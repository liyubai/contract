package com.cauc.training.pojos;

import java.util.Date;

/**
 * AddHoursAndAddLesson entity. @author MyEclipse Persistence Tools
 */

public class AddHoursAndAddLesson implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUserByVAudituserid;
	private TUser TUserByVCreateuserid;
	private TTrainingLesson TTrainingLesson;
	private StudentBaseInfo studentBaseInfo;
	private Integer IType;
	private double DDuration;
	private Date DCreatedate;
	private Integer IAuditstatus;
	private Date DAudittime;

	// Constructors

	/** default constructor */
	public AddHoursAndAddLesson() {
	}

	/** minimal constructor */
	public AddHoursAndAddLesson(TUser TUserByVCreateuserid, Date DCreatedate) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public AddHoursAndAddLesson(TUser TUserByVAudituserid,
			TUser TUserByVCreateuserid, TTrainingLesson TTrainingLesson,
			StudentBaseInfo studentBaseInfo, Integer IType, double DDuration,
			Date DCreatedate, Integer IAuditstatus, Date DAudittime) {
		this.TUserByVAudituserid = TUserByVAudituserid;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.TTrainingLesson = TTrainingLesson;
		this.studentBaseInfo = studentBaseInfo;
		this.IType = IType;
		this.DDuration = DDuration;
		this.DCreatedate = DCreatedate;
		this.IAuditstatus = IAuditstatus;
		this.DAudittime = DAudittime;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUserByVAudituserid() {
		return this.TUserByVAudituserid;
	}

	public void setTUserByVAudituserid(TUser TUserByVAudituserid) {
		this.TUserByVAudituserid = TUserByVAudituserid;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public double getDDuration() {
		return this.DDuration;
	}

	public void setDDuration(double DDuration) {
		this.DDuration = DDuration;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIAuditstatus() {
		return this.IAuditstatus;
	}

	public void setIAuditstatus(Integer IAuditstatus) {
		this.IAuditstatus = IAuditstatus;
	}

	public Date getDAudittime() {
		return this.DAudittime;
	}

	public void setDAudittime(Date DAudittime) {
		this.DAudittime = DAudittime;
	}

}