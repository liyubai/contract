package com.cauc.training.pojos;

import java.util.Date;

/**
 * AssignExamTeacher entity. @author MyEclipse Persistence Tools
 */

public class AssignExamTeacher implements java.io.Serializable {

	// Fields

	private String VId;
	private PracticeAsk practiceAsk;
	private TUser TUser;
	private TeacherBaseInfo teacherBaseInfo;
	private TOtheruser TOtheruser;
	private Integer IType;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public AssignExamTeacher() {
	}

	/** full constructor */
	public AssignExamTeacher(PracticeAsk practiceAsk, TUser TUser,
			TeacherBaseInfo teacherBaseInfo, TOtheruser TOtheruser,
			Integer IType, Date DCreatedate) {
		this.practiceAsk = practiceAsk;
		this.TUser = TUser;
		this.teacherBaseInfo = teacherBaseInfo;
		this.TOtheruser = TOtheruser;
		this.IType = IType;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public PracticeAsk getPracticeAsk() {
		return this.practiceAsk;
	}

	public void setPracticeAsk(PracticeAsk practiceAsk) {
		this.practiceAsk = practiceAsk;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public TOtheruser getTOtheruser() {
		return this.TOtheruser;
	}

	public void setTOtheruser(TOtheruser TOtheruser) {
		this.TOtheruser = TOtheruser;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}