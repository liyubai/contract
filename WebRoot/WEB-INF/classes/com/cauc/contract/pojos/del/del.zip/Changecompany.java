package com.cauc.training.pojos;

import java.util.Date;

/**
 * Changecompany entity. @author MyEclipse Persistence Tools
 */

public class Changecompany implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrgByVNewcompany;
	private TUser TUser;
	private TOrg TOrgByVOldcompany;
	private StudentBaseInfo studentBaseInfo;
	private String VReason;
	private Date DChangetime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public Changecompany() {
	}

	/** full constructor */
	public Changecompany(TOrg TOrgByVNewcompany, TUser TUser,
			TOrg TOrgByVOldcompany, StudentBaseInfo studentBaseInfo,
			String VReason, Date DChangetime, Date DCreatedate) {
		this.TOrgByVNewcompany = TOrgByVNewcompany;
		this.TUser = TUser;
		this.TOrgByVOldcompany = TOrgByVOldcompany;
		this.studentBaseInfo = studentBaseInfo;
		this.VReason = VReason;
		this.DChangetime = DChangetime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrgByVNewcompany() {
		return this.TOrgByVNewcompany;
	}

	public void setTOrgByVNewcompany(TOrg TOrgByVNewcompany) {
		this.TOrgByVNewcompany = TOrgByVNewcompany;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TOrg getTOrgByVOldcompany() {
		return this.TOrgByVOldcompany;
	}

	public void setTOrgByVOldcompany(TOrg TOrgByVOldcompany) {
		this.TOrgByVOldcompany = TOrgByVOldcompany;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDChangetime() {
		return this.DChangetime;
	}

	public void setDChangetime(Date DChangetime) {
		this.DChangetime = DChangetime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}