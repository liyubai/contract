package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Changedbaseflyline entity. @author MyEclipse Persistence Tools
 */

public class Changedbaseflyline implements java.io.Serializable {

	// Fields

	private String VId;
	private Station stationByEndStationId;
	private TUser TUser;
	private Station stationByStartStationid;
	private double DCourse;
	private Date DCreatedate;
	private Set lessonchangedbaseflylines = new HashSet(0);

	// Constructors

	/** default constructor */
	public Changedbaseflyline() {
	}

	/** minimal constructor */
	public Changedbaseflyline(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public Changedbaseflyline(Station stationByEndStationId, TUser TUser,
			Station stationByStartStationid, double DCourse, Date DCreatedate,
			Set lessonchangedbaseflylines) {
		this.stationByEndStationId = stationByEndStationId;
		this.TUser = TUser;
		this.stationByStartStationid = stationByStartStationid;
		this.DCourse = DCourse;
		this.DCreatedate = DCreatedate;
		this.lessonchangedbaseflylines = lessonchangedbaseflylines;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Station getStationByEndStationId() {
		return this.stationByEndStationId;
	}

	public void setStationByEndStationId(Station stationByEndStationId) {
		this.stationByEndStationId = stationByEndStationId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Station getStationByStartStationid() {
		return this.stationByStartStationid;
	}

	public void setStationByStartStationid(Station stationByStartStationid) {
		this.stationByStartStationid = stationByStartStationid;
	}

	public double getDCourse() {
		return this.DCourse;
	}

	public void setDCourse(double DCourse) {
		this.DCourse = DCourse;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getLessonchangedbaseflylines() {
		return this.lessonchangedbaseflylines;
	}

	public void setLessonchangedbaseflylines(Set lessonchangedbaseflylines) {
		this.lessonchangedbaseflylines = lessonchangedbaseflylines;
	}

}