package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Flytaskbook entity. @author MyEclipse Persistence Tools
 */

public class Flytaskbook implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TeacherBaseInfo teacherBaseInfo;
	private String VEnginecode;
	private String VEngineform;
	private String VCaptain;
	private String VSecondcaptain;
	private String VCrew;
	private String VInspector;
	private String VEaxm;
	private String VSubject;
	private String VFlyline;
	private double DJgweight;
	private double DJbweight;
	private double DMaxfweight;
	private double DMaxlweight;
	private String VOperator;
	private String VDean;
	private Date DDate;
	private Date DCreateDate;
	private Set TFlyreports = new HashSet(0);

	// Constructors

	/** default constructor */
	public Flytaskbook() {
	}

	/** minimal constructor */
	public Flytaskbook(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Flytaskbook(TUser TUser, TeacherBaseInfo teacherBaseInfo,
			String VEnginecode, String VEngineform, String VCaptain,
			String VSecondcaptain, String VCrew, String VInspector,
			String VEaxm, String VSubject, String VFlyline, double DJgweight,
			double DJbweight, double DMaxfweight, double DMaxlweight,
			String VOperator, String VDean, Date DDate, Date DCreateDate,
			Set TFlyreports) {
		this.TUser = TUser;
		this.teacherBaseInfo = teacherBaseInfo;
		this.VEnginecode = VEnginecode;
		this.VEngineform = VEngineform;
		this.VCaptain = VCaptain;
		this.VSecondcaptain = VSecondcaptain;
		this.VCrew = VCrew;
		this.VInspector = VInspector;
		this.VEaxm = VEaxm;
		this.VSubject = VSubject;
		this.VFlyline = VFlyline;
		this.DJgweight = DJgweight;
		this.DJbweight = DJbweight;
		this.DMaxfweight = DMaxfweight;
		this.DMaxlweight = DMaxlweight;
		this.VOperator = VOperator;
		this.VDean = VDean;
		this.DDate = DDate;
		this.DCreateDate = DCreateDate;
		this.TFlyreports = TFlyreports;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public String getVEnginecode() {
		return this.VEnginecode;
	}

	public void setVEnginecode(String VEnginecode) {
		this.VEnginecode = VEnginecode;
	}

	public String getVEngineform() {
		return this.VEngineform;
	}

	public void setVEngineform(String VEngineform) {
		this.VEngineform = VEngineform;
	}

	public String getVCaptain() {
		return this.VCaptain;
	}

	public void setVCaptain(String VCaptain) {
		this.VCaptain = VCaptain;
	}

	public String getVSecondcaptain() {
		return this.VSecondcaptain;
	}

	public void setVSecondcaptain(String VSecondcaptain) {
		this.VSecondcaptain = VSecondcaptain;
	}

	public String getVCrew() {
		return this.VCrew;
	}

	public void setVCrew(String VCrew) {
		this.VCrew = VCrew;
	}

	public String getVInspector() {
		return this.VInspector;
	}

	public void setVInspector(String VInspector) {
		this.VInspector = VInspector;
	}

	public String getVEaxm() {
		return this.VEaxm;
	}

	public void setVEaxm(String VEaxm) {
		this.VEaxm = VEaxm;
	}

	public String getVSubject() {
		return this.VSubject;
	}

	public void setVSubject(String VSubject) {
		this.VSubject = VSubject;
	}

	public String getVFlyline() {
		return this.VFlyline;
	}

	public void setVFlyline(String VFlyline) {
		this.VFlyline = VFlyline;
	}

	public double getDJgweight() {
		return this.DJgweight;
	}

	public void setDJgweight(double DJgweight) {
		this.DJgweight = DJgweight;
	}

	public double getDJbweight() {
		return this.DJbweight;
	}

	public void setDJbweight(double DJbweight) {
		this.DJbweight = DJbweight;
	}

	public double getDMaxfweight() {
		return this.DMaxfweight;
	}

	public void setDMaxfweight(double DMaxfweight) {
		this.DMaxfweight = DMaxfweight;
	}

	public double getDMaxlweight() {
		return this.DMaxlweight;
	}

	public void setDMaxlweight(double DMaxlweight) {
		this.DMaxlweight = DMaxlweight;
	}

	public String getVOperator() {
		return this.VOperator;
	}

	public void setVOperator(String VOperator) {
		this.VOperator = VOperator;
	}

	public String getVDean() {
		return this.VDean;
	}

	public void setVDean(String VDean) {
		this.VDean = VDean;
	}

	public Date getDDate() {
		return this.DDate;
	}

	public void setDDate(Date DDate) {
		this.DDate = DDate;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Set getTFlyreports() {
		return this.TFlyreports;
	}

	public void setTFlyreports(Set TFlyreports) {
		this.TFlyreports = TFlyreports;
	}

}