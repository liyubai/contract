package com.cauc.training.pojos;

import java.util.Date;

/**
 * GraduationDesign entity. @author MyEclipse Persistence Tools
 */

public class GraduationDesign implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Integer ICheckResult;
	private Date DCreateDate;
	private Integer IType;

	// Constructors

	/** default constructor */
	public GraduationDesign() {
	}

	/** minimal constructor */
	public GraduationDesign(TUser TUser, StudentBaseInfo studentBaseInfo,
			Integer ICheckResult, Date DCreateDate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.ICheckResult = ICheckResult;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public GraduationDesign(TUser TUser, StudentBaseInfo studentBaseInfo,
			Integer ICheckResult, Date DCreateDate, Integer IType) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.ICheckResult = ICheckResult;
		this.DCreateDate = DCreateDate;
		this.IType = IType;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Integer getICheckResult() {
		return this.ICheckResult;
	}

	public void setICheckResult(Integer ICheckResult) {
		this.ICheckResult = ICheckResult;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

}