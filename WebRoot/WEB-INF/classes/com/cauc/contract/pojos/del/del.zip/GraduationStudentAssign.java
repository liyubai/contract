package com.cauc.training.pojos;

import java.util.Date;

/**
 * GraduationStudentAssign entity. @author MyEclipse Persistence Tools
 */

public class GraduationStudentAssign implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private TOrg TOrg;
	private String VAssignaddress;
	private Date VAssigndate;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public GraduationStudentAssign() {
	}

	/** full constructor */
	public GraduationStudentAssign(TUser TUser,
			StudentBaseInfo studentBaseInfo, TOrg TOrg, String VAssignaddress,
			Date VAssigndate, Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.TOrg = TOrg;
		this.VAssignaddress = VAssignaddress;
		this.VAssigndate = VAssigndate;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public String getVAssignaddress() {
		return this.VAssignaddress;
	}

	public void setVAssignaddress(String VAssignaddress) {
		this.VAssignaddress = VAssignaddress;
	}

	public Date getVAssigndate() {
		return this.VAssigndate;
	}

	public void setVAssigndate(Date VAssigndate) {
		this.VAssigndate = VAssigndate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}