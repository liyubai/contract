package com.cauc.training.pojos;

/**
 * Lessonchangedbaseflyline entity. @author MyEclipse Persistence Tools
 */

public class Lessonchangedbaseflyline implements java.io.Serializable {

	// Fields

	private String VId;
	private Changedbaseflyline changedbaseflyline;
	private TTrainingLesson TTrainingLesson;
	private Integer IDefine;

	// Constructors

	/** default constructor */
	public Lessonchangedbaseflyline() {
	}

	/** full constructor */
	public Lessonchangedbaseflyline(Changedbaseflyline changedbaseflyline,
			TTrainingLesson TTrainingLesson, Integer IDefine) {
		this.changedbaseflyline = changedbaseflyline;
		this.TTrainingLesson = TTrainingLesson;
		this.IDefine = IDefine;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Changedbaseflyline getChangedbaseflyline() {
		return this.changedbaseflyline;
	}

	public void setChangedbaseflyline(Changedbaseflyline changedbaseflyline) {
		this.changedbaseflyline = changedbaseflyline;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public Integer getIDefine() {
		return this.IDefine;
	}

	public void setIDefine(Integer IDefine) {
		this.IDefine = IDefine;
	}

}