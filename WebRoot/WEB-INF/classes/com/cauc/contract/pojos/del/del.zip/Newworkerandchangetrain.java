package com.cauc.training.pojos;

import java.util.Date;

/**
 * Newworkerandchangetrain entity. @author MyEclipse Persistence Tools
 */

public class Newworkerandchangetrain implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DStarttime;
	private Date DEndtime;
	private double DScore;
	private Integer ITrainType;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public Newworkerandchangetrain() {
	}

	/** minimal constructor */
	public Newworkerandchangetrain(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public Newworkerandchangetrain(TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DStarttime, Date DEndtime,
			double DScore, Integer ITrainType, Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DStarttime = DStarttime;
		this.DEndtime = DEndtime;
		this.DScore = DScore;
		this.ITrainType = ITrainType;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDStarttime() {
		return this.DStarttime;
	}

	public void setDStarttime(Date DStarttime) {
		this.DStarttime = DStarttime;
	}

	public Date getDEndtime() {
		return this.DEndtime;
	}

	public void setDEndtime(Date DEndtime) {
		this.DEndtime = DEndtime;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public Integer getITrainType() {
		return this.ITrainType;
	}

	public void setITrainType(Integer ITrainType) {
		this.ITrainType = ITrainType;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}