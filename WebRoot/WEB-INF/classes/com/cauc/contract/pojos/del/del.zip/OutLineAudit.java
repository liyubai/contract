package com.cauc.training.pojos;

import java.util.Date;

/**
 * OutLineAudit entity. @author MyEclipse Persistence Tools
 */

public class OutLineAudit implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutline;
	private TUser TUser;
	private Date DAudittime;
	private Integer IStatus;
	private String VReason;

	// Constructors

	/** default constructor */
	public OutLineAudit() {
	}

	/** full constructor */
	public OutLineAudit(TOutline TOutline, TUser TUser, Date DAudittime,
			Integer IStatus, String VReason) {
		this.TOutline = TOutline;
		this.TUser = TUser;
		this.DAudittime = DAudittime;
		this.IStatus = IStatus;
		this.VReason = VReason;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDAudittime() {
		return this.DAudittime;
	}

	public void setDAudittime(Date DAudittime) {
		this.DAudittime = DAudittime;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

}