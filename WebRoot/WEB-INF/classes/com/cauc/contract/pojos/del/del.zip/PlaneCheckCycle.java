package com.cauc.training.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * PlaneCheckCycle entity. @author MyEclipse Persistence Tools
 */

public class PlaneCheckCycle implements java.io.Serializable {

	// Fields

	private String VId;
	private String VFormid;
	private Integer ICycle;
	private Set planechecks = new HashSet(0);

	// Constructors

	/** default constructor */
	public PlaneCheckCycle() {
	}

	/** full constructor */
	public PlaneCheckCycle(String VFormid, Integer ICycle, Set planechecks) {
		this.VFormid = VFormid;
		this.ICycle = ICycle;
		this.planechecks = planechecks;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public String getVFormid() {
		return this.VFormid;
	}

	public void setVFormid(String VFormid) {
		this.VFormid = VFormid;
	}

	public Integer getICycle() {
		return this.ICycle;
	}

	public void setICycle(Integer ICycle) {
		this.ICycle = ICycle;
	}

	public Set getPlanechecks() {
		return this.planechecks;
	}

	public void setPlanechecks(Set planechecks) {
		this.planechecks = planechecks;
	}

}