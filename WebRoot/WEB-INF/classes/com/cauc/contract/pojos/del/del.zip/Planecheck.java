package com.cauc.training.pojos;

import java.util.Date;

/**
 * Planecheck entity. @author MyEclipse Persistence Tools
 */

public class Planecheck implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private PlaneCheckCycle planeCheckCycle;
	private Planeinfo planeinfo;
	private Date DChecktime;
	private String VCheckperson;
	private String VCheckresult;
	private String VChecktype;
	private Date DCreateDate;
	private double IFifty;
	private double IOne;
	private double ITwo;
	private double IThree;

	// Constructors

	/** default constructor */
	public Planecheck() {
	}

	/** minimal constructor */
	public Planecheck(TUser TUser, Date DChecktime, Date DCreateDate) {
		this.TUser = TUser;
		this.DChecktime = DChecktime;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Planecheck(TUser TUser, PlaneCheckCycle planeCheckCycle,
			Planeinfo planeinfo, Date DChecktime, String VCheckperson,
			String VCheckresult, String VChecktype, Date DCreateDate,
			double IFifty, double IOne, double ITwo, double IThree) {
		this.TUser = TUser;
		this.planeCheckCycle = planeCheckCycle;
		this.planeinfo = planeinfo;
		this.DChecktime = DChecktime;
		this.VCheckperson = VCheckperson;
		this.VCheckresult = VCheckresult;
		this.VChecktype = VChecktype;
		this.DCreateDate = DCreateDate;
		this.IFifty = IFifty;
		this.IOne = IOne;
		this.ITwo = ITwo;
		this.IThree = IThree;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public PlaneCheckCycle getPlaneCheckCycle() {
		return this.planeCheckCycle;
	}

	public void setPlaneCheckCycle(PlaneCheckCycle planeCheckCycle) {
		this.planeCheckCycle = planeCheckCycle;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Date getDChecktime() {
		return this.DChecktime;
	}

	public void setDChecktime(Date DChecktime) {
		this.DChecktime = DChecktime;
	}

	public String getVCheckperson() {
		return this.VCheckperson;
	}

	public void setVCheckperson(String VCheckperson) {
		this.VCheckperson = VCheckperson;
	}

	public String getVCheckresult() {
		return this.VCheckresult;
	}

	public void setVCheckresult(String VCheckresult) {
		this.VCheckresult = VCheckresult;
	}

	public String getVChecktype() {
		return this.VChecktype;
	}

	public void setVChecktype(String VChecktype) {
		this.VChecktype = VChecktype;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public double getIFifty() {
		return this.IFifty;
	}

	public void setIFifty(double IFifty) {
		this.IFifty = IFifty;
	}

	public double getIOne() {
		return this.IOne;
	}

	public void setIOne(double IOne) {
		this.IOne = IOne;
	}

	public double getITwo() {
		return this.ITwo;
	}

	public void setITwo(double ITwo) {
		this.ITwo = ITwo;
	}

	public double getIThree() {
		return this.IThree;
	}

	public void setIThree(double IThree) {
		this.IThree = IThree;
	}

}