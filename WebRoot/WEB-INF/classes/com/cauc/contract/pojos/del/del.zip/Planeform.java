package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Planeform entity. @author MyEclipse Persistence Tools
 */

public class Planeform implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private String VChangshang;
	private String VXingzhi;
	private String VFtd;
	private String DShouming;
	private String DJbweight;
	private String DFweight;
	private String DLweight;
	private String DJgweight;
	private String VBz;
	private Date DCreateDate;
	private Set planeinfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public Planeform() {
	}

	/** minimal constructor */
	public Planeform(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Planeform(TUser TUser, String VName, String VChangshang,
			String VXingzhi, String VFtd, String DShouming, String DJbweight,
			String DFweight, String DLweight, String DJgweight, String VBz,
			Date DCreateDate, Set planeinfos) {
		this.TUser = TUser;
		this.VName = VName;
		this.VChangshang = VChangshang;
		this.VXingzhi = VXingzhi;
		this.VFtd = VFtd;
		this.DShouming = DShouming;
		this.DJbweight = DJbweight;
		this.DFweight = DFweight;
		this.DLweight = DLweight;
		this.DJgweight = DJgweight;
		this.VBz = VBz;
		this.DCreateDate = DCreateDate;
		this.planeinfos = planeinfos;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVChangshang() {
		return this.VChangshang;
	}

	public void setVChangshang(String VChangshang) {
		this.VChangshang = VChangshang;
	}

	public String getVXingzhi() {
		return this.VXingzhi;
	}

	public void setVXingzhi(String VXingzhi) {
		this.VXingzhi = VXingzhi;
	}

	public String getVFtd() {
		return this.VFtd;
	}

	public void setVFtd(String VFtd) {
		this.VFtd = VFtd;
	}

	public String getDShouming() {
		return this.DShouming;
	}

	public void setDShouming(String DShouming) {
		this.DShouming = DShouming;
	}

	public String getDJbweight() {
		return this.DJbweight;
	}

	public void setDJbweight(String DJbweight) {
		this.DJbweight = DJbweight;
	}

	public String getDFweight() {
		return this.DFweight;
	}

	public void setDFweight(String DFweight) {
		this.DFweight = DFweight;
	}

	public String getDLweight() {
		return this.DLweight;
	}

	public void setDLweight(String DLweight) {
		this.DLweight = DLweight;
	}

	public String getDJgweight() {
		return this.DJgweight;
	}

	public void setDJgweight(String DJgweight) {
		this.DJgweight = DJgweight;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Set getPlaneinfos() {
		return this.planeinfos;
	}

	public void setPlaneinfos(Set planeinfos) {
		this.planeinfos = planeinfos;
	}

}