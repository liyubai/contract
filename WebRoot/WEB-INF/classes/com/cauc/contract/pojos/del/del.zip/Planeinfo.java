package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Planeinfo entity. @author MyEclipse Persistence Tools
 */

public class Planeinfo implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrg;
	private Planeform planeform;
	private TUser TUser;
	private String VPlanecode;
	private Date DEnterdate;
	private Integer ITimes;
	private double DUsetime;
	private double DCsdjtime;
	private double DActflytime;
	private double DSjdjflytime;
	private String VHgz;
	private Integer IStatus;
	private String VDw;
	private String VBz;
	private Date DCreateDate;
	private double DWstime;
	private double DYbtime;
	private double DEbtime;
	private double DYqwbtime;
	private Integer IDeviceType;
	private String VZhuce;
	private String VCountry;
	private Set TPlanereleases = new HashSet(0);
	private Set TTeacherpaytimes = new HashSet(0);
	private Set TFlightexperiencerecords = new HashSet(0);
	private Set TPlaneexchanges = new HashSet(0);
	private Set TFlightTrainingrecords = new HashSet(0);
	private Set TFlyteachrecords = new HashSet(0);
	private Set TDispatchs = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set TExperiencerecordEdits = new HashSet(0);
	private Set TOtherflyrecords = new HashSet(0);
	private Set planechecks = new HashSet(0);
	private Set TRepairrecords = new HashSet(0);
	private Set TTeacherflightexperiencerecords = new HashSet(0);

	// Constructors

	/** default constructor */
	public Planeinfo() {
	}

	/** minimal constructor */
	public Planeinfo(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Planeinfo(TOrg TOrg, Planeform planeform, TUser TUser,
			String VPlanecode, Date DEnterdate, Integer ITimes,
			double DUsetime, double DCsdjtime, double DActflytime,
			double DSjdjflytime, String VHgz, Integer IStatus, String VDw,
			String VBz, Date DCreateDate, double DWstime, double DYbtime,
			double DEbtime, double DYqwbtime, Integer IDeviceType,
			String VZhuce, String VCountry, Set TPlanereleases,
			Set TTeacherpaytimes, Set TFlightexperiencerecords,
			Set TPlaneexchanges, Set TFlightTrainingrecords,
			Set TFlyteachrecords, Set TDispatchs, Set THistoryrecords,
			Set TExperiencerecordEdits, Set TOtherflyrecords, Set planechecks,
			Set TRepairrecords, Set TTeacherflightexperiencerecords) {
		this.TOrg = TOrg;
		this.planeform = planeform;
		this.TUser = TUser;
		this.VPlanecode = VPlanecode;
		this.DEnterdate = DEnterdate;
		this.ITimes = ITimes;
		this.DUsetime = DUsetime;
		this.DCsdjtime = DCsdjtime;
		this.DActflytime = DActflytime;
		this.DSjdjflytime = DSjdjflytime;
		this.VHgz = VHgz;
		this.IStatus = IStatus;
		this.VDw = VDw;
		this.VBz = VBz;
		this.DCreateDate = DCreateDate;
		this.DWstime = DWstime;
		this.DYbtime = DYbtime;
		this.DEbtime = DEbtime;
		this.DYqwbtime = DYqwbtime;
		this.IDeviceType = IDeviceType;
		this.VZhuce = VZhuce;
		this.VCountry = VCountry;
		this.TPlanereleases = TPlanereleases;
		this.TTeacherpaytimes = TTeacherpaytimes;
		this.TFlightexperiencerecords = TFlightexperiencerecords;
		this.TPlaneexchanges = TPlaneexchanges;
		this.TFlightTrainingrecords = TFlightTrainingrecords;
		this.TFlyteachrecords = TFlyteachrecords;
		this.TDispatchs = TDispatchs;
		this.THistoryrecords = THistoryrecords;
		this.TExperiencerecordEdits = TExperiencerecordEdits;
		this.TOtherflyrecords = TOtherflyrecords;
		this.planechecks = planechecks;
		this.TRepairrecords = TRepairrecords;
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public Planeform getPlaneform() {
		return this.planeform;
	}

	public void setPlaneform(Planeform planeform) {
		this.planeform = planeform;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVPlanecode() {
		return this.VPlanecode;
	}

	public void setVPlanecode(String VPlanecode) {
		this.VPlanecode = VPlanecode;
	}

	public Date getDEnterdate() {
		return this.DEnterdate;
	}

	public void setDEnterdate(Date DEnterdate) {
		this.DEnterdate = DEnterdate;
	}

	public Integer getITimes() {
		return this.ITimes;
	}

	public void setITimes(Integer ITimes) {
		this.ITimes = ITimes;
	}

	public double getDUsetime() {
		return this.DUsetime;
	}

	public void setDUsetime(double DUsetime) {
		this.DUsetime = DUsetime;
	}

	public double getDCsdjtime() {
		return this.DCsdjtime;
	}

	public void setDCsdjtime(double DCsdjtime) {
		this.DCsdjtime = DCsdjtime;
	}

	public double getDActflytime() {
		return this.DActflytime;
	}

	public void setDActflytime(double DActflytime) {
		this.DActflytime = DActflytime;
	}

	public double getDSjdjflytime() {
		return this.DSjdjflytime;
	}

	public void setDSjdjflytime(double DSjdjflytime) {
		this.DSjdjflytime = DSjdjflytime;
	}

	public String getVHgz() {
		return this.VHgz;
	}

	public void setVHgz(String VHgz) {
		this.VHgz = VHgz;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public String getVDw() {
		return this.VDw;
	}

	public void setVDw(String VDw) {
		this.VDw = VDw;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public double getDWstime() {
		return this.DWstime;
	}

	public void setDWstime(double DWstime) {
		this.DWstime = DWstime;
	}

	public double getDYbtime() {
		return this.DYbtime;
	}

	public void setDYbtime(double DYbtime) {
		this.DYbtime = DYbtime;
	}

	public double getDEbtime() {
		return this.DEbtime;
	}

	public void setDEbtime(double DEbtime) {
		this.DEbtime = DEbtime;
	}

	public double getDYqwbtime() {
		return this.DYqwbtime;
	}

	public void setDYqwbtime(double DYqwbtime) {
		this.DYqwbtime = DYqwbtime;
	}

	public Integer getIDeviceType() {
		return this.IDeviceType;
	}

	public void setIDeviceType(Integer IDeviceType) {
		this.IDeviceType = IDeviceType;
	}

	public String getVZhuce() {
		return this.VZhuce;
	}

	public void setVZhuce(String VZhuce) {
		this.VZhuce = VZhuce;
	}

	public String getVCountry() {
		return this.VCountry;
	}

	public void setVCountry(String VCountry) {
		this.VCountry = VCountry;
	}

	public Set getTPlanereleases() {
		return this.TPlanereleases;
	}

	public void setTPlanereleases(Set TPlanereleases) {
		this.TPlanereleases = TPlanereleases;
	}

	public Set getTTeacherpaytimes() {
		return this.TTeacherpaytimes;
	}

	public void setTTeacherpaytimes(Set TTeacherpaytimes) {
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

	public Set getTFlightexperiencerecords() {
		return this.TFlightexperiencerecords;
	}

	public void setTFlightexperiencerecords(Set TFlightexperiencerecords) {
		this.TFlightexperiencerecords = TFlightexperiencerecords;
	}

	public Set getTPlaneexchanges() {
		return this.TPlaneexchanges;
	}

	public void setTPlaneexchanges(Set TPlaneexchanges) {
		this.TPlaneexchanges = TPlaneexchanges;
	}

	public Set getTFlightTrainingrecords() {
		return this.TFlightTrainingrecords;
	}

	public void setTFlightTrainingrecords(Set TFlightTrainingrecords) {
		this.TFlightTrainingrecords = TFlightTrainingrecords;
	}

	public Set getTFlyteachrecords() {
		return this.TFlyteachrecords;
	}

	public void setTFlyteachrecords(Set TFlyteachrecords) {
		this.TFlyteachrecords = TFlyteachrecords;
	}

	public Set getTDispatchs() {
		return this.TDispatchs;
	}

	public void setTDispatchs(Set TDispatchs) {
		this.TDispatchs = TDispatchs;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getTExperiencerecordEdits() {
		return this.TExperiencerecordEdits;
	}

	public void setTExperiencerecordEdits(Set TExperiencerecordEdits) {
		this.TExperiencerecordEdits = TExperiencerecordEdits;
	}

	public Set getTOtherflyrecords() {
		return this.TOtherflyrecords;
	}

	public void setTOtherflyrecords(Set TOtherflyrecords) {
		this.TOtherflyrecords = TOtherflyrecords;
	}

	public Set getPlanechecks() {
		return this.planechecks;
	}

	public void setPlanechecks(Set planechecks) {
		this.planechecks = planechecks;
	}

	public Set getTRepairrecords() {
		return this.TRepairrecords;
	}

	public void setTRepairrecords(Set TRepairrecords) {
		this.TRepairrecords = TRepairrecords;
	}

	public Set getTTeacherflightexperiencerecords() {
		return this.TTeacherflightexperiencerecords;
	}

	public void setTTeacherflightexperiencerecords(
			Set TTeacherflightexperiencerecords) {
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

}