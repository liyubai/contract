package com.cauc.training.pojos;

import java.util.Date;

/**
 * PolicyLaws entity. @author MyEclipse Persistence Tools
 */

public class PolicyLaws implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private Integer INo;
	private Integer IType;
	private String VContent;
	private Integer IContentType;
	private Integer IContentTime;
	private Integer ILimitTime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public PolicyLaws() {
	}

	/** minimal constructor */
	public PolicyLaws(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public PolicyLaws(TUser TUser, Integer INo, Integer IType, String VContent,
			Integer IContentType, Integer IContentTime, Integer ILimitTime,
			Date DCreatedate) {
		this.TUser = TUser;
		this.INo = INo;
		this.IType = IType;
		this.VContent = VContent;
		this.IContentType = IContentType;
		this.IContentTime = IContentTime;
		this.ILimitTime = ILimitTime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Integer getINo() {
		return this.INo;
	}

	public void setINo(Integer INo) {
		this.INo = INo;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public String getVContent() {
		return this.VContent;
	}

	public void setVContent(String VContent) {
		this.VContent = VContent;
	}

	public Integer getIContentType() {
		return this.IContentType;
	}

	public void setIContentType(Integer IContentType) {
		this.IContentType = IContentType;
	}

	public Integer getIContentTime() {
		return this.IContentTime;
	}

	public void setIContentTime(Integer IContentTime) {
		this.IContentTime = IContentTime;
	}

	public Integer getILimitTime() {
		return this.ILimitTime;
	}

	public void setILimitTime(Integer ILimitTime) {
		this.ILimitTime = ILimitTime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}