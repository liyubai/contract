package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * PracticeAsk entity. @author MyEclipse Persistence Tools
 */

public class PracticeAsk implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUserByVAuditUserid;
	private TUser TUserByVCreateuserid;
	private Date DCreatedate;
	private String VBz;
	private String VName;
	private String VContent;
	private Date DAskTime;
	private Integer IAuditStauts;
	private Date DAuditTime;
	private Date DExamTime;
	private Set practiceTests = new HashSet(0);
	private Set assignExamTeachers = new HashSet(0);

	// Constructors

	/** default constructor */
	public PracticeAsk() {
	}

	/** full constructor */
	public PracticeAsk(TUser TUserByVAuditUserid, TUser TUserByVCreateuserid,
			Date DCreatedate, String VBz, String VName, String VContent,
			Date DAskTime, Integer IAuditStauts, Date DAuditTime,
			Date DExamTime, Set practiceTests, Set assignExamTeachers) {
		this.TUserByVAuditUserid = TUserByVAuditUserid;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.DCreatedate = DCreatedate;
		this.VBz = VBz;
		this.VName = VName;
		this.VContent = VContent;
		this.DAskTime = DAskTime;
		this.IAuditStauts = IAuditStauts;
		this.DAuditTime = DAuditTime;
		this.DExamTime = DExamTime;
		this.practiceTests = practiceTests;
		this.assignExamTeachers = assignExamTeachers;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUserByVAuditUserid() {
		return this.TUserByVAuditUserid;
	}

	public void setTUserByVAuditUserid(TUser TUserByVAuditUserid) {
		this.TUserByVAuditUserid = TUserByVAuditUserid;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVContent() {
		return this.VContent;
	}

	public void setVContent(String VContent) {
		this.VContent = VContent;
	}

	public Date getDAskTime() {
		return this.DAskTime;
	}

	public void setDAskTime(Date DAskTime) {
		this.DAskTime = DAskTime;
	}

	public Integer getIAuditStauts() {
		return this.IAuditStauts;
	}

	public void setIAuditStauts(Integer IAuditStauts) {
		this.IAuditStauts = IAuditStauts;
	}

	public Date getDAuditTime() {
		return this.DAuditTime;
	}

	public void setDAuditTime(Date DAuditTime) {
		this.DAuditTime = DAuditTime;
	}

	public Date getDExamTime() {
		return this.DExamTime;
	}

	public void setDExamTime(Date DExamTime) {
		this.DExamTime = DExamTime;
	}

	public Set getPracticeTests() {
		return this.practiceTests;
	}

	public void setPracticeTests(Set practiceTests) {
		this.practiceTests = practiceTests;
	}

	public Set getAssignExamTeachers() {
		return this.assignExamTeachers;
	}

	public void setAssignExamTeachers(Set assignExamTeachers) {
		this.assignExamTeachers = assignExamTeachers;
	}

}