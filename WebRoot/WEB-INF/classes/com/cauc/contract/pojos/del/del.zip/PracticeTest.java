package com.cauc.training.pojos;

import java.util.Date;

/**
 * PracticeTest entity. @author MyEclipse Persistence Tools
 */

public class PracticeTest implements java.io.Serializable {

	// Fields

	private String VId;
	private PracticeAsk practiceAsk;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private TeacherBaseInfo teacherBaseInfo;
	private TOtheruser TOtheruser;
	private Date DRecommendTime;
	private Date DCreatedate;
	private Integer IType;

	// Constructors

	/** default constructor */
	public PracticeTest() {
	}

	/** full constructor */
	public PracticeTest(PracticeAsk practiceAsk, TUser TUser,
			StudentBaseInfo studentBaseInfo, TeacherBaseInfo teacherBaseInfo,
			TOtheruser TOtheruser, Date DRecommendTime, Date DCreatedate,
			Integer IType) {
		this.practiceAsk = practiceAsk;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.teacherBaseInfo = teacherBaseInfo;
		this.TOtheruser = TOtheruser;
		this.DRecommendTime = DRecommendTime;
		this.DCreatedate = DCreatedate;
		this.IType = IType;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public PracticeAsk getPracticeAsk() {
		return this.practiceAsk;
	}

	public void setPracticeAsk(PracticeAsk practiceAsk) {
		this.practiceAsk = practiceAsk;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public TOtheruser getTOtheruser() {
		return this.TOtheruser;
	}

	public void setTOtheruser(TOtheruser TOtheruser) {
		this.TOtheruser = TOtheruser;
	}

	public Date getDRecommendTime() {
		return this.DRecommendTime;
	}

	public void setDRecommendTime(Date DRecommendTime) {
		this.DRecommendTime = DRecommendTime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

}