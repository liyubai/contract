package com.cauc.training.pojos;

import java.util.Date;

/**
 * RecommendStudentLicenseExam entity. @author MyEclipse Persistence Tools
 */

public class RecommendStudentLicenseExam implements java.io.Serializable {

	// Fields

	private String VId;
	private TOtheruser TOtheruser;
	private TSetClass TSetClass;
	private TLesson TLesson;
	private StudentBaseInfo studentBaseInfo;
	private Date DTjdate;
	private Date DExamDate;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public RecommendStudentLicenseExam() {
	}

	/** full constructor */
	public RecommendStudentLicenseExam(TOtheruser TOtheruser,
			TSetClass TSetClass, TLesson TLesson,
			StudentBaseInfo studentBaseInfo, Date DTjdate, Date DExamDate,
			Date DCreateDate) {
		this.TOtheruser = TOtheruser;
		this.TSetClass = TSetClass;
		this.TLesson = TLesson;
		this.studentBaseInfo = studentBaseInfo;
		this.DTjdate = DTjdate;
		this.DExamDate = DExamDate;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOtheruser getTOtheruser() {
		return this.TOtheruser;
	}

	public void setTOtheruser(TOtheruser TOtheruser) {
		this.TOtheruser = TOtheruser;
	}

	public TSetClass getTSetClass() {
		return this.TSetClass;
	}

	public void setTSetClass(TSetClass TSetClass) {
		this.TSetClass = TSetClass;
	}

	public TLesson getTLesson() {
		return this.TLesson;
	}

	public void setTLesson(TLesson TLesson) {
		this.TLesson = TLesson;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDTjdate() {
		return this.DTjdate;
	}

	public void setDTjdate(Date DTjdate) {
		this.DTjdate = DTjdate;
	}

	public Date getDExamDate() {
		return this.DExamDate;
	}

	public void setDExamDate(Date DExamDate) {
		this.DExamDate = DExamDate;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}