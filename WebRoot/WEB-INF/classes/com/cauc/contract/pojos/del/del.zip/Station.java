package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Station entity. @author MyEclipse Persistence Tools
 */

public class Station implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private Date DCreateDate;
	private String VCode;
	private String VJcname;
	private String DArpx;
	private String DArpy;
	private Set changedbaseflylinesForEndStationId = new HashSet(0);
	private Set TFlightexperiencerecordsForVLandpos = new HashSet(0);
	private Set TOtherflyrecordsForVLandpos = new HashSet(0);
	private Set THistoryrecordsForVLpos = new HashSet(0);
	private Set TFlyteachrecordsForVFlypos = new HashSet(0);
	private Set TTeacherflightexperiencerecordsForVFlypos = new HashSet(0);
	private Set TTeacherpaytimesForVLandpos = new HashSet(0);
	private Set TTeacherpaytimesForVFlypos = new HashSet(0);
	private Set TFlightexperiencerecordsForVFlypos = new HashSet(0);
	private Set TFlyteachrecordsForVLandpos = new HashSet(0);
	private Set TFlyreportsForVFlypos = new HashSet(0);
	private Set TExperiencerecordEditsForVLandpos = new HashSet(0);
	private Set TOtherflyrecordsForVFlypos = new HashSet(0);
	private Set THistoryrecordsForVFpos = new HashSet(0);
	private Set TTeacherflightexperiencerecordsForVLandpos = new HashSet(0);
	private Set TFlightTrainingrecordsForVFpos = new HashSet(0);
	private Set TFlyreportsForVLandpos = new HashSet(0);
	private Set TExperiencerecordEditsForVFlypos = new HashSet(0);
	private Set TTrainingLessonsForVStartpos = new HashSet(0);
	private Set TTrainingLessonsForVEndpos = new HashSet(0);
	private Set changedbaseflylinesForStartStationid = new HashSet(0);
	private Set TFlightTrainingrecordsForVJtpos = new HashSet(0);
	private Set TFlightTrainingrecordsForVLpos = new HashSet(0);

	// Constructors

	/** default constructor */
	public Station() {
	}

	/** minimal constructor */
	public Station(TUser TUser, String VName, Date DCreateDate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Station(TUser TUser, String VName, Date DCreateDate, String VCode,
			String VJcname, String DArpx, String DArpy,
			Set changedbaseflylinesForEndStationId,
			Set TFlightexperiencerecordsForVLandpos,
			Set TOtherflyrecordsForVLandpos, Set THistoryrecordsForVLpos,
			Set TFlyteachrecordsForVFlypos,
			Set TTeacherflightexperiencerecordsForVFlypos,
			Set TTeacherpaytimesForVLandpos, Set TTeacherpaytimesForVFlypos,
			Set TFlightexperiencerecordsForVFlypos,
			Set TFlyteachrecordsForVLandpos, Set TFlyreportsForVFlypos,
			Set TExperiencerecordEditsForVLandpos,
			Set TOtherflyrecordsForVFlypos, Set THistoryrecordsForVFpos,
			Set TTeacherflightexperiencerecordsForVLandpos,
			Set TFlightTrainingrecordsForVFpos, Set TFlyreportsForVLandpos,
			Set TExperiencerecordEditsForVFlypos,
			Set TTrainingLessonsForVStartpos, Set TTrainingLessonsForVEndpos,
			Set changedbaseflylinesForStartStationid,
			Set TFlightTrainingrecordsForVJtpos,
			Set TFlightTrainingrecordsForVLpos) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreateDate = DCreateDate;
		this.VCode = VCode;
		this.VJcname = VJcname;
		this.DArpx = DArpx;
		this.DArpy = DArpy;
		this.changedbaseflylinesForEndStationId = changedbaseflylinesForEndStationId;
		this.TFlightexperiencerecordsForVLandpos = TFlightexperiencerecordsForVLandpos;
		this.TOtherflyrecordsForVLandpos = TOtherflyrecordsForVLandpos;
		this.THistoryrecordsForVLpos = THistoryrecordsForVLpos;
		this.TFlyteachrecordsForVFlypos = TFlyteachrecordsForVFlypos;
		this.TTeacherflightexperiencerecordsForVFlypos = TTeacherflightexperiencerecordsForVFlypos;
		this.TTeacherpaytimesForVLandpos = TTeacherpaytimesForVLandpos;
		this.TTeacherpaytimesForVFlypos = TTeacherpaytimesForVFlypos;
		this.TFlightexperiencerecordsForVFlypos = TFlightexperiencerecordsForVFlypos;
		this.TFlyteachrecordsForVLandpos = TFlyteachrecordsForVLandpos;
		this.TFlyreportsForVFlypos = TFlyreportsForVFlypos;
		this.TExperiencerecordEditsForVLandpos = TExperiencerecordEditsForVLandpos;
		this.TOtherflyrecordsForVFlypos = TOtherflyrecordsForVFlypos;
		this.THistoryrecordsForVFpos = THistoryrecordsForVFpos;
		this.TTeacherflightexperiencerecordsForVLandpos = TTeacherflightexperiencerecordsForVLandpos;
		this.TFlightTrainingrecordsForVFpos = TFlightTrainingrecordsForVFpos;
		this.TFlyreportsForVLandpos = TFlyreportsForVLandpos;
		this.TExperiencerecordEditsForVFlypos = TExperiencerecordEditsForVFlypos;
		this.TTrainingLessonsForVStartpos = TTrainingLessonsForVStartpos;
		this.TTrainingLessonsForVEndpos = TTrainingLessonsForVEndpos;
		this.changedbaseflylinesForStartStationid = changedbaseflylinesForStartStationid;
		this.TFlightTrainingrecordsForVJtpos = TFlightTrainingrecordsForVJtpos;
		this.TFlightTrainingrecordsForVLpos = TFlightTrainingrecordsForVLpos;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public String getVJcname() {
		return this.VJcname;
	}

	public void setVJcname(String VJcname) {
		this.VJcname = VJcname;
	}

	public String getDArpx() {
		return this.DArpx;
	}

	public void setDArpx(String DArpx) {
		this.DArpx = DArpx;
	}

	public String getDArpy() {
		return this.DArpy;
	}

	public void setDArpy(String DArpy) {
		this.DArpy = DArpy;
	}

	public Set getChangedbaseflylinesForEndStationId() {
		return this.changedbaseflylinesForEndStationId;
	}

	public void setChangedbaseflylinesForEndStationId(
			Set changedbaseflylinesForEndStationId) {
		this.changedbaseflylinesForEndStationId = changedbaseflylinesForEndStationId;
	}

	public Set getTFlightexperiencerecordsForVLandpos() {
		return this.TFlightexperiencerecordsForVLandpos;
	}

	public void setTFlightexperiencerecordsForVLandpos(
			Set TFlightexperiencerecordsForVLandpos) {
		this.TFlightexperiencerecordsForVLandpos = TFlightexperiencerecordsForVLandpos;
	}

	public Set getTOtherflyrecordsForVLandpos() {
		return this.TOtherflyrecordsForVLandpos;
	}

	public void setTOtherflyrecordsForVLandpos(Set TOtherflyrecordsForVLandpos) {
		this.TOtherflyrecordsForVLandpos = TOtherflyrecordsForVLandpos;
	}

	public Set getTHistoryrecordsForVLpos() {
		return this.THistoryrecordsForVLpos;
	}

	public void setTHistoryrecordsForVLpos(Set THistoryrecordsForVLpos) {
		this.THistoryrecordsForVLpos = THistoryrecordsForVLpos;
	}

	public Set getTFlyteachrecordsForVFlypos() {
		return this.TFlyteachrecordsForVFlypos;
	}

	public void setTFlyteachrecordsForVFlypos(Set TFlyteachrecordsForVFlypos) {
		this.TFlyteachrecordsForVFlypos = TFlyteachrecordsForVFlypos;
	}

	public Set getTTeacherflightexperiencerecordsForVFlypos() {
		return this.TTeacherflightexperiencerecordsForVFlypos;
	}

	public void setTTeacherflightexperiencerecordsForVFlypos(
			Set TTeacherflightexperiencerecordsForVFlypos) {
		this.TTeacherflightexperiencerecordsForVFlypos = TTeacherflightexperiencerecordsForVFlypos;
	}

	public Set getTTeacherpaytimesForVLandpos() {
		return this.TTeacherpaytimesForVLandpos;
	}

	public void setTTeacherpaytimesForVLandpos(Set TTeacherpaytimesForVLandpos) {
		this.TTeacherpaytimesForVLandpos = TTeacherpaytimesForVLandpos;
	}

	public Set getTTeacherpaytimesForVFlypos() {
		return this.TTeacherpaytimesForVFlypos;
	}

	public void setTTeacherpaytimesForVFlypos(Set TTeacherpaytimesForVFlypos) {
		this.TTeacherpaytimesForVFlypos = TTeacherpaytimesForVFlypos;
	}

	public Set getTFlightexperiencerecordsForVFlypos() {
		return this.TFlightexperiencerecordsForVFlypos;
	}

	public void setTFlightexperiencerecordsForVFlypos(
			Set TFlightexperiencerecordsForVFlypos) {
		this.TFlightexperiencerecordsForVFlypos = TFlightexperiencerecordsForVFlypos;
	}

	public Set getTFlyteachrecordsForVLandpos() {
		return this.TFlyteachrecordsForVLandpos;
	}

	public void setTFlyteachrecordsForVLandpos(Set TFlyteachrecordsForVLandpos) {
		this.TFlyteachrecordsForVLandpos = TFlyteachrecordsForVLandpos;
	}

	public Set getTFlyreportsForVFlypos() {
		return this.TFlyreportsForVFlypos;
	}

	public void setTFlyreportsForVFlypos(Set TFlyreportsForVFlypos) {
		this.TFlyreportsForVFlypos = TFlyreportsForVFlypos;
	}

	public Set getTExperiencerecordEditsForVLandpos() {
		return this.TExperiencerecordEditsForVLandpos;
	}

	public void setTExperiencerecordEditsForVLandpos(
			Set TExperiencerecordEditsForVLandpos) {
		this.TExperiencerecordEditsForVLandpos = TExperiencerecordEditsForVLandpos;
	}

	public Set getTOtherflyrecordsForVFlypos() {
		return this.TOtherflyrecordsForVFlypos;
	}

	public void setTOtherflyrecordsForVFlypos(Set TOtherflyrecordsForVFlypos) {
		this.TOtherflyrecordsForVFlypos = TOtherflyrecordsForVFlypos;
	}

	public Set getTHistoryrecordsForVFpos() {
		return this.THistoryrecordsForVFpos;
	}

	public void setTHistoryrecordsForVFpos(Set THistoryrecordsForVFpos) {
		this.THistoryrecordsForVFpos = THistoryrecordsForVFpos;
	}

	public Set getTTeacherflightexperiencerecordsForVLandpos() {
		return this.TTeacherflightexperiencerecordsForVLandpos;
	}

	public void setTTeacherflightexperiencerecordsForVLandpos(
			Set TTeacherflightexperiencerecordsForVLandpos) {
		this.TTeacherflightexperiencerecordsForVLandpos = TTeacherflightexperiencerecordsForVLandpos;
	}

	public Set getTFlightTrainingrecordsForVFpos() {
		return this.TFlightTrainingrecordsForVFpos;
	}

	public void setTFlightTrainingrecordsForVFpos(
			Set TFlightTrainingrecordsForVFpos) {
		this.TFlightTrainingrecordsForVFpos = TFlightTrainingrecordsForVFpos;
	}

	public Set getTFlyreportsForVLandpos() {
		return this.TFlyreportsForVLandpos;
	}

	public void setTFlyreportsForVLandpos(Set TFlyreportsForVLandpos) {
		this.TFlyreportsForVLandpos = TFlyreportsForVLandpos;
	}

	public Set getTExperiencerecordEditsForVFlypos() {
		return this.TExperiencerecordEditsForVFlypos;
	}

	public void setTExperiencerecordEditsForVFlypos(
			Set TExperiencerecordEditsForVFlypos) {
		this.TExperiencerecordEditsForVFlypos = TExperiencerecordEditsForVFlypos;
	}

	public Set getTTrainingLessonsForVStartpos() {
		return this.TTrainingLessonsForVStartpos;
	}

	public void setTTrainingLessonsForVStartpos(Set TTrainingLessonsForVStartpos) {
		this.TTrainingLessonsForVStartpos = TTrainingLessonsForVStartpos;
	}

	public Set getTTrainingLessonsForVEndpos() {
		return this.TTrainingLessonsForVEndpos;
	}

	public void setTTrainingLessonsForVEndpos(Set TTrainingLessonsForVEndpos) {
		this.TTrainingLessonsForVEndpos = TTrainingLessonsForVEndpos;
	}

	public Set getChangedbaseflylinesForStartStationid() {
		return this.changedbaseflylinesForStartStationid;
	}

	public void setChangedbaseflylinesForStartStationid(
			Set changedbaseflylinesForStartStationid) {
		this.changedbaseflylinesForStartStationid = changedbaseflylinesForStartStationid;
	}

	public Set getTFlightTrainingrecordsForVJtpos() {
		return this.TFlightTrainingrecordsForVJtpos;
	}

	public void setTFlightTrainingrecordsForVJtpos(
			Set TFlightTrainingrecordsForVJtpos) {
		this.TFlightTrainingrecordsForVJtpos = TFlightTrainingrecordsForVJtpos;
	}

	public Set getTFlightTrainingrecordsForVLpos() {
		return this.TFlightTrainingrecordsForVLpos;
	}

	public void setTFlightTrainingrecordsForVLpos(
			Set TFlightTrainingrecordsForVLpos) {
		this.TFlightTrainingrecordsForVLpos = TFlightTrainingrecordsForVLpos;
	}

}