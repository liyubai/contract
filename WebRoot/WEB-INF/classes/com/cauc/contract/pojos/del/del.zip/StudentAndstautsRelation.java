package com.cauc.training.pojos;

import java.util.Date;

/**
 * StudentAndstautsRelation entity. @author MyEclipse Persistence Tools
 */

public class StudentAndstautsRelation implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TDiction TDictionByVStudentid;
	private TDiction TDictionByVStuStatusid;
	private Date DCreatetime;

	// Constructors

	/** default constructor */
	public StudentAndstautsRelation() {
	}

	/** full constructor */
	public StudentAndstautsRelation(TUser TUser, TDiction TDictionByVStudentid,
			TDiction TDictionByVStuStatusid, Date DCreatetime) {
		this.TUser = TUser;
		this.TDictionByVStudentid = TDictionByVStudentid;
		this.TDictionByVStuStatusid = TDictionByVStuStatusid;
		this.DCreatetime = DCreatetime;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TDiction getTDictionByVStudentid() {
		return this.TDictionByVStudentid;
	}

	public void setTDictionByVStudentid(TDiction TDictionByVStudentid) {
		this.TDictionByVStudentid = TDictionByVStudentid;
	}

	public TDiction getTDictionByVStuStatusid() {
		return this.TDictionByVStuStatusid;
	}

	public void setTDictionByVStuStatusid(TDiction TDictionByVStuStatusid) {
		this.TDictionByVStuStatusid = TDictionByVStuStatusid;
	}

	public Date getDCreatetime() {
		return this.DCreatetime;
	}

	public void setDCreatetime(Date DCreatetime) {
		this.DCreatetime = DCreatetime;
	}

}