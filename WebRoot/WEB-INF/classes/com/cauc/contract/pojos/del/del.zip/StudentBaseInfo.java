package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * StudentBaseInfo entity. @author MyEclipse Persistence Tools
 */

public class StudentBaseInfo implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDictionByVWhcd;
	private TDiction TDictionByVFreeTypeid;
	private TDiction TDictionByVXjStatusid;
	private TUser TUser;
	private TDiction TDictionByVNationid;
	private TDiction TDictionByVFormid;
	private TDiction TDictionByVStuStatusid;
	private TDiction TDictionByVStuTypeid;
	private TOrg TOrg;
	private String VCode;
	private String VName;
	private String VCardid;
	private String VClassNoid;
	private String VGender;
	private Date DBirthday;
	private String VSyd;
	private Date DRxsj;
	private Date DLxsj;
	private Integer ITjexam;
	private Date DCreatedate;
	private String VJtzz;
	private String VZzmm;
	private String VByyx;
	private String VEnlevel;
	private String VZy;
	private String VXlxz;
	private String VXxlx;
	private String VLxfs;
	private String VJg;
	private Date DBysj;
	private Integer openStatus;
	private Integer IUsertype;
	private Date DTjexamdate;
	private String photo;
	private Set TStuchangedteachers = new HashSet(0);
	private Set practiceTests = new HashSet(0);
	private Set TGntrainbackschools = new HashSet(0);
	private Set TStuassignteachers = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set TGnchangedgws = new HashSet(0);
	private Set TDgdistributions = new HashSet(0);
	private Set TChangedgroups = new HashSet(0);
	private Set TStuMedicals = new HashSet(0);
	private Set TChangedbases = new HashSet(0);
	private Set TFlyreports = new HashSet(0);
	private Set TScores = new HashSet(0);
	private Set addHoursAndAddLessons = new HashSet(0);
	private Set trainingPlanes = new HashSet(0);
	private Set recommendStudentLicenseExams = new HashSet(0);
	private Set studentDistributionClasses = new HashSet(0);
	private Set graduationStudentAssigns = new HashSet(0);
	private Set TLessonFitChecks = new HashSet(0);
	private Set graduationDesigns = new HashSet(0);
	private Set TSchoolchangedbases = new HashSet(0);
	private Set TStuassignbases = new HashSet(0);
	private Set studentassignschools = new HashSet(0);
	private Set TChangedoutlines = new HashSet(0);
	private Set TStustopflies = new HashSet(0);
	private Set studentstatuschanges = new HashSet(0);
	private Set licenseTheoryTests = new HashSet(0);
	private Set TFlightTrainingrecords = new HashSet(0);
	private Set studentLicenses = new HashSet(0);
	private Set changecompanies = new HashSet(0);
	private Set newworkerandchangetrains = new HashSet(0);
	private Set TSendqualificationreviews = new HashSet(0);
	private Set TStuStatuses = new HashSet(0);
	private Set TStuMedicalhistories = new HashSet(0);
	private Set TStuassigngroups = new HashSet(0);
	private Set studentLicensehistories = new HashSet(0);
	private Set TOffschools = new HashSet(0);

	// Constructors

	/** default constructor */
	public StudentBaseInfo() {
	}

	/** minimal constructor */
	public StudentBaseInfo(TUser TUser, String VCode, String VName,
			Date DCreatedate) {
		this.TUser = TUser;
		this.VCode = VCode;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public StudentBaseInfo(TDiction TDictionByVWhcd,
			TDiction TDictionByVFreeTypeid, TDiction TDictionByVXjStatusid,
			TUser TUser, TDiction TDictionByVNationid,
			TDiction TDictionByVFormid, TDiction TDictionByVStuStatusid,
			TDiction TDictionByVStuTypeid, TOrg TOrg, String VCode,
			String VName, String VCardid, String VClassNoid, String VGender,
			Date DBirthday, String VSyd, Date DRxsj, Date DLxsj,
			Integer ITjexam, Date DCreatedate, String VJtzz, String VZzmm,
			String VByyx, String VEnlevel, String VZy, String VXlxz,
			String VXxlx, String VLxfs, String VJg, Date DBysj,
			Integer openStatus, Integer IUsertype, Date DTjexamdate,
			String photo, Set TStuchangedteachers, Set practiceTests,
			Set TGntrainbackschools, Set TStuassignteachers,
			Set THistoryrecords, Set TGnchangedgws, Set TDgdistributions,
			Set TChangedgroups, Set TStuMedicals, Set TChangedbases,
			Set TFlyreports, Set TScores, Set addHoursAndAddLessons,
			Set trainingPlanes, Set recommendStudentLicenseExams,
			Set studentDistributionClasses, Set graduationStudentAssigns,
			Set TLessonFitChecks, Set graduationDesigns,
			Set TSchoolchangedbases, Set TStuassignbases,
			Set studentassignschools, Set TChangedoutlines, Set TStustopflies,
			Set studentstatuschanges, Set licenseTheoryTests,
			Set TFlightTrainingrecords, Set studentLicenses,
			Set changecompanies, Set newworkerandchangetrains,
			Set TSendqualificationreviews, Set TStuStatuses,
			Set TStuMedicalhistories, Set TStuassigngroups,
			Set studentLicensehistories, Set TOffschools) {
		this.TDictionByVWhcd = TDictionByVWhcd;
		this.TDictionByVFreeTypeid = TDictionByVFreeTypeid;
		this.TDictionByVXjStatusid = TDictionByVXjStatusid;
		this.TUser = TUser;
		this.TDictionByVNationid = TDictionByVNationid;
		this.TDictionByVFormid = TDictionByVFormid;
		this.TDictionByVStuStatusid = TDictionByVStuStatusid;
		this.TDictionByVStuTypeid = TDictionByVStuTypeid;
		this.TOrg = TOrg;
		this.VCode = VCode;
		this.VName = VName;
		this.VCardid = VCardid;
		this.VClassNoid = VClassNoid;
		this.VGender = VGender;
		this.DBirthday = DBirthday;
		this.VSyd = VSyd;
		this.DRxsj = DRxsj;
		this.DLxsj = DLxsj;
		this.ITjexam = ITjexam;
		this.DCreatedate = DCreatedate;
		this.VJtzz = VJtzz;
		this.VZzmm = VZzmm;
		this.VByyx = VByyx;
		this.VEnlevel = VEnlevel;
		this.VZy = VZy;
		this.VXlxz = VXlxz;
		this.VXxlx = VXxlx;
		this.VLxfs = VLxfs;
		this.VJg = VJg;
		this.DBysj = DBysj;
		this.openStatus = openStatus;
		this.IUsertype = IUsertype;
		this.DTjexamdate = DTjexamdate;
		this.photo = photo;
		this.TStuchangedteachers = TStuchangedteachers;
		this.practiceTests = practiceTests;
		this.TGntrainbackschools = TGntrainbackschools;
		this.TStuassignteachers = TStuassignteachers;
		this.THistoryrecords = THistoryrecords;
		this.TGnchangedgws = TGnchangedgws;
		this.TDgdistributions = TDgdistributions;
		this.TChangedgroups = TChangedgroups;
		this.TStuMedicals = TStuMedicals;
		this.TChangedbases = TChangedbases;
		this.TFlyreports = TFlyreports;
		this.TScores = TScores;
		this.addHoursAndAddLessons = addHoursAndAddLessons;
		this.trainingPlanes = trainingPlanes;
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
		this.studentDistributionClasses = studentDistributionClasses;
		this.graduationStudentAssigns = graduationStudentAssigns;
		this.TLessonFitChecks = TLessonFitChecks;
		this.graduationDesigns = graduationDesigns;
		this.TSchoolchangedbases = TSchoolchangedbases;
		this.TStuassignbases = TStuassignbases;
		this.studentassignschools = studentassignschools;
		this.TChangedoutlines = TChangedoutlines;
		this.TStustopflies = TStustopflies;
		this.studentstatuschanges = studentstatuschanges;
		this.licenseTheoryTests = licenseTheoryTests;
		this.TFlightTrainingrecords = TFlightTrainingrecords;
		this.studentLicenses = studentLicenses;
		this.changecompanies = changecompanies;
		this.newworkerandchangetrains = newworkerandchangetrains;
		this.TSendqualificationreviews = TSendqualificationreviews;
		this.TStuStatuses = TStuStatuses;
		this.TStuMedicalhistories = TStuMedicalhistories;
		this.TStuassigngroups = TStuassigngroups;
		this.studentLicensehistories = studentLicensehistories;
		this.TOffschools = TOffschools;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDictionByVWhcd() {
		return this.TDictionByVWhcd;
	}

	public void setTDictionByVWhcd(TDiction TDictionByVWhcd) {
		this.TDictionByVWhcd = TDictionByVWhcd;
	}

	public TDiction getTDictionByVFreeTypeid() {
		return this.TDictionByVFreeTypeid;
	}

	public void setTDictionByVFreeTypeid(TDiction TDictionByVFreeTypeid) {
		this.TDictionByVFreeTypeid = TDictionByVFreeTypeid;
	}

	public TDiction getTDictionByVXjStatusid() {
		return this.TDictionByVXjStatusid;
	}

	public void setTDictionByVXjStatusid(TDiction TDictionByVXjStatusid) {
		this.TDictionByVXjStatusid = TDictionByVXjStatusid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TDiction getTDictionByVNationid() {
		return this.TDictionByVNationid;
	}

	public void setTDictionByVNationid(TDiction TDictionByVNationid) {
		this.TDictionByVNationid = TDictionByVNationid;
	}

	public TDiction getTDictionByVFormid() {
		return this.TDictionByVFormid;
	}

	public void setTDictionByVFormid(TDiction TDictionByVFormid) {
		this.TDictionByVFormid = TDictionByVFormid;
	}

	public TDiction getTDictionByVStuStatusid() {
		return this.TDictionByVStuStatusid;
	}

	public void setTDictionByVStuStatusid(TDiction TDictionByVStuStatusid) {
		this.TDictionByVStuStatusid = TDictionByVStuStatusid;
	}

	public TDiction getTDictionByVStuTypeid() {
		return this.TDictionByVStuTypeid;
	}

	public void setTDictionByVStuTypeid(TDiction TDictionByVStuTypeid) {
		this.TDictionByVStuTypeid = TDictionByVStuTypeid;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVCardid() {
		return this.VCardid;
	}

	public void setVCardid(String VCardid) {
		this.VCardid = VCardid;
	}

	public String getVClassNoid() {
		return this.VClassNoid;
	}

	public void setVClassNoid(String VClassNoid) {
		this.VClassNoid = VClassNoid;
	}

	public String getVGender() {
		return this.VGender;
	}

	public void setVGender(String VGender) {
		this.VGender = VGender;
	}

	public Date getDBirthday() {
		return this.DBirthday;
	}

	public void setDBirthday(Date DBirthday) {
		this.DBirthday = DBirthday;
	}

	public String getVSyd() {
		return this.VSyd;
	}

	public void setVSyd(String VSyd) {
		this.VSyd = VSyd;
	}

	public Date getDRxsj() {
		return this.DRxsj;
	}

	public void setDRxsj(Date DRxsj) {
		this.DRxsj = DRxsj;
	}

	public Date getDLxsj() {
		return this.DLxsj;
	}

	public void setDLxsj(Date DLxsj) {
		this.DLxsj = DLxsj;
	}

	public Integer getITjexam() {
		return this.ITjexam;
	}

	public void setITjexam(Integer ITjexam) {
		this.ITjexam = ITjexam;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVJtzz() {
		return this.VJtzz;
	}

	public void setVJtzz(String VJtzz) {
		this.VJtzz = VJtzz;
	}

	public String getVZzmm() {
		return this.VZzmm;
	}

	public void setVZzmm(String VZzmm) {
		this.VZzmm = VZzmm;
	}

	public String getVByyx() {
		return this.VByyx;
	}

	public void setVByyx(String VByyx) {
		this.VByyx = VByyx;
	}

	public String getVEnlevel() {
		return this.VEnlevel;
	}

	public void setVEnlevel(String VEnlevel) {
		this.VEnlevel = VEnlevel;
	}

	public String getVZy() {
		return this.VZy;
	}

	public void setVZy(String VZy) {
		this.VZy = VZy;
	}

	public String getVXlxz() {
		return this.VXlxz;
	}

	public void setVXlxz(String VXlxz) {
		this.VXlxz = VXlxz;
	}

	public String getVXxlx() {
		return this.VXxlx;
	}

	public void setVXxlx(String VXxlx) {
		this.VXxlx = VXxlx;
	}

	public String getVLxfs() {
		return this.VLxfs;
	}

	public void setVLxfs(String VLxfs) {
		this.VLxfs = VLxfs;
	}

	public String getVJg() {
		return this.VJg;
	}

	public void setVJg(String VJg) {
		this.VJg = VJg;
	}

	public Date getDBysj() {
		return this.DBysj;
	}

	public void setDBysj(Date DBysj) {
		this.DBysj = DBysj;
	}

	public Integer getOpenStatus() {
		return this.openStatus;
	}

	public void setOpenStatus(Integer openStatus) {
		this.openStatus = openStatus;
	}

	public Integer getIUsertype() {
		return this.IUsertype;
	}

	public void setIUsertype(Integer IUsertype) {
		this.IUsertype = IUsertype;
	}

	public Date getDTjexamdate() {
		return this.DTjexamdate;
	}

	public void setDTjexamdate(Date DTjexamdate) {
		this.DTjexamdate = DTjexamdate;
	}

	public String getPhoto() {
		return this.photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public Set getTStuchangedteachers() {
		return this.TStuchangedteachers;
	}

	public void setTStuchangedteachers(Set TStuchangedteachers) {
		this.TStuchangedteachers = TStuchangedteachers;
	}

	public Set getPracticeTests() {
		return this.practiceTests;
	}

	public void setPracticeTests(Set practiceTests) {
		this.practiceTests = practiceTests;
	}

	public Set getTGntrainbackschools() {
		return this.TGntrainbackschools;
	}

	public void setTGntrainbackschools(Set TGntrainbackschools) {
		this.TGntrainbackschools = TGntrainbackschools;
	}

	public Set getTStuassignteachers() {
		return this.TStuassignteachers;
	}

	public void setTStuassignteachers(Set TStuassignteachers) {
		this.TStuassignteachers = TStuassignteachers;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getTGnchangedgws() {
		return this.TGnchangedgws;
	}

	public void setTGnchangedgws(Set TGnchangedgws) {
		this.TGnchangedgws = TGnchangedgws;
	}

	public Set getTDgdistributions() {
		return this.TDgdistributions;
	}

	public void setTDgdistributions(Set TDgdistributions) {
		this.TDgdistributions = TDgdistributions;
	}

	public Set getTChangedgroups() {
		return this.TChangedgroups;
	}

	public void setTChangedgroups(Set TChangedgroups) {
		this.TChangedgroups = TChangedgroups;
	}

	public Set getTStuMedicals() {
		return this.TStuMedicals;
	}

	public void setTStuMedicals(Set TStuMedicals) {
		this.TStuMedicals = TStuMedicals;
	}

	public Set getTChangedbases() {
		return this.TChangedbases;
	}

	public void setTChangedbases(Set TChangedbases) {
		this.TChangedbases = TChangedbases;
	}

	public Set getTFlyreports() {
		return this.TFlyreports;
	}

	public void setTFlyreports(Set TFlyreports) {
		this.TFlyreports = TFlyreports;
	}

	public Set getTScores() {
		return this.TScores;
	}

	public void setTScores(Set TScores) {
		this.TScores = TScores;
	}

	public Set getAddHoursAndAddLessons() {
		return this.addHoursAndAddLessons;
	}

	public void setAddHoursAndAddLessons(Set addHoursAndAddLessons) {
		this.addHoursAndAddLessons = addHoursAndAddLessons;
	}

	public Set getTrainingPlanes() {
		return this.trainingPlanes;
	}

	public void setTrainingPlanes(Set trainingPlanes) {
		this.trainingPlanes = trainingPlanes;
	}

	public Set getRecommendStudentLicenseExams() {
		return this.recommendStudentLicenseExams;
	}

	public void setRecommendStudentLicenseExams(Set recommendStudentLicenseExams) {
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
	}

	public Set getStudentDistributionClasses() {
		return this.studentDistributionClasses;
	}

	public void setStudentDistributionClasses(Set studentDistributionClasses) {
		this.studentDistributionClasses = studentDistributionClasses;
	}

	public Set getGraduationStudentAssigns() {
		return this.graduationStudentAssigns;
	}

	public void setGraduationStudentAssigns(Set graduationStudentAssigns) {
		this.graduationStudentAssigns = graduationStudentAssigns;
	}

	public Set getTLessonFitChecks() {
		return this.TLessonFitChecks;
	}

	public void setTLessonFitChecks(Set TLessonFitChecks) {
		this.TLessonFitChecks = TLessonFitChecks;
	}

	public Set getGraduationDesigns() {
		return this.graduationDesigns;
	}

	public void setGraduationDesigns(Set graduationDesigns) {
		this.graduationDesigns = graduationDesigns;
	}

	public Set getTSchoolchangedbases() {
		return this.TSchoolchangedbases;
	}

	public void setTSchoolchangedbases(Set TSchoolchangedbases) {
		this.TSchoolchangedbases = TSchoolchangedbases;
	}

	public Set getTStuassignbases() {
		return this.TStuassignbases;
	}

	public void setTStuassignbases(Set TStuassignbases) {
		this.TStuassignbases = TStuassignbases;
	}

	public Set getStudentassignschools() {
		return this.studentassignschools;
	}

	public void setStudentassignschools(Set studentassignschools) {
		this.studentassignschools = studentassignschools;
	}

	public Set getTChangedoutlines() {
		return this.TChangedoutlines;
	}

	public void setTChangedoutlines(Set TChangedoutlines) {
		this.TChangedoutlines = TChangedoutlines;
	}

	public Set getTStustopflies() {
		return this.TStustopflies;
	}

	public void setTStustopflies(Set TStustopflies) {
		this.TStustopflies = TStustopflies;
	}

	public Set getStudentstatuschanges() {
		return this.studentstatuschanges;
	}

	public void setStudentstatuschanges(Set studentstatuschanges) {
		this.studentstatuschanges = studentstatuschanges;
	}

	public Set getLicenseTheoryTests() {
		return this.licenseTheoryTests;
	}

	public void setLicenseTheoryTests(Set licenseTheoryTests) {
		this.licenseTheoryTests = licenseTheoryTests;
	}

	public Set getTFlightTrainingrecords() {
		return this.TFlightTrainingrecords;
	}

	public void setTFlightTrainingrecords(Set TFlightTrainingrecords) {
		this.TFlightTrainingrecords = TFlightTrainingrecords;
	}

	public Set getStudentLicenses() {
		return this.studentLicenses;
	}

	public void setStudentLicenses(Set studentLicenses) {
		this.studentLicenses = studentLicenses;
	}

	public Set getChangecompanies() {
		return this.changecompanies;
	}

	public void setChangecompanies(Set changecompanies) {
		this.changecompanies = changecompanies;
	}

	public Set getNewworkerandchangetrains() {
		return this.newworkerandchangetrains;
	}

	public void setNewworkerandchangetrains(Set newworkerandchangetrains) {
		this.newworkerandchangetrains = newworkerandchangetrains;
	}

	public Set getTSendqualificationreviews() {
		return this.TSendqualificationreviews;
	}

	public void setTSendqualificationreviews(Set TSendqualificationreviews) {
		this.TSendqualificationreviews = TSendqualificationreviews;
	}

	public Set getTStuStatuses() {
		return this.TStuStatuses;
	}

	public void setTStuStatuses(Set TStuStatuses) {
		this.TStuStatuses = TStuStatuses;
	}

	public Set getTStuMedicalhistories() {
		return this.TStuMedicalhistories;
	}

	public void setTStuMedicalhistories(Set TStuMedicalhistories) {
		this.TStuMedicalhistories = TStuMedicalhistories;
	}

	public Set getTStuassigngroups() {
		return this.TStuassigngroups;
	}

	public void setTStuassigngroups(Set TStuassigngroups) {
		this.TStuassigngroups = TStuassigngroups;
	}

	public Set getStudentLicensehistories() {
		return this.studentLicensehistories;
	}

	public void setStudentLicensehistories(Set studentLicensehistories) {
		this.studentLicensehistories = studentLicensehistories;
	}

	public Set getTOffschools() {
		return this.TOffschools;
	}

	public void setTOffschools(Set TOffschools) {
		this.TOffschools = TOffschools;
	}

}