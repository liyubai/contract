package com.cauc.training.pojos;

import java.util.Date;

/**
 * StudentDistributionClass entity. @author MyEclipse Persistence Tools
 */

public class StudentDistributionClass implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TSetClass TSetClass;
	private StudentBaseInfo studentBaseInfo;
	private Date DAssigntime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public StudentDistributionClass() {
	}

	/** minimal constructor */
	public StudentDistributionClass(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public StudentDistributionClass(TUser TUser, TSetClass TSetClass,
			StudentBaseInfo studentBaseInfo, Date DAssigntime, Date DCreatedate) {
		this.TUser = TUser;
		this.TSetClass = TSetClass;
		this.studentBaseInfo = studentBaseInfo;
		this.DAssigntime = DAssigntime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TSetClass getTSetClass() {
		return this.TSetClass;
	}

	public void setTSetClass(TSetClass TSetClass) {
		this.TSetClass = TSetClass;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDAssigntime() {
		return this.DAssigntime;
	}

	public void setDAssigntime(Date DAssigntime) {
		this.DAssigntime = DAssigntime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}