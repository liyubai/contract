package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * StudentLicense entity. @author MyEclipse Persistence Tools
 */

public class StudentLicense implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDiction;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private String VCardid;
	private Date DEffectdate;
	private String VIssuer;
	private String VCompany;
	private Date DIssuetime;
	private Date DUpdatedate;
	private String VZhizhaoxingzhi;
	private String VZhizhaodengji;
	private String VHangkongqileibie;
	private String VXuanzhuanjijibie;
	private String VFeijijibie;
	private String VHkqdj;
	private String VBeizhu;
	private Date DLastchecktime;
	private Date DChecktime;
	private Date DExamtime;
	private Date DNextchecktime;
	private Date DCreatedate;
	private Set studentLicenseskilledchecks = new HashSet(0);
	private Set studentLicensehistories = new HashSet(0);

	// Constructors

	/** default constructor */
	public StudentLicense() {
	}

	/** minimal constructor */
	public StudentLicense(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public StudentLicense(TDiction TDiction, TUser TUser,
			StudentBaseInfo studentBaseInfo, String VCardid, Date DEffectdate,
			String VIssuer, String VCompany, Date DIssuetime, Date DUpdatedate,
			String VZhizhaoxingzhi, String VZhizhaodengji,
			String VHangkongqileibie, String VXuanzhuanjijibie,
			String VFeijijibie, String VHkqdj, String VBeizhu,
			Date DLastchecktime, Date DChecktime, Date DExamtime,
			Date DNextchecktime, Date DCreatedate,
			Set studentLicenseskilledchecks, Set studentLicensehistories) {
		this.TDiction = TDiction;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.VCardid = VCardid;
		this.DEffectdate = DEffectdate;
		this.VIssuer = VIssuer;
		this.VCompany = VCompany;
		this.DIssuetime = DIssuetime;
		this.DUpdatedate = DUpdatedate;
		this.VZhizhaoxingzhi = VZhizhaoxingzhi;
		this.VZhizhaodengji = VZhizhaodengji;
		this.VHangkongqileibie = VHangkongqileibie;
		this.VXuanzhuanjijibie = VXuanzhuanjijibie;
		this.VFeijijibie = VFeijijibie;
		this.VHkqdj = VHkqdj;
		this.VBeizhu = VBeizhu;
		this.DLastchecktime = DLastchecktime;
		this.DChecktime = DChecktime;
		this.DExamtime = DExamtime;
		this.DNextchecktime = DNextchecktime;
		this.DCreatedate = DCreatedate;
		this.studentLicenseskilledchecks = studentLicenseskilledchecks;
		this.studentLicensehistories = studentLicensehistories;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public String getVCardid() {
		return this.VCardid;
	}

	public void setVCardid(String VCardid) {
		this.VCardid = VCardid;
	}

	public Date getDEffectdate() {
		return this.DEffectdate;
	}

	public void setDEffectdate(Date DEffectdate) {
		this.DEffectdate = DEffectdate;
	}

	public String getVIssuer() {
		return this.VIssuer;
	}

	public void setVIssuer(String VIssuer) {
		this.VIssuer = VIssuer;
	}

	public String getVCompany() {
		return this.VCompany;
	}

	public void setVCompany(String VCompany) {
		this.VCompany = VCompany;
	}

	public Date getDIssuetime() {
		return this.DIssuetime;
	}

	public void setDIssuetime(Date DIssuetime) {
		this.DIssuetime = DIssuetime;
	}

	public Date getDUpdatedate() {
		return this.DUpdatedate;
	}

	public void setDUpdatedate(Date DUpdatedate) {
		this.DUpdatedate = DUpdatedate;
	}

	public String getVZhizhaoxingzhi() {
		return this.VZhizhaoxingzhi;
	}

	public void setVZhizhaoxingzhi(String VZhizhaoxingzhi) {
		this.VZhizhaoxingzhi = VZhizhaoxingzhi;
	}

	public String getVZhizhaodengji() {
		return this.VZhizhaodengji;
	}

	public void setVZhizhaodengji(String VZhizhaodengji) {
		this.VZhizhaodengji = VZhizhaodengji;
	}

	public String getVHangkongqileibie() {
		return this.VHangkongqileibie;
	}

	public void setVHangkongqileibie(String VHangkongqileibie) {
		this.VHangkongqileibie = VHangkongqileibie;
	}

	public String getVXuanzhuanjijibie() {
		return this.VXuanzhuanjijibie;
	}

	public void setVXuanzhuanjijibie(String VXuanzhuanjijibie) {
		this.VXuanzhuanjijibie = VXuanzhuanjijibie;
	}

	public String getVFeijijibie() {
		return this.VFeijijibie;
	}

	public void setVFeijijibie(String VFeijijibie) {
		this.VFeijijibie = VFeijijibie;
	}

	public String getVHkqdj() {
		return this.VHkqdj;
	}

	public void setVHkqdj(String VHkqdj) {
		this.VHkqdj = VHkqdj;
	}

	public String getVBeizhu() {
		return this.VBeizhu;
	}

	public void setVBeizhu(String VBeizhu) {
		this.VBeizhu = VBeizhu;
	}

	public Date getDLastchecktime() {
		return this.DLastchecktime;
	}

	public void setDLastchecktime(Date DLastchecktime) {
		this.DLastchecktime = DLastchecktime;
	}

	public Date getDChecktime() {
		return this.DChecktime;
	}

	public void setDChecktime(Date DChecktime) {
		this.DChecktime = DChecktime;
	}

	public Date getDExamtime() {
		return this.DExamtime;
	}

	public void setDExamtime(Date DExamtime) {
		this.DExamtime = DExamtime;
	}

	public Date getDNextchecktime() {
		return this.DNextchecktime;
	}

	public void setDNextchecktime(Date DNextchecktime) {
		this.DNextchecktime = DNextchecktime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getStudentLicenseskilledchecks() {
		return this.studentLicenseskilledchecks;
	}

	public void setStudentLicenseskilledchecks(Set studentLicenseskilledchecks) {
		this.studentLicenseskilledchecks = studentLicenseskilledchecks;
	}

	public Set getStudentLicensehistories() {
		return this.studentLicensehistories;
	}

	public void setStudentLicensehistories(Set studentLicensehistories) {
		this.studentLicensehistories = studentLicensehistories;
	}

}