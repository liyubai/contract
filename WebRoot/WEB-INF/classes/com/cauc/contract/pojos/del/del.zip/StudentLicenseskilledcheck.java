package com.cauc.training.pojos;

import java.util.Date;

/**
 * StudentLicenseskilledcheck entity. @author MyEclipse Persistence Tools
 */

public class StudentLicenseskilledcheck implements java.io.Serializable {

	// Fields

	private String VId;
	private StudentLicensehistory studentLicensehistory;
	private StudentLicense studentLicense;
	private TUser TUser;
	private Date DCheckdate;
	private String VCheckcontent;
	private String VCheckteacher;
	private String VBz;
	private Date DEffectdate;
	private String VFlyform;
	private Integer IChecktype;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public StudentLicenseskilledcheck() {
	}

	/** minimal constructor */
	public StudentLicenseskilledcheck(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public StudentLicenseskilledcheck(
			StudentLicensehistory studentLicensehistory,
			StudentLicense studentLicense, TUser TUser, Date DCheckdate,
			String VCheckcontent, String VCheckteacher, String VBz,
			Date DEffectdate, String VFlyform, Integer IChecktype,
			Date DCreatedate) {
		this.studentLicensehistory = studentLicensehistory;
		this.studentLicense = studentLicense;
		this.TUser = TUser;
		this.DCheckdate = DCheckdate;
		this.VCheckcontent = VCheckcontent;
		this.VCheckteacher = VCheckteacher;
		this.VBz = VBz;
		this.DEffectdate = DEffectdate;
		this.VFlyform = VFlyform;
		this.IChecktype = IChecktype;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public StudentLicensehistory getStudentLicensehistory() {
		return this.studentLicensehistory;
	}

	public void setStudentLicensehistory(
			StudentLicensehistory studentLicensehistory) {
		this.studentLicensehistory = studentLicensehistory;
	}

	public StudentLicense getStudentLicense() {
		return this.studentLicense;
	}

	public void setStudentLicense(StudentLicense studentLicense) {
		this.studentLicense = studentLicense;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDCheckdate() {
		return this.DCheckdate;
	}

	public void setDCheckdate(Date DCheckdate) {
		this.DCheckdate = DCheckdate;
	}

	public String getVCheckcontent() {
		return this.VCheckcontent;
	}

	public void setVCheckcontent(String VCheckcontent) {
		this.VCheckcontent = VCheckcontent;
	}

	public String getVCheckteacher() {
		return this.VCheckteacher;
	}

	public void setVCheckteacher(String VCheckteacher) {
		this.VCheckteacher = VCheckteacher;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Date getDEffectdate() {
		return this.DEffectdate;
	}

	public void setDEffectdate(Date DEffectdate) {
		this.DEffectdate = DEffectdate;
	}

	public String getVFlyform() {
		return this.VFlyform;
	}

	public void setVFlyform(String VFlyform) {
		this.VFlyform = VFlyform;
	}

	public Integer getIChecktype() {
		return this.IChecktype;
	}

	public void setIChecktype(Integer IChecktype) {
		this.IChecktype = IChecktype;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}