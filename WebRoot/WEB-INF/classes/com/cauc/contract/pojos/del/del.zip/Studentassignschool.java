package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Studentassignschool entity. @author MyEclipse Persistence Tools
 */

public class Studentassignschool implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TAbroadaviationschool TAbroadaviationschool;
	private StudentBaseInfo studentBaseInfo;
	private Date DCreatedate;
	private Set TForeignaviationschoolinterviews = new HashSet(0);
	private Set TAbroadtrains = new HashSet(0);

	// Constructors

	/** default constructor */
	public Studentassignschool() {
	}

	/** minimal constructor */
	public Studentassignschool(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public Studentassignschool(TUser TUser,
			TAbroadaviationschool TAbroadaviationschool,
			StudentBaseInfo studentBaseInfo, Date DCreatedate,
			Set TForeignaviationschoolinterviews, Set TAbroadtrains) {
		this.TUser = TUser;
		this.TAbroadaviationschool = TAbroadaviationschool;
		this.studentBaseInfo = studentBaseInfo;
		this.DCreatedate = DCreatedate;
		this.TForeignaviationschoolinterviews = TForeignaviationschoolinterviews;
		this.TAbroadtrains = TAbroadtrains;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TAbroadaviationschool getTAbroadaviationschool() {
		return this.TAbroadaviationschool;
	}

	public void setTAbroadaviationschool(
			TAbroadaviationschool TAbroadaviationschool) {
		this.TAbroadaviationschool = TAbroadaviationschool;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTForeignaviationschoolinterviews() {
		return this.TForeignaviationschoolinterviews;
	}

	public void setTForeignaviationschoolinterviews(
			Set TForeignaviationschoolinterviews) {
		this.TForeignaviationschoolinterviews = TForeignaviationschoolinterviews;
	}

	public Set getTAbroadtrains() {
		return this.TAbroadtrains;
	}

	public void setTAbroadtrains(Set TAbroadtrains) {
		this.TAbroadtrains = TAbroadtrains;
	}

}