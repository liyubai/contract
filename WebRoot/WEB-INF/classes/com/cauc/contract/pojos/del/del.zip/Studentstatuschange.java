package com.cauc.training.pojos;

import java.util.Date;

/**
 * Studentstatuschange entity. @author MyEclipse Persistence Tools
 */

public class Studentstatuschange implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDictionByVOldStatusid;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private TDiction TDictionByVNewstatusid;
	private Date DChangedtime;
	private String VComment;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public Studentstatuschange() {
	}

	/** minimal constructor */
	public Studentstatuschange(TDiction TDictionByVOldStatusid, TUser TUser,
			Date DCreatedate) {
		this.TDictionByVOldStatusid = TDictionByVOldStatusid;
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public Studentstatuschange(TDiction TDictionByVOldStatusid, TUser TUser,
			StudentBaseInfo studentBaseInfo, TDiction TDictionByVNewstatusid,
			Date DChangedtime, String VComment, Date DCreatedate) {
		this.TDictionByVOldStatusid = TDictionByVOldStatusid;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.TDictionByVNewstatusid = TDictionByVNewstatusid;
		this.DChangedtime = DChangedtime;
		this.VComment = VComment;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDictionByVOldStatusid() {
		return this.TDictionByVOldStatusid;
	}

	public void setTDictionByVOldStatusid(TDiction TDictionByVOldStatusid) {
		this.TDictionByVOldStatusid = TDictionByVOldStatusid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TDiction getTDictionByVNewstatusid() {
		return this.TDictionByVNewstatusid;
	}

	public void setTDictionByVNewstatusid(TDiction TDictionByVNewstatusid) {
		this.TDictionByVNewstatusid = TDictionByVNewstatusid;
	}

	public Date getDChangedtime() {
		return this.DChangedtime;
	}

	public void setDChangedtime(Date DChangedtime) {
		this.DChangedtime = DChangedtime;
	}

	public String getVComment() {
		return this.VComment;
	}

	public void setVComment(String VComment) {
		this.VComment = VComment;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}