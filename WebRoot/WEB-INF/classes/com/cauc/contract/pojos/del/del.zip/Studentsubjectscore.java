package com.cauc.training.pojos;

import java.util.Date;

/**
 * Studentsubjectscore entity. @author MyEclipse Persistence Tools
 */

public class Studentsubjectscore implements java.io.Serializable {

	// Fields

	private String VId;
	private TTrainsubject TTrainsubject;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private TUser TUser;
	private double DActscore;
	private Date DCreatedate;
	private Integer IIsused;

	// Constructors

	/** default constructor */
	public Studentsubjectscore() {
	}

	/** full constructor */
	public Studentsubjectscore(TTrainsubject TTrainsubject,
			TFlightTrainingrecord TFlightTrainingrecord, TUser TUser,
			double DActscore, Date DCreatedate, Integer IIsused) {
		this.TTrainsubject = TTrainsubject;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.TUser = TUser;
		this.DActscore = DActscore;
		this.DCreatedate = DCreatedate;
		this.IIsused = IIsused;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TTrainsubject getTTrainsubject() {
		return this.TTrainsubject;
	}

	public void setTTrainsubject(TTrainsubject TTrainsubject) {
		this.TTrainsubject = TTrainsubject;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public double getDActscore() {
		return this.DActscore;
	}

	public void setDActscore(double DActscore) {
		this.DActscore = DActscore;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIIsused() {
		return this.IIsused;
	}

	public void setIIsused(Integer IIsused) {
		this.IIsused = IIsused;
	}

}