package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TAbroadaviationschool entity. @author MyEclipse Persistence Tools
 */

public class TAbroadaviationschool implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VSchoolname;
	private String VIntroduction;
	private Date DCreatedate;
	private String VCountry;
	private String VAddress;
	private String VWeb;
	private String VCode;
	private Date DEffectdate;
	private Set studentassignschools = new HashSet(0);

	// Constructors

	/** default constructor */
	public TAbroadaviationschool() {
	}

	/** minimal constructor */
	public TAbroadaviationschool(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TAbroadaviationschool(TUser TUser, String VSchoolname,
			String VIntroduction, Date DCreatedate, String VCountry,
			String VAddress, String VWeb, String VCode, Date DEffectdate,
			Set studentassignschools) {
		this.TUser = TUser;
		this.VSchoolname = VSchoolname;
		this.VIntroduction = VIntroduction;
		this.DCreatedate = DCreatedate;
		this.VCountry = VCountry;
		this.VAddress = VAddress;
		this.VWeb = VWeb;
		this.VCode = VCode;
		this.DEffectdate = DEffectdate;
		this.studentassignschools = studentassignschools;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVSchoolname() {
		return this.VSchoolname;
	}

	public void setVSchoolname(String VSchoolname) {
		this.VSchoolname = VSchoolname;
	}

	public String getVIntroduction() {
		return this.VIntroduction;
	}

	public void setVIntroduction(String VIntroduction) {
		this.VIntroduction = VIntroduction;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVCountry() {
		return this.VCountry;
	}

	public void setVCountry(String VCountry) {
		this.VCountry = VCountry;
	}

	public String getVAddress() {
		return this.VAddress;
	}

	public void setVAddress(String VAddress) {
		this.VAddress = VAddress;
	}

	public String getVWeb() {
		return this.VWeb;
	}

	public void setVWeb(String VWeb) {
		this.VWeb = VWeb;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public Date getDEffectdate() {
		return this.DEffectdate;
	}

	public void setDEffectdate(Date DEffectdate) {
		this.DEffectdate = DEffectdate;
	}

	public Set getStudentassignschools() {
		return this.studentassignschools;
	}

	public void setStudentassignschools(Set studentassignschools) {
		this.studentassignschools = studentassignschools;
	}

}