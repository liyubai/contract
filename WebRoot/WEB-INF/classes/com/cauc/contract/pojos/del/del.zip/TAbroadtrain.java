package com.cauc.training.pojos;

import java.util.Date;

/**
 * TAbroadtrain entity. @author MyEclipse Persistence Tools
 */

public class TAbroadtrain implements java.io.Serializable {

	// Fields

	private String VId;
	private Studentassignschool studentassignschool;
	private TUser TUser;
	private Date DCgtime;
	private Date DHgtime;
	private Date DStopflyaudittime;
	private Date DStopflytime;
	private String VReason;
	private Date DBkschool;
	private Integer IStatus;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TAbroadtrain() {
	}

	/** minimal constructor */
	public TAbroadtrain(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TAbroadtrain(Studentassignschool studentassignschool, TUser TUser,
			Date DCgtime, Date DHgtime, Date DStopflyaudittime,
			Date DStopflytime, String VReason, Date DBkschool, Integer IStatus,
			Date DCreatedate) {
		this.studentassignschool = studentassignschool;
		this.TUser = TUser;
		this.DCgtime = DCgtime;
		this.DHgtime = DHgtime;
		this.DStopflyaudittime = DStopflyaudittime;
		this.DStopflytime = DStopflytime;
		this.VReason = VReason;
		this.DBkschool = DBkschool;
		this.IStatus = IStatus;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Studentassignschool getStudentassignschool() {
		return this.studentassignschool;
	}

	public void setStudentassignschool(Studentassignschool studentassignschool) {
		this.studentassignschool = studentassignschool;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDCgtime() {
		return this.DCgtime;
	}

	public void setDCgtime(Date DCgtime) {
		this.DCgtime = DCgtime;
	}

	public Date getDHgtime() {
		return this.DHgtime;
	}

	public void setDHgtime(Date DHgtime) {
		this.DHgtime = DHgtime;
	}

	public Date getDStopflyaudittime() {
		return this.DStopflyaudittime;
	}

	public void setDStopflyaudittime(Date DStopflyaudittime) {
		this.DStopflyaudittime = DStopflyaudittime;
	}

	public Date getDStopflytime() {
		return this.DStopflytime;
	}

	public void setDStopflytime(Date DStopflytime) {
		this.DStopflytime = DStopflytime;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDBkschool() {
		return this.DBkschool;
	}

	public void setDBkschool(Date DBkschool) {
		this.DBkschool = DBkschool;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}