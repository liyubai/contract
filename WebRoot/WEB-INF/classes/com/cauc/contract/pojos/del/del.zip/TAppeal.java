package com.cauc.training.pojos;

import java.util.Date;

/**
 * TAppeal entity. @author MyEclipse Persistence Tools
 */

public class TAppeal implements java.io.Serializable {

	// Fields

	private String VId;
	private TComment TComment;
	private TUser TUserByVCreateuserid;
	private TUser TUserByVDowithuserid;
	private String VReason;
	private Date DCreatedate;
	private String VResult;
	private Date DDowithtime;
	private Integer IStatus;

	// Constructors

	/** default constructor */
	public TAppeal() {
	}

	/** minimal constructor */
	public TAppeal(TUser TUserByVCreateuserid, Date DCreatedate) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TAppeal(TComment TComment, TUser TUserByVCreateuserid,
			TUser TUserByVDowithuserid, String VReason, Date DCreatedate,
			String VResult, Date DDowithtime, Integer IStatus) {
		this.TComment = TComment;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.TUserByVDowithuserid = TUserByVDowithuserid;
		this.VReason = VReason;
		this.DCreatedate = DCreatedate;
		this.VResult = VResult;
		this.DDowithtime = DDowithtime;
		this.IStatus = IStatus;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TComment getTComment() {
		return this.TComment;
	}

	public void setTComment(TComment TComment) {
		this.TComment = TComment;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public TUser getTUserByVDowithuserid() {
		return this.TUserByVDowithuserid;
	}

	public void setTUserByVDowithuserid(TUser TUserByVDowithuserid) {
		this.TUserByVDowithuserid = TUserByVDowithuserid;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVResult() {
		return this.VResult;
	}

	public void setVResult(String VResult) {
		this.VResult = VResult;
	}

	public Date getDDowithtime() {
		return this.DDowithtime;
	}

	public void setDDowithtime(Date DDowithtime) {
		this.DDowithtime = DDowithtime;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

}