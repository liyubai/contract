package com.cauc.training.pojos;

import java.util.Date;

/**
 * TChangedbase entity. @author MyEclipse Persistence Tools
 */

public class TChangedbase implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TOrg TOrgByVOldbaseid;
	private StudentBaseInfo studentBaseInfo;
	private TOrg TOrgByVNewbaseid;
	private Date DChangedtime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TChangedbase() {
	}

	/** minimal constructor */
	public TChangedbase(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TChangedbase(TUser TUser, TOrg TOrgByVOldbaseid,
			StudentBaseInfo studentBaseInfo, TOrg TOrgByVNewbaseid,
			Date DChangedtime, Date DCreatedate) {
		this.TUser = TUser;
		this.TOrgByVOldbaseid = TOrgByVOldbaseid;
		this.studentBaseInfo = studentBaseInfo;
		this.TOrgByVNewbaseid = TOrgByVNewbaseid;
		this.DChangedtime = DChangedtime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TOrg getTOrgByVOldbaseid() {
		return this.TOrgByVOldbaseid;
	}

	public void setTOrgByVOldbaseid(TOrg TOrgByVOldbaseid) {
		this.TOrgByVOldbaseid = TOrgByVOldbaseid;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TOrg getTOrgByVNewbaseid() {
		return this.TOrgByVNewbaseid;
	}

	public void setTOrgByVNewbaseid(TOrg TOrgByVNewbaseid) {
		this.TOrgByVNewbaseid = TOrgByVNewbaseid;
	}

	public Date getDChangedtime() {
		return this.DChangedtime;
	}

	public void setDChangedtime(Date DChangedtime) {
		this.DChangedtime = DChangedtime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}