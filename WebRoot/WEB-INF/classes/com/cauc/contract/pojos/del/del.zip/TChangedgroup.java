package com.cauc.training.pojos;

import java.util.Date;

/**
 * TChangedgroup entity. @author MyEclipse Persistence Tools
 */

public class TChangedgroup implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrgByVOldgroup;
	private TUser TUser;
	private TOrg TOrgByVNewgroup;
	private StudentBaseInfo studentBaseInfo;
	private Date DChangedtime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TChangedgroup() {
	}

	/** minimal constructor */
	public TChangedgroup(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TChangedgroup(TOrg TOrgByVOldgroup, TUser TUser,
			TOrg TOrgByVNewgroup, StudentBaseInfo studentBaseInfo,
			Date DChangedtime, Date DCreatedate) {
		this.TOrgByVOldgroup = TOrgByVOldgroup;
		this.TUser = TUser;
		this.TOrgByVNewgroup = TOrgByVNewgroup;
		this.studentBaseInfo = studentBaseInfo;
		this.DChangedtime = DChangedtime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrgByVOldgroup() {
		return this.TOrgByVOldgroup;
	}

	public void setTOrgByVOldgroup(TOrg TOrgByVOldgroup) {
		this.TOrgByVOldgroup = TOrgByVOldgroup;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TOrg getTOrgByVNewgroup() {
		return this.TOrgByVNewgroup;
	}

	public void setTOrgByVNewgroup(TOrg TOrgByVNewgroup) {
		this.TOrgByVNewgroup = TOrgByVNewgroup;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDChangedtime() {
		return this.DChangedtime;
	}

	public void setDChangedtime(Date DChangedtime) {
		this.DChangedtime = DChangedtime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}