package com.cauc.training.pojos;

import java.util.Date;

/**
 * TChangedoutline entity. @author MyEclipse Persistence Tools
 */

public class TChangedoutline implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutlineByVOlddgid;
	private TOutline TOutlineByVNewdgid;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DChangeddate;
	private Date DCreatedate;
	private Integer ICycle;
	private Integer IType;
	private String VContact;

	// Constructors

	/** default constructor */
	public TChangedoutline() {
	}

	/** minimal constructor */
	public TChangedoutline(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TChangedoutline(TOutline TOutlineByVOlddgid,
			TOutline TOutlineByVNewdgid, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DChangeddate,
			Date DCreatedate, Integer ICycle, Integer IType, String VContact) {
		this.TOutlineByVOlddgid = TOutlineByVOlddgid;
		this.TOutlineByVNewdgid = TOutlineByVNewdgid;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DChangeddate = DChangeddate;
		this.DCreatedate = DCreatedate;
		this.ICycle = ICycle;
		this.IType = IType;
		this.VContact = VContact;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutlineByVOlddgid() {
		return this.TOutlineByVOlddgid;
	}

	public void setTOutlineByVOlddgid(TOutline TOutlineByVOlddgid) {
		this.TOutlineByVOlddgid = TOutlineByVOlddgid;
	}

	public TOutline getTOutlineByVNewdgid() {
		return this.TOutlineByVNewdgid;
	}

	public void setTOutlineByVNewdgid(TOutline TOutlineByVNewdgid) {
		this.TOutlineByVNewdgid = TOutlineByVNewdgid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDChangeddate() {
		return this.DChangeddate;
	}

	public void setDChangeddate(Date DChangeddate) {
		this.DChangeddate = DChangeddate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getICycle() {
		return this.ICycle;
	}

	public void setICycle(Integer ICycle) {
		this.ICycle = ICycle;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public String getVContact() {
		return this.VContact;
	}

	public void setVContact(String VContact) {
		this.VContact = VContact;
	}

}