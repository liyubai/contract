package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TComment entity. @author MyEclipse Persistence Tools
 */

public class TComment implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private String VComment;
	private Date DCreatedate;
	private Integer IStatus;
	private String VJishu;
	private String VZongjie;
	private Integer IPass;
	private String VCheckcomment;
	private Integer IZpzb;
	private Integer IZpjs;
	private Integer IZp;
	private Set TAppeals = new HashSet(0);

	// Constructors

	/** default constructor */
	public TComment() {
	}

	/** minimal constructor */
	public TComment(TUser TUser, TFlightTrainingrecord TFlightTrainingrecord,
			String VComment, Date DCreatedate, Integer IStatus) {
		this.TUser = TUser;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.VComment = VComment;
		this.DCreatedate = DCreatedate;
		this.IStatus = IStatus;
	}

	/** full constructor */
	public TComment(TUser TUser, TFlightTrainingrecord TFlightTrainingrecord,
			String VComment, Date DCreatedate, Integer IStatus, String VJishu,
			String VZongjie, Integer IPass, String VCheckcomment,
			Integer IZpzb, Integer IZpjs, Integer IZp, Set TAppeals) {
		this.TUser = TUser;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.VComment = VComment;
		this.DCreatedate = DCreatedate;
		this.IStatus = IStatus;
		this.VJishu = VJishu;
		this.VZongjie = VZongjie;
		this.IPass = IPass;
		this.VCheckcomment = VCheckcomment;
		this.IZpzb = IZpzb;
		this.IZpjs = IZpjs;
		this.IZp = IZp;
		this.TAppeals = TAppeals;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public String getVComment() {
		return this.VComment;
	}

	public void setVComment(String VComment) {
		this.VComment = VComment;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public String getVJishu() {
		return this.VJishu;
	}

	public void setVJishu(String VJishu) {
		this.VJishu = VJishu;
	}

	public String getVZongjie() {
		return this.VZongjie;
	}

	public void setVZongjie(String VZongjie) {
		this.VZongjie = VZongjie;
	}

	public Integer getIPass() {
		return this.IPass;
	}

	public void setIPass(Integer IPass) {
		this.IPass = IPass;
	}

	public String getVCheckcomment() {
		return this.VCheckcomment;
	}

	public void setVCheckcomment(String VCheckcomment) {
		this.VCheckcomment = VCheckcomment;
	}

	public Integer getIZpzb() {
		return this.IZpzb;
	}

	public void setIZpzb(Integer IZpzb) {
		this.IZpzb = IZpzb;
	}

	public Integer getIZpjs() {
		return this.IZpjs;
	}

	public void setIZpjs(Integer IZpjs) {
		this.IZpjs = IZpjs;
	}

	public Integer getIZp() {
		return this.IZp;
	}

	public void setIZp(Integer IZp) {
		this.IZp = IZp;
	}

	public Set getTAppeals() {
		return this.TAppeals;
	}

	public void setTAppeals(Set TAppeals) {
		this.TAppeals = TAppeals;
	}

}