package com.cauc.training.pojos;

import java.io.Serializable;

public class TContractUser implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 6800789915930245677L;

	private String VId;
	private String VNo;
	private String VName;
	private String VRole;
	private String VDelFlg;

	public TContractUser() {
		super();
	}

	public TContractUser(String vId, String vNo, String vName, String vRole, String vDelFlg) {
		super();
		VId = vId;
		VNo = vNo;
		VName = vName;
		VRole = vRole;
		VDelFlg = vDelFlg;
	}

	public String getVId() {
		return VId;
	}

	public void setVId(String vId) {
		VId = vId;
	}

	public String getVNo() {
		return VNo;
	}

	public void setVNo(String vNo) {
		VNo = vNo;
	}

	public String getVName() {
		return VName;
	}

	public void setVName(String vName) {
		VName = vName;
	}

	public String getVRole() {
		return VRole;
	}

	public void setVRole(String vRole) {
		VRole = vRole;
	}

	public String getVDelFlg() {
		return VDelFlg;
	}

	public void setVDelFlg(String vDelFlg) {
		VDelFlg = vDelFlg;
	}

}
