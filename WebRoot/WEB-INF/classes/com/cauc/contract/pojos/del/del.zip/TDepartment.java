package com.cauc.training.pojos;

import java.util.Date;

/**
 * TDepartment entity. @author MyEclipse Persistence Tools
 */

public class TDepartment implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private String VParentid;
	private Integer IOrder;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TDepartment() {
	}

	/** minimal constructor */
	public TDepartment(TUser TUser, String VName, Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TDepartment(TUser TUser, String VName, String VParentid,
			Integer IOrder, Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.VParentid = VParentid;
		this.IOrder = IOrder;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVParentid() {
		return this.VParentid;
	}

	public void setVParentid(String VParentid) {
		this.VParentid = VParentid;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}