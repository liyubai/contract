package com.cauc.training.pojos;

import java.util.Date;

/**
 * TDgdistribution entity. @author MyEclipse Persistence Tools
 */

public class TDgdistribution implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutline;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private String VContact;
	private Date DCreatedate;
	private Integer ICycle;
	private Integer IType;
	private Date DEnterDate;

	// Constructors

	/** default constructor */
	public TDgdistribution() {
	}

	/** minimal constructor */
	public TDgdistribution(TOutline TOutline, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DCreatedate) {
		this.TOutline = TOutline;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TDgdistribution(TOutline TOutline, TUser TUser,
			StudentBaseInfo studentBaseInfo, String VContact, Date DCreatedate,
			Integer ICycle, Integer IType, Date DEnterDate) {
		this.TOutline = TOutline;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.VContact = VContact;
		this.DCreatedate = DCreatedate;
		this.ICycle = ICycle;
		this.IType = IType;
		this.DEnterDate = DEnterDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public String getVContact() {
		return this.VContact;
	}

	public void setVContact(String VContact) {
		this.VContact = VContact;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getICycle() {
		return this.ICycle;
	}

	public void setICycle(Integer ICycle) {
		this.ICycle = ICycle;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Date getDEnterDate() {
		return this.DEnterDate;
	}

	public void setDEnterDate(Date DEnterDate) {
		this.DEnterDate = DEnterDate;
	}

}