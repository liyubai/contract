package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TDiction entity. @author MyEclipse Persistence Tools
 */

public class TDiction implements java.io.Serializable {

	// Fields

	private String VId;
	private TDictype TDictype;
	private TUser TUser;
	private String VName;
	private Date DCreatedate;
	private Set TStuStatusesForVNewstatusid = new HashSet(0);
	private Set studentAndstautsRelationsForVStuStatusid = new HashSet(0);
	private Set TTeacherflightexperiencerecords = new HashSet(0);
	private Set studentLicenses = new HashSet(0);
	private Set TFlightTrainingrecords = new HashSet(0);
	private Set TFlyteachrecords = new HashSet(0);
	private Set TTimesubjects = new HashSet(0);
	private Set TTeacherpaytimes = new HashSet(0);
	private Set studentstatuschangesForVOldStatusid = new HashSet(0);
	private Set TExperiencerecordEdits = new HashSet(0);
	private Set teacherBaseInfosForVFlytype = new HashSet(0);
	private Set studentBaseInfosForVNationid = new HashSet(0);
	private Set studentstatuschangesForVNewstatusid = new HashSet(0);
	private Set teacherBaseInfosForVTecdengji = new HashSet(0);
	private Set teacherBaseInfosForVGeneraltype = new HashSet(0);
	private Set teacherBaseInfosForVFlyform = new HashSet(0);
	private Set studentAndstautsRelationsForVStudentid = new HashSet(0);
	private Set teacherBaseInfosForVWhcd = new HashSet(0);
	private Set teacherBaseInfosForVMz = new HashSet(0);
	private Set TOtherflyrecords = new HashSet(0);
	private Set studentBaseInfosForVStuTypeid = new HashSet(0);
	private Set TFlightexperiencerecords = new HashSet(0);
	private Set studentBaseInfosForVXjStatusid = new HashSet(0);
	private Set studentBaseInfosForVStuStatusid = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set studentBaseInfosForVFormid = new HashSet(0);
	private Set studentLicensehistories = new HashSet(0);
	private Set studentBaseInfosForVWhcd = new HashSet(0);
	private Set TSchoolchangedbases = new HashSet(0);
	private Set studentBaseInfosForVFreeTypeid = new HashSet(0);
	private Set TStuStatusesForVOldstatusid = new HashSet(0);

	// Constructors

	/** default constructor */
	public TDiction() {
	}

	/** minimal constructor */
	public TDiction(TDictype TDictype, TUser TUser, String VName,
			Date DCreatedate) {
		this.TDictype = TDictype;
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TDiction(TDictype TDictype, TUser TUser, String VName,
			Date DCreatedate, Set TStuStatusesForVNewstatusid,
			Set studentAndstautsRelationsForVStuStatusid,
			Set TTeacherflightexperiencerecords, Set studentLicenses,
			Set TFlightTrainingrecords, Set TFlyteachrecords,
			Set TTimesubjects, Set TTeacherpaytimes,
			Set studentstatuschangesForVOldStatusid,
			Set TExperiencerecordEdits, Set teacherBaseInfosForVFlytype,
			Set studentBaseInfosForVNationid,
			Set studentstatuschangesForVNewstatusid,
			Set teacherBaseInfosForVTecdengji,
			Set teacherBaseInfosForVGeneraltype,
			Set teacherBaseInfosForVFlyform,
			Set studentAndstautsRelationsForVStudentid,
			Set teacherBaseInfosForVWhcd, Set teacherBaseInfosForVMz,
			Set TOtherflyrecords, Set studentBaseInfosForVStuTypeid,
			Set TFlightexperiencerecords, Set studentBaseInfosForVXjStatusid,
			Set studentBaseInfosForVStuStatusid, Set THistoryrecords,
			Set studentBaseInfosForVFormid, Set studentLicensehistories,
			Set studentBaseInfosForVWhcd, Set TSchoolchangedbases,
			Set studentBaseInfosForVFreeTypeid, Set TStuStatusesForVOldstatusid) {
		this.TDictype = TDictype;
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
		this.TStuStatusesForVNewstatusid = TStuStatusesForVNewstatusid;
		this.studentAndstautsRelationsForVStuStatusid = studentAndstautsRelationsForVStuStatusid;
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
		this.studentLicenses = studentLicenses;
		this.TFlightTrainingrecords = TFlightTrainingrecords;
		this.TFlyteachrecords = TFlyteachrecords;
		this.TTimesubjects = TTimesubjects;
		this.TTeacherpaytimes = TTeacherpaytimes;
		this.studentstatuschangesForVOldStatusid = studentstatuschangesForVOldStatusid;
		this.TExperiencerecordEdits = TExperiencerecordEdits;
		this.teacherBaseInfosForVFlytype = teacherBaseInfosForVFlytype;
		this.studentBaseInfosForVNationid = studentBaseInfosForVNationid;
		this.studentstatuschangesForVNewstatusid = studentstatuschangesForVNewstatusid;
		this.teacherBaseInfosForVTecdengji = teacherBaseInfosForVTecdengji;
		this.teacherBaseInfosForVGeneraltype = teacherBaseInfosForVGeneraltype;
		this.teacherBaseInfosForVFlyform = teacherBaseInfosForVFlyform;
		this.studentAndstautsRelationsForVStudentid = studentAndstautsRelationsForVStudentid;
		this.teacherBaseInfosForVWhcd = teacherBaseInfosForVWhcd;
		this.teacherBaseInfosForVMz = teacherBaseInfosForVMz;
		this.TOtherflyrecords = TOtherflyrecords;
		this.studentBaseInfosForVStuTypeid = studentBaseInfosForVStuTypeid;
		this.TFlightexperiencerecords = TFlightexperiencerecords;
		this.studentBaseInfosForVXjStatusid = studentBaseInfosForVXjStatusid;
		this.studentBaseInfosForVStuStatusid = studentBaseInfosForVStuStatusid;
		this.THistoryrecords = THistoryrecords;
		this.studentBaseInfosForVFormid = studentBaseInfosForVFormid;
		this.studentLicensehistories = studentLicensehistories;
		this.studentBaseInfosForVWhcd = studentBaseInfosForVWhcd;
		this.TSchoolchangedbases = TSchoolchangedbases;
		this.studentBaseInfosForVFreeTypeid = studentBaseInfosForVFreeTypeid;
		this.TStuStatusesForVOldstatusid = TStuStatusesForVOldstatusid;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDictype getTDictype() {
		return this.TDictype;
	}

	public void setTDictype(TDictype TDictype) {
		this.TDictype = TDictype;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTStuStatusesForVNewstatusid() {
		return this.TStuStatusesForVNewstatusid;
	}

	public void setTStuStatusesForVNewstatusid(Set TStuStatusesForVNewstatusid) {
		this.TStuStatusesForVNewstatusid = TStuStatusesForVNewstatusid;
	}

	public Set getStudentAndstautsRelationsForVStuStatusid() {
		return this.studentAndstautsRelationsForVStuStatusid;
	}

	public void setStudentAndstautsRelationsForVStuStatusid(
			Set studentAndstautsRelationsForVStuStatusid) {
		this.studentAndstautsRelationsForVStuStatusid = studentAndstautsRelationsForVStuStatusid;
	}

	public Set getTTeacherflightexperiencerecords() {
		return this.TTeacherflightexperiencerecords;
	}

	public void setTTeacherflightexperiencerecords(
			Set TTeacherflightexperiencerecords) {
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

	public Set getStudentLicenses() {
		return this.studentLicenses;
	}

	public void setStudentLicenses(Set studentLicenses) {
		this.studentLicenses = studentLicenses;
	}

	public Set getTFlightTrainingrecords() {
		return this.TFlightTrainingrecords;
	}

	public void setTFlightTrainingrecords(Set TFlightTrainingrecords) {
		this.TFlightTrainingrecords = TFlightTrainingrecords;
	}

	public Set getTFlyteachrecords() {
		return this.TFlyteachrecords;
	}

	public void setTFlyteachrecords(Set TFlyteachrecords) {
		this.TFlyteachrecords = TFlyteachrecords;
	}

	public Set getTTimesubjects() {
		return this.TTimesubjects;
	}

	public void setTTimesubjects(Set TTimesubjects) {
		this.TTimesubjects = TTimesubjects;
	}

	public Set getTTeacherpaytimes() {
		return this.TTeacherpaytimes;
	}

	public void setTTeacherpaytimes(Set TTeacherpaytimes) {
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

	public Set getStudentstatuschangesForVOldStatusid() {
		return this.studentstatuschangesForVOldStatusid;
	}

	public void setStudentstatuschangesForVOldStatusid(
			Set studentstatuschangesForVOldStatusid) {
		this.studentstatuschangesForVOldStatusid = studentstatuschangesForVOldStatusid;
	}

	public Set getTExperiencerecordEdits() {
		return this.TExperiencerecordEdits;
	}

	public void setTExperiencerecordEdits(Set TExperiencerecordEdits) {
		this.TExperiencerecordEdits = TExperiencerecordEdits;
	}

	public Set getTeacherBaseInfosForVFlytype() {
		return this.teacherBaseInfosForVFlytype;
	}

	public void setTeacherBaseInfosForVFlytype(Set teacherBaseInfosForVFlytype) {
		this.teacherBaseInfosForVFlytype = teacherBaseInfosForVFlytype;
	}

	public Set getStudentBaseInfosForVNationid() {
		return this.studentBaseInfosForVNationid;
	}

	public void setStudentBaseInfosForVNationid(Set studentBaseInfosForVNationid) {
		this.studentBaseInfosForVNationid = studentBaseInfosForVNationid;
	}

	public Set getStudentstatuschangesForVNewstatusid() {
		return this.studentstatuschangesForVNewstatusid;
	}

	public void setStudentstatuschangesForVNewstatusid(
			Set studentstatuschangesForVNewstatusid) {
		this.studentstatuschangesForVNewstatusid = studentstatuschangesForVNewstatusid;
	}

	public Set getTeacherBaseInfosForVTecdengji() {
		return this.teacherBaseInfosForVTecdengji;
	}

	public void setTeacherBaseInfosForVTecdengji(
			Set teacherBaseInfosForVTecdengji) {
		this.teacherBaseInfosForVTecdengji = teacherBaseInfosForVTecdengji;
	}

	public Set getTeacherBaseInfosForVGeneraltype() {
		return this.teacherBaseInfosForVGeneraltype;
	}

	public void setTeacherBaseInfosForVGeneraltype(
			Set teacherBaseInfosForVGeneraltype) {
		this.teacherBaseInfosForVGeneraltype = teacherBaseInfosForVGeneraltype;
	}

	public Set getTeacherBaseInfosForVFlyform() {
		return this.teacherBaseInfosForVFlyform;
	}

	public void setTeacherBaseInfosForVFlyform(Set teacherBaseInfosForVFlyform) {
		this.teacherBaseInfosForVFlyform = teacherBaseInfosForVFlyform;
	}

	public Set getStudentAndstautsRelationsForVStudentid() {
		return this.studentAndstautsRelationsForVStudentid;
	}

	public void setStudentAndstautsRelationsForVStudentid(
			Set studentAndstautsRelationsForVStudentid) {
		this.studentAndstautsRelationsForVStudentid = studentAndstautsRelationsForVStudentid;
	}

	public Set getTeacherBaseInfosForVWhcd() {
		return this.teacherBaseInfosForVWhcd;
	}

	public void setTeacherBaseInfosForVWhcd(Set teacherBaseInfosForVWhcd) {
		this.teacherBaseInfosForVWhcd = teacherBaseInfosForVWhcd;
	}

	public Set getTeacherBaseInfosForVMz() {
		return this.teacherBaseInfosForVMz;
	}

	public void setTeacherBaseInfosForVMz(Set teacherBaseInfosForVMz) {
		this.teacherBaseInfosForVMz = teacherBaseInfosForVMz;
	}

	public Set getTOtherflyrecords() {
		return this.TOtherflyrecords;
	}

	public void setTOtherflyrecords(Set TOtherflyrecords) {
		this.TOtherflyrecords = TOtherflyrecords;
	}

	public Set getStudentBaseInfosForVStuTypeid() {
		return this.studentBaseInfosForVStuTypeid;
	}

	public void setStudentBaseInfosForVStuTypeid(
			Set studentBaseInfosForVStuTypeid) {
		this.studentBaseInfosForVStuTypeid = studentBaseInfosForVStuTypeid;
	}

	public Set getTFlightexperiencerecords() {
		return this.TFlightexperiencerecords;
	}

	public void setTFlightexperiencerecords(Set TFlightexperiencerecords) {
		this.TFlightexperiencerecords = TFlightexperiencerecords;
	}

	public Set getStudentBaseInfosForVXjStatusid() {
		return this.studentBaseInfosForVXjStatusid;
	}

	public void setStudentBaseInfosForVXjStatusid(
			Set studentBaseInfosForVXjStatusid) {
		this.studentBaseInfosForVXjStatusid = studentBaseInfosForVXjStatusid;
	}

	public Set getStudentBaseInfosForVStuStatusid() {
		return this.studentBaseInfosForVStuStatusid;
	}

	public void setStudentBaseInfosForVStuStatusid(
			Set studentBaseInfosForVStuStatusid) {
		this.studentBaseInfosForVStuStatusid = studentBaseInfosForVStuStatusid;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getStudentBaseInfosForVFormid() {
		return this.studentBaseInfosForVFormid;
	}

	public void setStudentBaseInfosForVFormid(Set studentBaseInfosForVFormid) {
		this.studentBaseInfosForVFormid = studentBaseInfosForVFormid;
	}

	public Set getStudentLicensehistories() {
		return this.studentLicensehistories;
	}

	public void setStudentLicensehistories(Set studentLicensehistories) {
		this.studentLicensehistories = studentLicensehistories;
	}

	public Set getStudentBaseInfosForVWhcd() {
		return this.studentBaseInfosForVWhcd;
	}

	public void setStudentBaseInfosForVWhcd(Set studentBaseInfosForVWhcd) {
		this.studentBaseInfosForVWhcd = studentBaseInfosForVWhcd;
	}

	public Set getTSchoolchangedbases() {
		return this.TSchoolchangedbases;
	}

	public void setTSchoolchangedbases(Set TSchoolchangedbases) {
		this.TSchoolchangedbases = TSchoolchangedbases;
	}

	public Set getStudentBaseInfosForVFreeTypeid() {
		return this.studentBaseInfosForVFreeTypeid;
	}

	public void setStudentBaseInfosForVFreeTypeid(
			Set studentBaseInfosForVFreeTypeid) {
		this.studentBaseInfosForVFreeTypeid = studentBaseInfosForVFreeTypeid;
	}

	public Set getTStuStatusesForVOldstatusid() {
		return this.TStuStatusesForVOldstatusid;
	}

	public void setTStuStatusesForVOldstatusid(Set TStuStatusesForVOldstatusid) {
		this.TStuStatusesForVOldstatusid = TStuStatusesForVOldstatusid;
	}

}