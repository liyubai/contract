package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TDictype entity. @author MyEclipse Persistence Tools
 */

public class TDictype implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private Date DCreatedate;
	private Set TDictions = new HashSet(0);

	// Constructors

	/** default constructor */
	public TDictype() {
	}

	/** minimal constructor */
	public TDictype(TUser TUser, String VName, Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TDictype(TUser TUser, String VName, Date DCreatedate, Set TDictions) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
		this.TDictions = TDictions;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTDictions() {
		return this.TDictions;
	}

	public void setTDictions(Set TDictions) {
		this.TDictions = TDictions;
	}

}