package com.cauc.training.pojos;

import java.util.Date;

/**
 * TDispatch entity. @author MyEclipse Persistence Tools
 */

public class TDispatch implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfo;
	private TUser TUser;
	private Planeinfo planeinfo;
	private Date DDispatchtime;
	private Date DRecycletime;
	private Date DCreateDate;
	private double DFlytime;
	private Integer ITimes;
	private double DKongzhong;

	// Constructors

	/** default constructor */
	public TDispatch() {
	}

	/** minimal constructor */
	public TDispatch(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TDispatch(TeacherBaseInfo teacherBaseInfo, TUser TUser,
			Planeinfo planeinfo, Date DDispatchtime, Date DRecycletime,
			Date DCreateDate, double DFlytime, Integer ITimes, double DKongzhong) {
		this.teacherBaseInfo = teacherBaseInfo;
		this.TUser = TUser;
		this.planeinfo = planeinfo;
		this.DDispatchtime = DDispatchtime;
		this.DRecycletime = DRecycletime;
		this.DCreateDate = DCreateDate;
		this.DFlytime = DFlytime;
		this.ITimes = ITimes;
		this.DKongzhong = DKongzhong;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Date getDDispatchtime() {
		return this.DDispatchtime;
	}

	public void setDDispatchtime(Date DDispatchtime) {
		this.DDispatchtime = DDispatchtime;
	}

	public Date getDRecycletime() {
		return this.DRecycletime;
	}

	public void setDRecycletime(Date DRecycletime) {
		this.DRecycletime = DRecycletime;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public double getDFlytime() {
		return this.DFlytime;
	}

	public void setDFlytime(double DFlytime) {
		this.DFlytime = DFlytime;
	}

	public Integer getITimes() {
		return this.ITimes;
	}

	public void setITimes(Integer ITimes) {
		this.ITimes = ITimes;
	}

	public double getDKongzhong() {
		return this.DKongzhong;
	}

	public void setDKongzhong(double DKongzhong) {
		this.DKongzhong = DKongzhong;
	}

}