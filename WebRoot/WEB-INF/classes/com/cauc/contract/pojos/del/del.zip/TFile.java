package com.cauc.training.pojos;

import java.util.Date;

/**
 * TFile entity. @author MyEclipse Persistence Tools
 */

public class TFile implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VTitle;
	private String VFilename;
	private Integer IDoit;
	private String VIntroduction;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public TFile() {
	}

	/** minimal constructor */
	public TFile(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TFile(TUser TUser, String VTitle, String VFilename, Integer IDoit,
			String VIntroduction, Date DCreateDate) {
		this.TUser = TUser;
		this.VTitle = VTitle;
		this.VFilename = VFilename;
		this.IDoit = IDoit;
		this.VIntroduction = VIntroduction;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVTitle() {
		return this.VTitle;
	}

	public void setVTitle(String VTitle) {
		this.VTitle = VTitle;
	}

	public String getVFilename() {
		return this.VFilename;
	}

	public void setVFilename(String VFilename) {
		this.VFilename = VFilename;
	}

	public Integer getIDoit() {
		return this.IDoit;
	}

	public void setIDoit(Integer IDoit) {
		this.IDoit = IDoit;
	}

	public String getVIntroduction() {
		return this.VIntroduction;
	}

	public void setVIntroduction(String VIntroduction) {
		this.VIntroduction = VIntroduction;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}