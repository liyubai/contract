package com.cauc.training.pojos;

import java.sql.Clob;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TFlightTrainingrecord entity. @author MyEclipse Persistence Tools
 */

public class TFlightTrainingrecord implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfoByVFlyTeaId;
	private StudentBaseInfo studentBaseInfo;
	private TeacherBaseInfo teacherBaseInfoByVTeacherid;
	private TUser TUserByVAudituserid;
	private Station stationByVFpos;
	private Station stationByVJtpos;
	private TTrainingLesson TTrainingLesson;
	private TDiction TDiction;
	private TOutline TOutline;
	private Station stationByVLpos;
	private TeacherBaseInfo teacherBaseInfoByVMonitorteacherid;
	private TUser TUserByVCreateuserid;
	private Planeinfo planeinfo;
	private Integer IFlyUserType;
	private Date DFlydate;
	private Date DStartmoment;
	private Date DFlymoment;
	private Date DEndmoment;
	private Date DLandmoment;
	private double DEngineStart;
	private double DEngineEnd;
	private Date DCloseDate;
	private double DTrantime;
	private Integer ILanddaytimes;
	private Integer ILangnighttimes;
	private Date DCreatedate;
	private Integer IStustatus;
	private Date DAudittime;
	private Integer IAuditstatus;
	private Clob TSigncontent;
	private String VImgname;
	private String VSecondstudent;
	private Integer ISeat;
	private Set studentsubjectscores = new HashSet(0);
	private Set TFlyteachrecords = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set TComments = new HashSet(0);
	private Set TPassrecordeditors = new HashSet(0);
	private Set TFlightexperiencerecords = new HashSet(0);
	private Set TDelayrecords = new HashSet(0);
	private Set TReplaceapprovals = new HashSet(0);
	private Set TTeacherflightexperiencerecords = new HashSet(0);
	private Set TBackrecords = new HashSet(0);
	private Set TTeacherpaytimes = new HashSet(0);

	// Constructors

	/** default constructor */
	public TFlightTrainingrecord() {
	}

	/** minimal constructor */
	public TFlightTrainingrecord(TUser TUserByVCreateuserid, Date DCreatedate) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TFlightTrainingrecord(TeacherBaseInfo teacherBaseInfoByVFlyTeaId,
			StudentBaseInfo studentBaseInfo,
			TeacherBaseInfo teacherBaseInfoByVTeacherid,
			TUser TUserByVAudituserid, Station stationByVFpos,
			Station stationByVJtpos, TTrainingLesson TTrainingLesson,
			TDiction TDiction, TOutline TOutline, Station stationByVLpos,
			TeacherBaseInfo teacherBaseInfoByVMonitorteacherid,
			TUser TUserByVCreateuserid, Planeinfo planeinfo,
			Integer IFlyUserType, Date DFlydate, Date DStartmoment,
			Date DFlymoment, Date DEndmoment, Date DLandmoment,
			double DEngineStart, double DEngineEnd, Date DCloseDate,
			double DTrantime, Integer ILanddaytimes, Integer ILangnighttimes,
			Date DCreatedate, Integer IStustatus, Date DAudittime,
			Integer IAuditstatus, Clob TSigncontent, String VImgname,
			String VSecondstudent, Integer ISeat, Set studentsubjectscores,
			Set TFlyteachrecords, Set THistoryrecords, Set TComments,
			Set TPassrecordeditors, Set TFlightexperiencerecords,
			Set TDelayrecords, Set TReplaceapprovals,
			Set TTeacherflightexperiencerecords, Set TBackrecords,
			Set TTeacherpaytimes) {
		this.teacherBaseInfoByVFlyTeaId = teacherBaseInfoByVFlyTeaId;
		this.studentBaseInfo = studentBaseInfo;
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
		this.TUserByVAudituserid = TUserByVAudituserid;
		this.stationByVFpos = stationByVFpos;
		this.stationByVJtpos = stationByVJtpos;
		this.TTrainingLesson = TTrainingLesson;
		this.TDiction = TDiction;
		this.TOutline = TOutline;
		this.stationByVLpos = stationByVLpos;
		this.teacherBaseInfoByVMonitorteacherid = teacherBaseInfoByVMonitorteacherid;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.planeinfo = planeinfo;
		this.IFlyUserType = IFlyUserType;
		this.DFlydate = DFlydate;
		this.DStartmoment = DStartmoment;
		this.DFlymoment = DFlymoment;
		this.DEndmoment = DEndmoment;
		this.DLandmoment = DLandmoment;
		this.DEngineStart = DEngineStart;
		this.DEngineEnd = DEngineEnd;
		this.DCloseDate = DCloseDate;
		this.DTrantime = DTrantime;
		this.ILanddaytimes = ILanddaytimes;
		this.ILangnighttimes = ILangnighttimes;
		this.DCreatedate = DCreatedate;
		this.IStustatus = IStustatus;
		this.DAudittime = DAudittime;
		this.IAuditstatus = IAuditstatus;
		this.TSigncontent = TSigncontent;
		this.VImgname = VImgname;
		this.VSecondstudent = VSecondstudent;
		this.ISeat = ISeat;
		this.studentsubjectscores = studentsubjectscores;
		this.TFlyteachrecords = TFlyteachrecords;
		this.THistoryrecords = THistoryrecords;
		this.TComments = TComments;
		this.TPassrecordeditors = TPassrecordeditors;
		this.TFlightexperiencerecords = TFlightexperiencerecords;
		this.TDelayrecords = TDelayrecords;
		this.TReplaceapprovals = TReplaceapprovals;
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
		this.TBackrecords = TBackrecords;
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVFlyTeaId() {
		return this.teacherBaseInfoByVFlyTeaId;
	}

	public void setTeacherBaseInfoByVFlyTeaId(
			TeacherBaseInfo teacherBaseInfoByVFlyTeaId) {
		this.teacherBaseInfoByVFlyTeaId = teacherBaseInfoByVFlyTeaId;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVTeacherid() {
		return this.teacherBaseInfoByVTeacherid;
	}

	public void setTeacherBaseInfoByVTeacherid(
			TeacherBaseInfo teacherBaseInfoByVTeacherid) {
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
	}

	public TUser getTUserByVAudituserid() {
		return this.TUserByVAudituserid;
	}

	public void setTUserByVAudituserid(TUser TUserByVAudituserid) {
		this.TUserByVAudituserid = TUserByVAudituserid;
	}

	public Station getStationByVFpos() {
		return this.stationByVFpos;
	}

	public void setStationByVFpos(Station stationByVFpos) {
		this.stationByVFpos = stationByVFpos;
	}

	public Station getStationByVJtpos() {
		return this.stationByVJtpos;
	}

	public void setStationByVJtpos(Station stationByVJtpos) {
		this.stationByVJtpos = stationByVJtpos;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public Station getStationByVLpos() {
		return this.stationByVLpos;
	}

	public void setStationByVLpos(Station stationByVLpos) {
		this.stationByVLpos = stationByVLpos;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVMonitorteacherid() {
		return this.teacherBaseInfoByVMonitorteacherid;
	}

	public void setTeacherBaseInfoByVMonitorteacherid(
			TeacherBaseInfo teacherBaseInfoByVMonitorteacherid) {
		this.teacherBaseInfoByVMonitorteacherid = teacherBaseInfoByVMonitorteacherid;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Integer getIFlyUserType() {
		return this.IFlyUserType;
	}

	public void setIFlyUserType(Integer IFlyUserType) {
		this.IFlyUserType = IFlyUserType;
	}

	public Date getDFlydate() {
		return this.DFlydate;
	}

	public void setDFlydate(Date DFlydate) {
		this.DFlydate = DFlydate;
	}

	public Date getDStartmoment() {
		return this.DStartmoment;
	}

	public void setDStartmoment(Date DStartmoment) {
		this.DStartmoment = DStartmoment;
	}

	public Date getDFlymoment() {
		return this.DFlymoment;
	}

	public void setDFlymoment(Date DFlymoment) {
		this.DFlymoment = DFlymoment;
	}

	public Date getDEndmoment() {
		return this.DEndmoment;
	}

	public void setDEndmoment(Date DEndmoment) {
		this.DEndmoment = DEndmoment;
	}

	public Date getDLandmoment() {
		return this.DLandmoment;
	}

	public void setDLandmoment(Date DLandmoment) {
		this.DLandmoment = DLandmoment;
	}

	public double getDEngineStart() {
		return this.DEngineStart;
	}

	public void setDEngineStart(double DEngineStart) {
		this.DEngineStart = DEngineStart;
	}

	public double getDEngineEnd() {
		return this.DEngineEnd;
	}

	public void setDEngineEnd(double DEngineEnd) {
		this.DEngineEnd = DEngineEnd;
	}

	public Date getDCloseDate() {
		return this.DCloseDate;
	}

	public void setDCloseDate(Date DCloseDate) {
		this.DCloseDate = DCloseDate;
	}

	public double getDTrantime() {
		return this.DTrantime;
	}

	public void setDTrantime(double DTrantime) {
		this.DTrantime = DTrantime;
	}

	public Integer getILanddaytimes() {
		return this.ILanddaytimes;
	}

	public void setILanddaytimes(Integer ILanddaytimes) {
		this.ILanddaytimes = ILanddaytimes;
	}

	public Integer getILangnighttimes() {
		return this.ILangnighttimes;
	}

	public void setILangnighttimes(Integer ILangnighttimes) {
		this.ILangnighttimes = ILangnighttimes;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIStustatus() {
		return this.IStustatus;
	}

	public void setIStustatus(Integer IStustatus) {
		this.IStustatus = IStustatus;
	}

	public Date getDAudittime() {
		return this.DAudittime;
	}

	public void setDAudittime(Date DAudittime) {
		this.DAudittime = DAudittime;
	}

	public Integer getIAuditstatus() {
		return this.IAuditstatus;
	}

	public void setIAuditstatus(Integer IAuditstatus) {
		this.IAuditstatus = IAuditstatus;
	}

	public Clob getTSigncontent() {
		return this.TSigncontent;
	}

	public void setTSigncontent(Clob TSigncontent) {
		this.TSigncontent = TSigncontent;
	}

	public String getVImgname() {
		return this.VImgname;
	}

	public void setVImgname(String VImgname) {
		this.VImgname = VImgname;
	}

	public String getVSecondstudent() {
		return this.VSecondstudent;
	}

	public void setVSecondstudent(String VSecondstudent) {
		this.VSecondstudent = VSecondstudent;
	}

	public Integer getISeat() {
		return this.ISeat;
	}

	public void setISeat(Integer ISeat) {
		this.ISeat = ISeat;
	}

	public Set getStudentsubjectscores() {
		return this.studentsubjectscores;
	}

	public void setStudentsubjectscores(Set studentsubjectscores) {
		this.studentsubjectscores = studentsubjectscores;
	}

	public Set getTFlyteachrecords() {
		return this.TFlyteachrecords;
	}

	public void setTFlyteachrecords(Set TFlyteachrecords) {
		this.TFlyteachrecords = TFlyteachrecords;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getTComments() {
		return this.TComments;
	}

	public void setTComments(Set TComments) {
		this.TComments = TComments;
	}

	public Set getTPassrecordeditors() {
		return this.TPassrecordeditors;
	}

	public void setTPassrecordeditors(Set TPassrecordeditors) {
		this.TPassrecordeditors = TPassrecordeditors;
	}

	public Set getTFlightexperiencerecords() {
		return this.TFlightexperiencerecords;
	}

	public void setTFlightexperiencerecords(Set TFlightexperiencerecords) {
		this.TFlightexperiencerecords = TFlightexperiencerecords;
	}

	public Set getTDelayrecords() {
		return this.TDelayrecords;
	}

	public void setTDelayrecords(Set TDelayrecords) {
		this.TDelayrecords = TDelayrecords;
	}

	public Set getTReplaceapprovals() {
		return this.TReplaceapprovals;
	}

	public void setTReplaceapprovals(Set TReplaceapprovals) {
		this.TReplaceapprovals = TReplaceapprovals;
	}

	public Set getTTeacherflightexperiencerecords() {
		return this.TTeacherflightexperiencerecords;
	}

	public void setTTeacherflightexperiencerecords(
			Set TTeacherflightexperiencerecords) {
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

	public Set getTBackrecords() {
		return this.TBackrecords;
	}

	public void setTBackrecords(Set TBackrecords) {
		this.TBackrecords = TBackrecords;
	}

	public Set getTTeacherpaytimes() {
		return this.TTeacherpaytimes;
	}

	public void setTTeacherpaytimes(Set TTeacherpaytimes) {
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

}