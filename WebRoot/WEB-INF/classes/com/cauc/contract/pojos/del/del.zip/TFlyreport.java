package com.cauc.training.pojos;

import java.util.Date;

/**
 * TFlyreport entity. @author MyEclipse Persistence Tools
 */

public class TFlyreport implements java.io.Serializable {

	// Fields

	private String VId;
	private Station stationByVLandpos;
	private TOutline TOutline;
	private Station stationByVFlypos;
	private TeacherBaseInfo teacherBaseInfoByVMonitorTeacher;
	private Flytaskbook flytaskbook;
	private TeacherBaseInfo teacherBaseInfoByVSingleTeacher;
	private TUser TUser;
	private TeacherBaseInfo teacherBaseInfoByVTeaid;
	private TTrainingLesson TTrainingLesson;
	private StudentBaseInfo studentBaseInfo;
	private Date DExectime;
	private Integer IUserType;
	private Date DStarttime;
	private Date DFlyTime;
	private Date DLandTime;
	private Date DEndtime;
	private Integer IFlys;
	private Integer ILands;
	private Date DFdjstarttime;
	private Date DFdjendtime;
	private Integer IReportType;
	private String VOtherFlight;
	private String VRemarks;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public TFlyreport() {
	}

	/** minimal constructor */
	public TFlyreport(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TFlyreport(Station stationByVLandpos, TOutline TOutline,
			Station stationByVFlypos,
			TeacherBaseInfo teacherBaseInfoByVMonitorTeacher,
			Flytaskbook flytaskbook,
			TeacherBaseInfo teacherBaseInfoByVSingleTeacher, TUser TUser,
			TeacherBaseInfo teacherBaseInfoByVTeaid,
			TTrainingLesson TTrainingLesson, StudentBaseInfo studentBaseInfo,
			Date DExectime, Integer IUserType, Date DStarttime, Date DFlyTime,
			Date DLandTime, Date DEndtime, Integer IFlys, Integer ILands,
			Date DFdjstarttime, Date DFdjendtime, Integer IReportType,
			String VOtherFlight, String VRemarks, Date DCreateDate) {
		this.stationByVLandpos = stationByVLandpos;
		this.TOutline = TOutline;
		this.stationByVFlypos = stationByVFlypos;
		this.teacherBaseInfoByVMonitorTeacher = teacherBaseInfoByVMonitorTeacher;
		this.flytaskbook = flytaskbook;
		this.teacherBaseInfoByVSingleTeacher = teacherBaseInfoByVSingleTeacher;
		this.TUser = TUser;
		this.teacherBaseInfoByVTeaid = teacherBaseInfoByVTeaid;
		this.TTrainingLesson = TTrainingLesson;
		this.studentBaseInfo = studentBaseInfo;
		this.DExectime = DExectime;
		this.IUserType = IUserType;
		this.DStarttime = DStarttime;
		this.DFlyTime = DFlyTime;
		this.DLandTime = DLandTime;
		this.DEndtime = DEndtime;
		this.IFlys = IFlys;
		this.ILands = ILands;
		this.DFdjstarttime = DFdjstarttime;
		this.DFdjendtime = DFdjendtime;
		this.IReportType = IReportType;
		this.VOtherFlight = VOtherFlight;
		this.VRemarks = VRemarks;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Station getStationByVLandpos() {
		return this.stationByVLandpos;
	}

	public void setStationByVLandpos(Station stationByVLandpos) {
		this.stationByVLandpos = stationByVLandpos;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public Station getStationByVFlypos() {
		return this.stationByVFlypos;
	}

	public void setStationByVFlypos(Station stationByVFlypos) {
		this.stationByVFlypos = stationByVFlypos;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVMonitorTeacher() {
		return this.teacherBaseInfoByVMonitorTeacher;
	}

	public void setTeacherBaseInfoByVMonitorTeacher(
			TeacherBaseInfo teacherBaseInfoByVMonitorTeacher) {
		this.teacherBaseInfoByVMonitorTeacher = teacherBaseInfoByVMonitorTeacher;
	}

	public Flytaskbook getFlytaskbook() {
		return this.flytaskbook;
	}

	public void setFlytaskbook(Flytaskbook flytaskbook) {
		this.flytaskbook = flytaskbook;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVSingleTeacher() {
		return this.teacherBaseInfoByVSingleTeacher;
	}

	public void setTeacherBaseInfoByVSingleTeacher(
			TeacherBaseInfo teacherBaseInfoByVSingleTeacher) {
		this.teacherBaseInfoByVSingleTeacher = teacherBaseInfoByVSingleTeacher;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVTeaid() {
		return this.teacherBaseInfoByVTeaid;
	}

	public void setTeacherBaseInfoByVTeaid(
			TeacherBaseInfo teacherBaseInfoByVTeaid) {
		this.teacherBaseInfoByVTeaid = teacherBaseInfoByVTeaid;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDExectime() {
		return this.DExectime;
	}

	public void setDExectime(Date DExectime) {
		this.DExectime = DExectime;
	}

	public Integer getIUserType() {
		return this.IUserType;
	}

	public void setIUserType(Integer IUserType) {
		this.IUserType = IUserType;
	}

	public Date getDStarttime() {
		return this.DStarttime;
	}

	public void setDStarttime(Date DStarttime) {
		this.DStarttime = DStarttime;
	}

	public Date getDFlyTime() {
		return this.DFlyTime;
	}

	public void setDFlyTime(Date DFlyTime) {
		this.DFlyTime = DFlyTime;
	}

	public Date getDLandTime() {
		return this.DLandTime;
	}

	public void setDLandTime(Date DLandTime) {
		this.DLandTime = DLandTime;
	}

	public Date getDEndtime() {
		return this.DEndtime;
	}

	public void setDEndtime(Date DEndtime) {
		this.DEndtime = DEndtime;
	}

	public Integer getIFlys() {
		return this.IFlys;
	}

	public void setIFlys(Integer IFlys) {
		this.IFlys = IFlys;
	}

	public Integer getILands() {
		return this.ILands;
	}

	public void setILands(Integer ILands) {
		this.ILands = ILands;
	}

	public Date getDFdjstarttime() {
		return this.DFdjstarttime;
	}

	public void setDFdjstarttime(Date DFdjstarttime) {
		this.DFdjstarttime = DFdjstarttime;
	}

	public Date getDFdjendtime() {
		return this.DFdjendtime;
	}

	public void setDFdjendtime(Date DFdjendtime) {
		this.DFdjendtime = DFdjendtime;
	}

	public Integer getIReportType() {
		return this.IReportType;
	}

	public void setIReportType(Integer IReportType) {
		this.IReportType = IReportType;
	}

	public String getVOtherFlight() {
		return this.VOtherFlight;
	}

	public void setVOtherFlight(String VOtherFlight) {
		this.VOtherFlight = VOtherFlight;
	}

	public String getVRemarks() {
		return this.VRemarks;
	}

	public void setVRemarks(String VRemarks) {
		this.VRemarks = VRemarks;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}