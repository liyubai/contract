package com.cauc.training.pojos;

import java.util.Date;

/**
 * TForeignaviationschoolinterview entity. @author MyEclipse Persistence Tools
 */

public class TForeignaviationschoolinterview implements java.io.Serializable {

	// Fields

	private String VId;
	private Studentassignschool studentassignschool;
	private TUser TUser;
	private Date DAuditiontime;
	private Integer IResult;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TForeignaviationschoolinterview() {
	}

	/** minimal constructor */
	public TForeignaviationschoolinterview(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TForeignaviationschoolinterview(
			Studentassignschool studentassignschool, TUser TUser,
			Date DAuditiontime, Integer IResult, Date DCreatedate) {
		this.studentassignschool = studentassignschool;
		this.TUser = TUser;
		this.DAuditiontime = DAuditiontime;
		this.IResult = IResult;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Studentassignschool getStudentassignschool() {
		return this.studentassignschool;
	}

	public void setStudentassignschool(Studentassignschool studentassignschool) {
		this.studentassignschool = studentassignschool;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDAuditiontime() {
		return this.DAuditiontime;
	}

	public void setDAuditiontime(Date DAuditiontime) {
		this.DAuditiontime = DAuditiontime;
	}

	public Integer getIResult() {
		return this.IResult;
	}

	public void setIResult(Integer IResult) {
		this.IResult = IResult;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}