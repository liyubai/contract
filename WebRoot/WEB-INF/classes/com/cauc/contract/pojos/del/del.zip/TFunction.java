package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TFunction entity. @author MyEclipse Persistence Tools
 */

public class TFunction implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private String VParentid;
	private Integer IOrder;
	private String VUrl;
	private Date DCreateDate;
	private Integer IDh;
	private Integer IRootid;
	private Set TRoleFunctions = new HashSet(0);
	private Set TLogs = new HashSet(0);

	// Constructors

	/** default constructor */
	public TFunction() {
	}

	/** minimal constructor */
	public TFunction(TUser TUser, String VName, Date DCreateDate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TFunction(TUser TUser, String VName, String VParentid,
			Integer IOrder, String VUrl, Date DCreateDate, Integer IDh,
			Integer IRootid, Set TRoleFunctions, Set TLogs) {
		this.TUser = TUser;
		this.VName = VName;
		this.VParentid = VParentid;
		this.IOrder = IOrder;
		this.VUrl = VUrl;
		this.DCreateDate = DCreateDate;
		this.IDh = IDh;
		this.IRootid = IRootid;
		this.TRoleFunctions = TRoleFunctions;
		this.TLogs = TLogs;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVParentid() {
		return this.VParentid;
	}

	public void setVParentid(String VParentid) {
		this.VParentid = VParentid;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public String getVUrl() {
		return this.VUrl;
	}

	public void setVUrl(String VUrl) {
		this.VUrl = VUrl;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Integer getIDh() {
		return this.IDh;
	}

	public void setIDh(Integer IDh) {
		this.IDh = IDh;
	}

	public Integer getIRootid() {
		return this.IRootid;
	}

	public void setIRootid(Integer IRootid) {
		this.IRootid = IRootid;
	}

	public Set getTRoleFunctions() {
		return this.TRoleFunctions;
	}

	public void setTRoleFunctions(Set TRoleFunctions) {
		this.TRoleFunctions = TRoleFunctions;
	}

	public Set getTLogs() {
		return this.TLogs;
	}

	public void setTLogs(Set TLogs) {
		this.TLogs = TLogs;
	}

}