package com.cauc.training.pojos;

import java.util.Date;

/**
 * TGnchangedgw entity. @author MyEclipse Persistence Tools
 */

public class TGnchangedgw implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DChangedtime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TGnchangedgw() {
	}

	/** minimal constructor */
	public TGnchangedgw(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TGnchangedgw(TUser TUser, StudentBaseInfo studentBaseInfo,
			Date DChangedtime, Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DChangedtime = DChangedtime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDChangedtime() {
		return this.DChangedtime;
	}

	public void setDChangedtime(Date DChangedtime) {
		this.DChangedtime = DChangedtime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}