package com.cauc.training.pojos;

import java.util.Date;

/**
 * TGntrainbackschool entity. @author MyEclipse Persistence Tools
 */

public class TGntrainbackschool implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DFinishtime;
	private Date DBackschooltime;
	private Integer IType;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TGntrainbackschool() {
	}

	/** minimal constructor */
	public TGntrainbackschool(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TGntrainbackschool(TUser TUser, StudentBaseInfo studentBaseInfo,
			Date DFinishtime, Date DBackschooltime, Integer IType,
			Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DFinishtime = DFinishtime;
		this.DBackschooltime = DBackschooltime;
		this.IType = IType;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDFinishtime() {
		return this.DFinishtime;
	}

	public void setDFinishtime(Date DFinishtime) {
		this.DFinishtime = DFinishtime;
	}

	public Date getDBackschooltime() {
		return this.DBackschooltime;
	}

	public void setDBackschooltime(Date DBackschooltime) {
		this.DBackschooltime = DBackschooltime;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}