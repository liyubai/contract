package com.cauc.training.pojos;

import java.sql.Clob;
import java.util.Date;

/**
 * THistoryrecord entity. @author MyEclipse Persistence Tools
 */

public class THistoryrecord implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfoByVFlyTeaId;
	private StudentBaseInfo studentBaseInfo;
	private TeacherBaseInfo teacherBaseInfoByVTeacherid;
	private TUser TUserByVAudituserid;
	private Station stationByVFpos;
	private TTrainingLesson TTrainingLesson;
	private TDiction TDiction;
	private TOutline TOutline;
	private Station stationByVLpos;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private TeacherBaseInfo teacherBaseInfoByVMonitorteacherid;
	private TUser TUserByVCreateuserid;
	private Planeinfo planeinfo;
	private Integer IFlyUserType;
	private Date DFlydate;
	private Date DStartmoment;
	private Date DFlymoment;
	private Date DEndmoment;
	private Date DLandmoment;
	private Date DCloseDate;
	private double DTrantime;
	private Integer ILanddaytimes;
	private Integer ILangnighttimes;
	private Date DCreatedate;
	private Integer IStustatus;
	private Date DAudittime;
	private Integer IAuditstatus;
	private String VImgname;
	private Clob TSigncontent;
	private String VSecondstudent;

	// Constructors

	/** default constructor */
	public THistoryrecord() {
	}

	/** minimal constructor */
	public THistoryrecord(TFlightTrainingrecord TFlightTrainingrecord,
			TUser TUserByVCreateuserid, Date DCreatedate) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public THistoryrecord(TeacherBaseInfo teacherBaseInfoByVFlyTeaId,
			StudentBaseInfo studentBaseInfo,
			TeacherBaseInfo teacherBaseInfoByVTeacherid,
			TUser TUserByVAudituserid, Station stationByVFpos,
			TTrainingLesson TTrainingLesson, TDiction TDiction,
			TOutline TOutline, Station stationByVLpos,
			TFlightTrainingrecord TFlightTrainingrecord,
			TeacherBaseInfo teacherBaseInfoByVMonitorteacherid,
			TUser TUserByVCreateuserid, Planeinfo planeinfo,
			Integer IFlyUserType, Date DFlydate, Date DStartmoment,
			Date DFlymoment, Date DEndmoment, Date DLandmoment,
			Date DCloseDate, double DTrantime, Integer ILanddaytimes,
			Integer ILangnighttimes, Date DCreatedate, Integer IStustatus,
			Date DAudittime, Integer IAuditstatus, String VImgname,
			Clob TSigncontent, String VSecondstudent) {
		this.teacherBaseInfoByVFlyTeaId = teacherBaseInfoByVFlyTeaId;
		this.studentBaseInfo = studentBaseInfo;
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
		this.TUserByVAudituserid = TUserByVAudituserid;
		this.stationByVFpos = stationByVFpos;
		this.TTrainingLesson = TTrainingLesson;
		this.TDiction = TDiction;
		this.TOutline = TOutline;
		this.stationByVLpos = stationByVLpos;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.teacherBaseInfoByVMonitorteacherid = teacherBaseInfoByVMonitorteacherid;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.planeinfo = planeinfo;
		this.IFlyUserType = IFlyUserType;
		this.DFlydate = DFlydate;
		this.DStartmoment = DStartmoment;
		this.DFlymoment = DFlymoment;
		this.DEndmoment = DEndmoment;
		this.DLandmoment = DLandmoment;
		this.DCloseDate = DCloseDate;
		this.DTrantime = DTrantime;
		this.ILanddaytimes = ILanddaytimes;
		this.ILangnighttimes = ILangnighttimes;
		this.DCreatedate = DCreatedate;
		this.IStustatus = IStustatus;
		this.DAudittime = DAudittime;
		this.IAuditstatus = IAuditstatus;
		this.VImgname = VImgname;
		this.TSigncontent = TSigncontent;
		this.VSecondstudent = VSecondstudent;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVFlyTeaId() {
		return this.teacherBaseInfoByVFlyTeaId;
	}

	public void setTeacherBaseInfoByVFlyTeaId(
			TeacherBaseInfo teacherBaseInfoByVFlyTeaId) {
		this.teacherBaseInfoByVFlyTeaId = teacherBaseInfoByVFlyTeaId;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVTeacherid() {
		return this.teacherBaseInfoByVTeacherid;
	}

	public void setTeacherBaseInfoByVTeacherid(
			TeacherBaseInfo teacherBaseInfoByVTeacherid) {
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
	}

	public TUser getTUserByVAudituserid() {
		return this.TUserByVAudituserid;
	}

	public void setTUserByVAudituserid(TUser TUserByVAudituserid) {
		this.TUserByVAudituserid = TUserByVAudituserid;
	}

	public Station getStationByVFpos() {
		return this.stationByVFpos;
	}

	public void setStationByVFpos(Station stationByVFpos) {
		this.stationByVFpos = stationByVFpos;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public Station getStationByVLpos() {
		return this.stationByVLpos;
	}

	public void setStationByVLpos(Station stationByVLpos) {
		this.stationByVLpos = stationByVLpos;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVMonitorteacherid() {
		return this.teacherBaseInfoByVMonitorteacherid;
	}

	public void setTeacherBaseInfoByVMonitorteacherid(
			TeacherBaseInfo teacherBaseInfoByVMonitorteacherid) {
		this.teacherBaseInfoByVMonitorteacherid = teacherBaseInfoByVMonitorteacherid;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Integer getIFlyUserType() {
		return this.IFlyUserType;
	}

	public void setIFlyUserType(Integer IFlyUserType) {
		this.IFlyUserType = IFlyUserType;
	}

	public Date getDFlydate() {
		return this.DFlydate;
	}

	public void setDFlydate(Date DFlydate) {
		this.DFlydate = DFlydate;
	}

	public Date getDStartmoment() {
		return this.DStartmoment;
	}

	public void setDStartmoment(Date DStartmoment) {
		this.DStartmoment = DStartmoment;
	}

	public Date getDFlymoment() {
		return this.DFlymoment;
	}

	public void setDFlymoment(Date DFlymoment) {
		this.DFlymoment = DFlymoment;
	}

	public Date getDEndmoment() {
		return this.DEndmoment;
	}

	public void setDEndmoment(Date DEndmoment) {
		this.DEndmoment = DEndmoment;
	}

	public Date getDLandmoment() {
		return this.DLandmoment;
	}

	public void setDLandmoment(Date DLandmoment) {
		this.DLandmoment = DLandmoment;
	}

	public Date getDCloseDate() {
		return this.DCloseDate;
	}

	public void setDCloseDate(Date DCloseDate) {
		this.DCloseDate = DCloseDate;
	}

	public double getDTrantime() {
		return this.DTrantime;
	}

	public void setDTrantime(double DTrantime) {
		this.DTrantime = DTrantime;
	}

	public Integer getILanddaytimes() {
		return this.ILanddaytimes;
	}

	public void setILanddaytimes(Integer ILanddaytimes) {
		this.ILanddaytimes = ILanddaytimes;
	}

	public Integer getILangnighttimes() {
		return this.ILangnighttimes;
	}

	public void setILangnighttimes(Integer ILangnighttimes) {
		this.ILangnighttimes = ILangnighttimes;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIStustatus() {
		return this.IStustatus;
	}

	public void setIStustatus(Integer IStustatus) {
		this.IStustatus = IStustatus;
	}

	public Date getDAudittime() {
		return this.DAudittime;
	}

	public void setDAudittime(Date DAudittime) {
		this.DAudittime = DAudittime;
	}

	public Integer getIAuditstatus() {
		return this.IAuditstatus;
	}

	public void setIAuditstatus(Integer IAuditstatus) {
		this.IAuditstatus = IAuditstatus;
	}

	public String getVImgname() {
		return this.VImgname;
	}

	public void setVImgname(String VImgname) {
		this.VImgname = VImgname;
	}

	public Clob getTSigncontent() {
		return this.TSigncontent;
	}

	public void setTSigncontent(Clob TSigncontent) {
		this.TSigncontent = TSigncontent;
	}

	public String getVSecondstudent() {
		return this.VSecondstudent;
	}

	public void setVSecondstudent(String VSecondstudent) {
		this.VSecondstudent = VSecondstudent;
	}

}