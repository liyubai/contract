package com.cauc.training.pojos;

import java.util.Date;

/**
 * THistoryscore entity. @author MyEclipse Persistence Tools
 */

public class THistoryscore implements java.io.Serializable {

	// Fields

	private String VId;
	private TScore TScore;
	private TUser TUserByVAuditUserId;
	private TUser TUserByVCreateUserId;
	private double DScore;
	private Date DExamtime;
	private Date DCreateDate;
	private Date DAuditDate;

	// Constructors

	/** default constructor */
	public THistoryscore() {
	}

	/** minimal constructor */
	public THistoryscore(TUser TUserByVCreateUserId, Date DCreateDate) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public THistoryscore(TScore TScore, TUser TUserByVAuditUserId,
			TUser TUserByVCreateUserId, double DScore, Date DExamtime,
			Date DCreateDate, Date DAuditDate) {
		this.TScore = TScore;
		this.TUserByVAuditUserId = TUserByVAuditUserId;
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.DScore = DScore;
		this.DExamtime = DExamtime;
		this.DCreateDate = DCreateDate;
		this.DAuditDate = DAuditDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TScore getTScore() {
		return this.TScore;
	}

	public void setTScore(TScore TScore) {
		this.TScore = TScore;
	}

	public TUser getTUserByVAuditUserId() {
		return this.TUserByVAuditUserId;
	}

	public void setTUserByVAuditUserId(TUser TUserByVAuditUserId) {
		this.TUserByVAuditUserId = TUserByVAuditUserId;
	}

	public TUser getTUserByVCreateUserId() {
		return this.TUserByVCreateUserId;
	}

	public void setTUserByVCreateUserId(TUser TUserByVCreateUserId) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public Date getDExamtime() {
		return this.DExamtime;
	}

	public void setDExamtime(Date DExamtime) {
		this.DExamtime = DExamtime;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Date getDAuditDate() {
		return this.DAuditDate;
	}

	public void setDAuditDate(Date DAuditDate) {
		this.DAuditDate = DAuditDate;
	}

}