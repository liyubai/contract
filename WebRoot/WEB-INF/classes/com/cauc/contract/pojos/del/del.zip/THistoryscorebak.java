package com.cauc.training.pojos;

import java.util.Date;

/**
 * THistoryscorebak entity. @author MyEclipse Persistence Tools
 */

public class THistoryscorebak implements java.io.Serializable {

	// Fields

	private String VId;
	private String VScoreid;
	private double DScore;
	private Date DExamtime;
	private Date DCreateDate;
	private String VCreateUserId;
	private String VAuditUserId;
	private Date DAuditDate;

	// Constructors

	/** default constructor */
	public THistoryscorebak() {
	}

	/** minimal constructor */
	public THistoryscorebak(Date DCreateDate, String VCreateUserId) {
		this.DCreateDate = DCreateDate;
		this.VCreateUserId = VCreateUserId;
	}

	/** full constructor */
	public THistoryscorebak(String VScoreid, double DScore, Date DExamtime,
			Date DCreateDate, String VCreateUserId, String VAuditUserId,
			Date DAuditDate) {
		this.VScoreid = VScoreid;
		this.DScore = DScore;
		this.DExamtime = DExamtime;
		this.DCreateDate = DCreateDate;
		this.VCreateUserId = VCreateUserId;
		this.VAuditUserId = VAuditUserId;
		this.DAuditDate = DAuditDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public String getVScoreid() {
		return this.VScoreid;
	}

	public void setVScoreid(String VScoreid) {
		this.VScoreid = VScoreid;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public Date getDExamtime() {
		return this.DExamtime;
	}

	public void setDExamtime(Date DExamtime) {
		this.DExamtime = DExamtime;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public String getVCreateUserId() {
		return this.VCreateUserId;
	}

	public void setVCreateUserId(String VCreateUserId) {
		this.VCreateUserId = VCreateUserId;
	}

	public String getVAuditUserId() {
		return this.VAuditUserId;
	}

	public void setVAuditUserId(String VAuditUserId) {
		this.VAuditUserId = VAuditUserId;
	}

	public Date getDAuditDate() {
		return this.DAuditDate;
	}

	public void setDAuditDate(Date DAuditDate) {
		this.DAuditDate = DAuditDate;
	}

}