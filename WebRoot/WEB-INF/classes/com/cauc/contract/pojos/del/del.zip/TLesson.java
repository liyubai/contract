package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TLesson entity. @author MyEclipse Persistence Tools
 */

public class TLesson implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VLessonName;
	private String VContent;
	private String VStandard;
	private String VCankao;
	private double DScore;
	private String VTeacherName;
	private Date DCreatedate;
	private Integer IType;
	private Integer IOrder;
	private Set TScores = new HashSet(0);
	private Set recommendStudentLicenseExams = new HashSet(0);
	private Set TPointLines = new HashSet(0);

	// Constructors

	/** default constructor */
	public TLesson() {
	}

	/** minimal constructor */
	public TLesson(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TLesson(TUser TUser, String VLessonName, String VContent,
			String VStandard, String VCankao, double DScore,
			String VTeacherName, Date DCreatedate, Integer IType,
			Integer IOrder, Set TScores, Set recommendStudentLicenseExams,
			Set TPointLines) {
		this.TUser = TUser;
		this.VLessonName = VLessonName;
		this.VContent = VContent;
		this.VStandard = VStandard;
		this.VCankao = VCankao;
		this.DScore = DScore;
		this.VTeacherName = VTeacherName;
		this.DCreatedate = DCreatedate;
		this.IType = IType;
		this.IOrder = IOrder;
		this.TScores = TScores;
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
		this.TPointLines = TPointLines;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVLessonName() {
		return this.VLessonName;
	}

	public void setVLessonName(String VLessonName) {
		this.VLessonName = VLessonName;
	}

	public String getVContent() {
		return this.VContent;
	}

	public void setVContent(String VContent) {
		this.VContent = VContent;
	}

	public String getVStandard() {
		return this.VStandard;
	}

	public void setVStandard(String VStandard) {
		this.VStandard = VStandard;
	}

	public String getVCankao() {
		return this.VCankao;
	}

	public void setVCankao(String VCankao) {
		this.VCankao = VCankao;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public String getVTeacherName() {
		return this.VTeacherName;
	}

	public void setVTeacherName(String VTeacherName) {
		this.VTeacherName = VTeacherName;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public Set getTScores() {
		return this.TScores;
	}

	public void setTScores(Set TScores) {
		this.TScores = TScores;
	}

	public Set getRecommendStudentLicenseExams() {
		return this.recommendStudentLicenseExams;
	}

	public void setRecommendStudentLicenseExams(Set recommendStudentLicenseExams) {
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
	}

	public Set getTPointLines() {
		return this.TPointLines;
	}

	public void setTPointLines(Set TPointLines) {
		this.TPointLines = TPointLines;
	}

}