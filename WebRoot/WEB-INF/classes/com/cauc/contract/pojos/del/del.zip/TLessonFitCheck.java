package com.cauc.training.pojos;

import java.util.Date;

/**
 * TLessonFitCheck entity. @author MyEclipse Persistence Tools
 */

public class TLessonFitCheck implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutline;
	private StudentBaseInfo studentBaseInfo;
	private TUser TUser;
	private String VParentid;
	private Integer IType;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TLessonFitCheck() {
	}

	/** full constructor */
	public TLessonFitCheck(TOutline TOutline, StudentBaseInfo studentBaseInfo,
			TUser TUser, String VParentid, Integer IType, Date DCreatedate) {
		this.TOutline = TOutline;
		this.studentBaseInfo = studentBaseInfo;
		this.TUser = TUser;
		this.VParentid = VParentid;
		this.IType = IType;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVParentid() {
		return this.VParentid;
	}

	public void setVParentid(String VParentid) {
		this.VParentid = VParentid;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}