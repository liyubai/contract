package com.cauc.training.pojos;

import java.sql.Clob;
import java.util.Date;

/**
 * TLog entity. @author MyEclipse Persistence Tools
 */

public class TLog implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TFunction TFunction;
	private Clob VContent;
	private Date DCreateDate;
	private String VOperateid;

	// Constructors

	/** default constructor */
	public TLog() {
	}

	/** minimal constructor */
	public TLog(TUser TUser, Clob VContent, Date DCreateDate) {
		this.TUser = TUser;
		this.VContent = VContent;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TLog(TUser TUser, TFunction TFunction, Clob VContent,
			Date DCreateDate, String VOperateid) {
		this.TUser = TUser;
		this.TFunction = TFunction;
		this.VContent = VContent;
		this.DCreateDate = DCreateDate;
		this.VOperateid = VOperateid;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TFunction getTFunction() {
		return this.TFunction;
	}

	public void setTFunction(TFunction TFunction) {
		this.TFunction = TFunction;
	}

	public Clob getVContent() {
		return this.VContent;
	}

	public void setVContent(Clob VContent) {
		this.VContent = VContent;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public String getVOperateid() {
		return this.VOperateid;
	}

	public void setVOperateid(String VOperateid) {
		this.VOperateid = VOperateid;
	}

}