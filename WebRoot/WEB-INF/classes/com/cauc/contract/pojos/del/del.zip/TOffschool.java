package com.cauc.training.pojos;

import java.util.Date;

/**
 * TOffschool entity. @author MyEclipse Persistence Tools
 */

public class TOffschool implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DFinishtime;
	private Date DOffschooltime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TOffschool() {
	}

	/** minimal constructor */
	public TOffschool(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TOffschool(TUser TUser, StudentBaseInfo studentBaseInfo,
			Date DFinishtime, Date DOffschooltime, Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DFinishtime = DFinishtime;
		this.DOffschooltime = DOffschooltime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDFinishtime() {
		return this.DFinishtime;
	}

	public void setDFinishtime(Date DFinishtime) {
		this.DFinishtime = DFinishtime;
	}

	public Date getDOffschooltime() {
		return this.DOffschooltime;
	}

	public void setDOffschooltime(Date DOffschooltime) {
		this.DOffschooltime = DOffschooltime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}