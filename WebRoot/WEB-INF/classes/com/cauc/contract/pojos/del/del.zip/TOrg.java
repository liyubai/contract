package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TOrg entity. @author MyEclipse Persistence Tools
 */

public class TOrg implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private String VParentid;
	private Integer IStatus;
	private Date DCreateDate;
	private Set TPlaneexchangesForVNewbase = new HashSet(0);
	private Set teacherBaseInfos = new HashSet(0);
	private Set TSimulatorinfos = new HashSet(0);
	private Set studentBaseInfos = new HashSet(0);
	private Set TPlaneexchangesForVOldbase = new HashSet(0);
	private Set changecompaniesForVOldcompany = new HashSet(0);
	private Set changecompaniesForVNewcompany = new HashSet(0);
	private Set planeinfos = new HashSet(0);
	private Set TChangedgroupsForVOldgroup = new HashSet(0);
	private Set TStuassigngroups = new HashSet(0);
	private Set TChangedgroupsForVNewgroup = new HashSet(0);
	private Set TStuassignbases = new HashSet(0);
	private Set graduationStudentAssigns = new HashSet(0);
	private Set TChangedbasesForVOldbaseid = new HashSet(0);
	private Set traininginfos = new HashSet(0);
	private Set TOtherusers = new HashSet(0);
	private Set TChangedbasesForVNewbaseid = new HashSet(0);

	// Constructors

	/** default constructor */
	public TOrg() {
	}

	/** minimal constructor */
	public TOrg(TUser TUser, String VName, Date DCreateDate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TOrg(TUser TUser, String VName, String VParentid, Integer IStatus,
			Date DCreateDate, Set TPlaneexchangesForVNewbase,
			Set teacherBaseInfos, Set TSimulatorinfos, Set studentBaseInfos,
			Set TPlaneexchangesForVOldbase, Set changecompaniesForVOldcompany,
			Set changecompaniesForVNewcompany, Set planeinfos,
			Set TChangedgroupsForVOldgroup, Set TStuassigngroups,
			Set TChangedgroupsForVNewgroup, Set TStuassignbases,
			Set graduationStudentAssigns, Set TChangedbasesForVOldbaseid,
			Set traininginfos, Set TOtherusers, Set TChangedbasesForVNewbaseid) {
		this.TUser = TUser;
		this.VName = VName;
		this.VParentid = VParentid;
		this.IStatus = IStatus;
		this.DCreateDate = DCreateDate;
		this.TPlaneexchangesForVNewbase = TPlaneexchangesForVNewbase;
		this.teacherBaseInfos = teacherBaseInfos;
		this.TSimulatorinfos = TSimulatorinfos;
		this.studentBaseInfos = studentBaseInfos;
		this.TPlaneexchangesForVOldbase = TPlaneexchangesForVOldbase;
		this.changecompaniesForVOldcompany = changecompaniesForVOldcompany;
		this.changecompaniesForVNewcompany = changecompaniesForVNewcompany;
		this.planeinfos = planeinfos;
		this.TChangedgroupsForVOldgroup = TChangedgroupsForVOldgroup;
		this.TStuassigngroups = TStuassigngroups;
		this.TChangedgroupsForVNewgroup = TChangedgroupsForVNewgroup;
		this.TStuassignbases = TStuassignbases;
		this.graduationStudentAssigns = graduationStudentAssigns;
		this.TChangedbasesForVOldbaseid = TChangedbasesForVOldbaseid;
		this.traininginfos = traininginfos;
		this.TOtherusers = TOtherusers;
		this.TChangedbasesForVNewbaseid = TChangedbasesForVNewbaseid;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVParentid() {
		return this.VParentid;
	}

	public void setVParentid(String VParentid) {
		this.VParentid = VParentid;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Set getTPlaneexchangesForVNewbase() {
		return this.TPlaneexchangesForVNewbase;
	}

	public void setTPlaneexchangesForVNewbase(Set TPlaneexchangesForVNewbase) {
		this.TPlaneexchangesForVNewbase = TPlaneexchangesForVNewbase;
	}

	public Set getTeacherBaseInfos() {
		return this.teacherBaseInfos;
	}

	public void setTeacherBaseInfos(Set teacherBaseInfos) {
		this.teacherBaseInfos = teacherBaseInfos;
	}

	public Set getTSimulatorinfos() {
		return this.TSimulatorinfos;
	}

	public void setTSimulatorinfos(Set TSimulatorinfos) {
		this.TSimulatorinfos = TSimulatorinfos;
	}

	public Set getStudentBaseInfos() {
		return this.studentBaseInfos;
	}

	public void setStudentBaseInfos(Set studentBaseInfos) {
		this.studentBaseInfos = studentBaseInfos;
	}

	public Set getTPlaneexchangesForVOldbase() {
		return this.TPlaneexchangesForVOldbase;
	}

	public void setTPlaneexchangesForVOldbase(Set TPlaneexchangesForVOldbase) {
		this.TPlaneexchangesForVOldbase = TPlaneexchangesForVOldbase;
	}

	public Set getChangecompaniesForVOldcompany() {
		return this.changecompaniesForVOldcompany;
	}

	public void setChangecompaniesForVOldcompany(
			Set changecompaniesForVOldcompany) {
		this.changecompaniesForVOldcompany = changecompaniesForVOldcompany;
	}

	public Set getChangecompaniesForVNewcompany() {
		return this.changecompaniesForVNewcompany;
	}

	public void setChangecompaniesForVNewcompany(
			Set changecompaniesForVNewcompany) {
		this.changecompaniesForVNewcompany = changecompaniesForVNewcompany;
	}

	public Set getPlaneinfos() {
		return this.planeinfos;
	}

	public void setPlaneinfos(Set planeinfos) {
		this.planeinfos = planeinfos;
	}

	public Set getTChangedgroupsForVOldgroup() {
		return this.TChangedgroupsForVOldgroup;
	}

	public void setTChangedgroupsForVOldgroup(Set TChangedgroupsForVOldgroup) {
		this.TChangedgroupsForVOldgroup = TChangedgroupsForVOldgroup;
	}

	public Set getTStuassigngroups() {
		return this.TStuassigngroups;
	}

	public void setTStuassigngroups(Set TStuassigngroups) {
		this.TStuassigngroups = TStuassigngroups;
	}

	public Set getTChangedgroupsForVNewgroup() {
		return this.TChangedgroupsForVNewgroup;
	}

	public void setTChangedgroupsForVNewgroup(Set TChangedgroupsForVNewgroup) {
		this.TChangedgroupsForVNewgroup = TChangedgroupsForVNewgroup;
	}

	public Set getTStuassignbases() {
		return this.TStuassignbases;
	}

	public void setTStuassignbases(Set TStuassignbases) {
		this.TStuassignbases = TStuassignbases;
	}

	public Set getGraduationStudentAssigns() {
		return this.graduationStudentAssigns;
	}

	public void setGraduationStudentAssigns(Set graduationStudentAssigns) {
		this.graduationStudentAssigns = graduationStudentAssigns;
	}

	public Set getTChangedbasesForVOldbaseid() {
		return this.TChangedbasesForVOldbaseid;
	}

	public void setTChangedbasesForVOldbaseid(Set TChangedbasesForVOldbaseid) {
		this.TChangedbasesForVOldbaseid = TChangedbasesForVOldbaseid;
	}

	public Set getTraininginfos() {
		return this.traininginfos;
	}

	public void setTraininginfos(Set traininginfos) {
		this.traininginfos = traininginfos;
	}

	public Set getTOtherusers() {
		return this.TOtherusers;
	}

	public void setTOtherusers(Set TOtherusers) {
		this.TOtherusers = TOtherusers;
	}

	public Set getTChangedbasesForVNewbaseid() {
		return this.TChangedbasesForVNewbaseid;
	}

	public void setTChangedbasesForVNewbaseid(Set TChangedbasesForVNewbaseid) {
		this.TChangedbasesForVNewbaseid = TChangedbasesForVNewbaseid;
	}

}