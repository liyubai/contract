package com.cauc.training.pojos;

import java.util.Date;

/**
 * TOtherflyrecord entity. @author MyEclipse Persistence Tools
 */

public class TOtherflyrecord implements java.io.Serializable {

	// Fields

	private String VId;
	private Station stationByVLandpos;
	private TDiction TDiction;
	private Station stationByVFlypos;
	private TUser TUserByVAuditUserid;
	private TUser TUserByVCreateUserId;
	private TUser TUserByVUserid;
	private TTrainingLesson TTrainingLesson;
	private Planeinfo planeinfo;
	private Date DFlydate;
	private Date DStarttime;
	private Date DEndtime;
	private Integer IDaytimes;
	private Integer INeighttimes;
	private double DJiashiyuantime;
	private double DJizhangtime;
	private double DDanfeitime;
	private double DZhuanchangtime;
	private double DYejiantime;
	private double DFujiashitime;
	private double DDaifeitime;
	private double DFjszhuanchangtime;
	private double DFjszcyjtime;
	private double DMoniyibiaotime;
	private double DZhenshiyibiao;
	private String VTranpos;
	private double DMnjsj;
	private double DXlqsj;
	private double DTeacherTime;
	private String VLhy;
	private String VTxy;
	private String VJxy;
	private String VBz;
	private Integer IAuditStatus;
	private Date DAuditTime;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public TOtherflyrecord() {
	}

	/** minimal constructor */
	public TOtherflyrecord(TUser TUserByVCreateUserId, Date DCreateDate) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TOtherflyrecord(Station stationByVLandpos, TDiction TDiction,
			Station stationByVFlypos, TUser TUserByVAuditUserid,
			TUser TUserByVCreateUserId, TUser TUserByVUserid,
			TTrainingLesson TTrainingLesson, Planeinfo planeinfo,
			Date DFlydate, Date DStarttime, Date DEndtime, Integer IDaytimes,
			Integer INeighttimes, double DJiashiyuantime, double DJizhangtime,
			double DDanfeitime, double DZhuanchangtime, double DYejiantime,
			double DFujiashitime, double DDaifeitime,
			double DFjszhuanchangtime, double DFjszcyjtime,
			double DMoniyibiaotime, double DZhenshiyibiao, String VTranpos,
			double DMnjsj, double DXlqsj, double DTeacherTime, String VLhy,
			String VTxy, String VJxy, String VBz, Integer IAuditStatus,
			Date DAuditTime, Date DCreateDate) {
		this.stationByVLandpos = stationByVLandpos;
		this.TDiction = TDiction;
		this.stationByVFlypos = stationByVFlypos;
		this.TUserByVAuditUserid = TUserByVAuditUserid;
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.TUserByVUserid = TUserByVUserid;
		this.TTrainingLesson = TTrainingLesson;
		this.planeinfo = planeinfo;
		this.DFlydate = DFlydate;
		this.DStarttime = DStarttime;
		this.DEndtime = DEndtime;
		this.IDaytimes = IDaytimes;
		this.INeighttimes = INeighttimes;
		this.DJiashiyuantime = DJiashiyuantime;
		this.DJizhangtime = DJizhangtime;
		this.DDanfeitime = DDanfeitime;
		this.DZhuanchangtime = DZhuanchangtime;
		this.DYejiantime = DYejiantime;
		this.DFujiashitime = DFujiashitime;
		this.DDaifeitime = DDaifeitime;
		this.DFjszhuanchangtime = DFjszhuanchangtime;
		this.DFjszcyjtime = DFjszcyjtime;
		this.DMoniyibiaotime = DMoniyibiaotime;
		this.DZhenshiyibiao = DZhenshiyibiao;
		this.VTranpos = VTranpos;
		this.DMnjsj = DMnjsj;
		this.DXlqsj = DXlqsj;
		this.DTeacherTime = DTeacherTime;
		this.VLhy = VLhy;
		this.VTxy = VTxy;
		this.VJxy = VJxy;
		this.VBz = VBz;
		this.IAuditStatus = IAuditStatus;
		this.DAuditTime = DAuditTime;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Station getStationByVLandpos() {
		return this.stationByVLandpos;
	}

	public void setStationByVLandpos(Station stationByVLandpos) {
		this.stationByVLandpos = stationByVLandpos;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public Station getStationByVFlypos() {
		return this.stationByVFlypos;
	}

	public void setStationByVFlypos(Station stationByVFlypos) {
		this.stationByVFlypos = stationByVFlypos;
	}

	public TUser getTUserByVAuditUserid() {
		return this.TUserByVAuditUserid;
	}

	public void setTUserByVAuditUserid(TUser TUserByVAuditUserid) {
		this.TUserByVAuditUserid = TUserByVAuditUserid;
	}

	public TUser getTUserByVCreateUserId() {
		return this.TUserByVCreateUserId;
	}

	public void setTUserByVCreateUserId(TUser TUserByVCreateUserId) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
	}

	public TUser getTUserByVUserid() {
		return this.TUserByVUserid;
	}

	public void setTUserByVUserid(TUser TUserByVUserid) {
		this.TUserByVUserid = TUserByVUserid;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Date getDFlydate() {
		return this.DFlydate;
	}

	public void setDFlydate(Date DFlydate) {
		this.DFlydate = DFlydate;
	}

	public Date getDStarttime() {
		return this.DStarttime;
	}

	public void setDStarttime(Date DStarttime) {
		this.DStarttime = DStarttime;
	}

	public Date getDEndtime() {
		return this.DEndtime;
	}

	public void setDEndtime(Date DEndtime) {
		this.DEndtime = DEndtime;
	}

	public Integer getIDaytimes() {
		return this.IDaytimes;
	}

	public void setIDaytimes(Integer IDaytimes) {
		this.IDaytimes = IDaytimes;
	}

	public Integer getINeighttimes() {
		return this.INeighttimes;
	}

	public void setINeighttimes(Integer INeighttimes) {
		this.INeighttimes = INeighttimes;
	}

	public double getDJiashiyuantime() {
		return this.DJiashiyuantime;
	}

	public void setDJiashiyuantime(double DJiashiyuantime) {
		this.DJiashiyuantime = DJiashiyuantime;
	}

	public double getDJizhangtime() {
		return this.DJizhangtime;
	}

	public void setDJizhangtime(double DJizhangtime) {
		this.DJizhangtime = DJizhangtime;
	}

	public double getDDanfeitime() {
		return this.DDanfeitime;
	}

	public void setDDanfeitime(double DDanfeitime) {
		this.DDanfeitime = DDanfeitime;
	}

	public double getDZhuanchangtime() {
		return this.DZhuanchangtime;
	}

	public void setDZhuanchangtime(double DZhuanchangtime) {
		this.DZhuanchangtime = DZhuanchangtime;
	}

	public double getDYejiantime() {
		return this.DYejiantime;
	}

	public void setDYejiantime(double DYejiantime) {
		this.DYejiantime = DYejiantime;
	}

	public double getDFujiashitime() {
		return this.DFujiashitime;
	}

	public void setDFujiashitime(double DFujiashitime) {
		this.DFujiashitime = DFujiashitime;
	}

	public double getDDaifeitime() {
		return this.DDaifeitime;
	}

	public void setDDaifeitime(double DDaifeitime) {
		this.DDaifeitime = DDaifeitime;
	}

	public double getDFjszhuanchangtime() {
		return this.DFjszhuanchangtime;
	}

	public void setDFjszhuanchangtime(double DFjszhuanchangtime) {
		this.DFjszhuanchangtime = DFjszhuanchangtime;
	}

	public double getDFjszcyjtime() {
		return this.DFjszcyjtime;
	}

	public void setDFjszcyjtime(double DFjszcyjtime) {
		this.DFjszcyjtime = DFjszcyjtime;
	}

	public double getDMoniyibiaotime() {
		return this.DMoniyibiaotime;
	}

	public void setDMoniyibiaotime(double DMoniyibiaotime) {
		this.DMoniyibiaotime = DMoniyibiaotime;
	}

	public double getDZhenshiyibiao() {
		return this.DZhenshiyibiao;
	}

	public void setDZhenshiyibiao(double DZhenshiyibiao) {
		this.DZhenshiyibiao = DZhenshiyibiao;
	}

	public String getVTranpos() {
		return this.VTranpos;
	}

	public void setVTranpos(String VTranpos) {
		this.VTranpos = VTranpos;
	}

	public double getDMnjsj() {
		return this.DMnjsj;
	}

	public void setDMnjsj(double DMnjsj) {
		this.DMnjsj = DMnjsj;
	}

	public double getDXlqsj() {
		return this.DXlqsj;
	}

	public void setDXlqsj(double DXlqsj) {
		this.DXlqsj = DXlqsj;
	}

	public double getDTeacherTime() {
		return this.DTeacherTime;
	}

	public void setDTeacherTime(double DTeacherTime) {
		this.DTeacherTime = DTeacherTime;
	}

	public String getVLhy() {
		return this.VLhy;
	}

	public void setVLhy(String VLhy) {
		this.VLhy = VLhy;
	}

	public String getVTxy() {
		return this.VTxy;
	}

	public void setVTxy(String VTxy) {
		this.VTxy = VTxy;
	}

	public String getVJxy() {
		return this.VJxy;
	}

	public void setVJxy(String VJxy) {
		this.VJxy = VJxy;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Integer getIAuditStatus() {
		return this.IAuditStatus;
	}

	public void setIAuditStatus(Integer IAuditStatus) {
		this.IAuditStatus = IAuditStatus;
	}

	public Date getDAuditTime() {
		return this.DAuditTime;
	}

	public void setDAuditTime(Date DAuditTime) {
		this.DAuditTime = DAuditTime;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}