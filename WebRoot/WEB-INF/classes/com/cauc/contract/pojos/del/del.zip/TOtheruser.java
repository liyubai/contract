package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TOtheruser entity. @author MyEclipse Persistence Tools
 */

public class TOtheruser implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrg;
	private TUser TUser;
	private String VName;
	private String VCode;
	private String VLxfs;
	private String VCardid;
	private String VSex;
	private Date DCsrq;
	private String VMz;
	private String VZzmm;
	private String VJg;
	private String VJtzz;
	private String VWhcd;
	private Date DCrgzsj;
	private Date DCreatedate;
	private Integer openStatus;
	private Set assignExamTeachers = new HashSet(0);
	private Set TSetClasses = new HashSet(0);
	private Set practiceTests = new HashSet(0);
	private Set recommendStudentLicenseExams = new HashSet(0);

	// Constructors

	/** default constructor */
	public TOtheruser() {
	}

	/** minimal constructor */
	public TOtheruser(TUser TUser, String VName, Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TOtheruser(TOrg TOrg, TUser TUser, String VName, String VCode,
			String VLxfs, String VCardid, String VSex, Date DCsrq, String VMz,
			String VZzmm, String VJg, String VJtzz, String VWhcd, Date DCrgzsj,
			Date DCreatedate, Integer openStatus, Set assignExamTeachers,
			Set TSetClasses, Set practiceTests, Set recommendStudentLicenseExams) {
		this.TOrg = TOrg;
		this.TUser = TUser;
		this.VName = VName;
		this.VCode = VCode;
		this.VLxfs = VLxfs;
		this.VCardid = VCardid;
		this.VSex = VSex;
		this.DCsrq = DCsrq;
		this.VMz = VMz;
		this.VZzmm = VZzmm;
		this.VJg = VJg;
		this.VJtzz = VJtzz;
		this.VWhcd = VWhcd;
		this.DCrgzsj = DCrgzsj;
		this.DCreatedate = DCreatedate;
		this.openStatus = openStatus;
		this.assignExamTeachers = assignExamTeachers;
		this.TSetClasses = TSetClasses;
		this.practiceTests = practiceTests;
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public String getVLxfs() {
		return this.VLxfs;
	}

	public void setVLxfs(String VLxfs) {
		this.VLxfs = VLxfs;
	}

	public String getVCardid() {
		return this.VCardid;
	}

	public void setVCardid(String VCardid) {
		this.VCardid = VCardid;
	}

	public String getVSex() {
		return this.VSex;
	}

	public void setVSex(String VSex) {
		this.VSex = VSex;
	}

	public Date getDCsrq() {
		return this.DCsrq;
	}

	public void setDCsrq(Date DCsrq) {
		this.DCsrq = DCsrq;
	}

	public String getVMz() {
		return this.VMz;
	}

	public void setVMz(String VMz) {
		this.VMz = VMz;
	}

	public String getVZzmm() {
		return this.VZzmm;
	}

	public void setVZzmm(String VZzmm) {
		this.VZzmm = VZzmm;
	}

	public String getVJg() {
		return this.VJg;
	}

	public void setVJg(String VJg) {
		this.VJg = VJg;
	}

	public String getVJtzz() {
		return this.VJtzz;
	}

	public void setVJtzz(String VJtzz) {
		this.VJtzz = VJtzz;
	}

	public String getVWhcd() {
		return this.VWhcd;
	}

	public void setVWhcd(String VWhcd) {
		this.VWhcd = VWhcd;
	}

	public Date getDCrgzsj() {
		return this.DCrgzsj;
	}

	public void setDCrgzsj(Date DCrgzsj) {
		this.DCrgzsj = DCrgzsj;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getOpenStatus() {
		return this.openStatus;
	}

	public void setOpenStatus(Integer openStatus) {
		this.openStatus = openStatus;
	}

	public Set getAssignExamTeachers() {
		return this.assignExamTeachers;
	}

	public void setAssignExamTeachers(Set assignExamTeachers) {
		this.assignExamTeachers = assignExamTeachers;
	}

	public Set getTSetClasses() {
		return this.TSetClasses;
	}

	public void setTSetClasses(Set TSetClasses) {
		this.TSetClasses = TSetClasses;
	}

	public Set getPracticeTests() {
		return this.practiceTests;
	}

	public void setPracticeTests(Set practiceTests) {
		this.practiceTests = practiceTests;
	}

	public Set getRecommendStudentLicenseExams() {
		return this.recommendStudentLicenseExams;
	}

	public void setRecommendStudentLicenseExams(Set recommendStudentLicenseExams) {
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
	}

}