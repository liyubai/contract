package com.cauc.training.pojos;

import java.sql.Clob;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TOutline entity. @author MyEclipse Persistence Tools
 */

public class TOutline implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUserByVAudituserid;
	private TUser TUserByVCreateuserid;
	private String VName;
	private String VCode;
	private String VBc;
	private String VRange;
	private String VTarget;
	private String VConditions;
	private String VTraincycle;
	private String VChangeschool;
	private String VStoptrain;
	private String VTrainmethod;
	private String VScorejudge;
	private String VTrainrecord;
	private Date DAudittime;
	private Date DUpdatetme;
	private Integer IUnits;
	private Integer IStages;
	private Integer ILessons;
	private double DTraintime;
	private double DPlanetime;
	private double DTrainningdevicetime;
	private double DMonijitime;
	private String VMeterclass;
	private String VMultipleclass;
	private String VTrainequipment;
	private String VTrainform;
	private Integer IStatus;
	private String VFilename;
	private Clob TSign;
	private Date DCreatedate;
	private Set trainlessonunits = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set TFlyreports = new HashSet(0);
	private Set TFlightTrainingrecords = new HashSet(0);
	private Set outLineAudits = new HashSet(0);
	private Set TChangedoutlinesForVOlddgid = new HashSet(0);
	private Set TLessonFitChecks = new HashSet(0);
	private Set TDgdistributions = new HashSet(0);
	private Set TChangedoutlinesForVNewdgid = new HashSet(0);
	private Set TTeacherdgdistributions = new HashSet(0);

	// Constructors

	/** default constructor */
	public TOutline() {
	}

	/** minimal constructor */
	public TOutline(TUser TUserByVCreateuserid, String VName, String VCode,
			Date DCreatedate) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.VName = VName;
		this.VCode = VCode;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TOutline(TUser TUserByVAudituserid, TUser TUserByVCreateuserid,
			String VName, String VCode, String VBc, String VRange,
			String VTarget, String VConditions, String VTraincycle,
			String VChangeschool, String VStoptrain, String VTrainmethod,
			String VScorejudge, String VTrainrecord, Date DAudittime,
			Date DUpdatetme, Integer IUnits, Integer IStages, Integer ILessons,
			double DTraintime, double DPlanetime, double DTrainningdevicetime,
			double DMonijitime, String VMeterclass, String VMultipleclass,
			String VTrainequipment, String VTrainform, Integer IStatus,
			String VFilename, Clob TSign, Date DCreatedate,
			Set trainlessonunits, Set THistoryrecords, Set TFlyreports,
			Set TFlightTrainingrecords, Set outLineAudits,
			Set TChangedoutlinesForVOlddgid, Set TLessonFitChecks,
			Set TDgdistributions, Set TChangedoutlinesForVNewdgid,
			Set TTeacherdgdistributions) {
		this.TUserByVAudituserid = TUserByVAudituserid;
		this.TUserByVCreateuserid = TUserByVCreateuserid;
		this.VName = VName;
		this.VCode = VCode;
		this.VBc = VBc;
		this.VRange = VRange;
		this.VTarget = VTarget;
		this.VConditions = VConditions;
		this.VTraincycle = VTraincycle;
		this.VChangeschool = VChangeschool;
		this.VStoptrain = VStoptrain;
		this.VTrainmethod = VTrainmethod;
		this.VScorejudge = VScorejudge;
		this.VTrainrecord = VTrainrecord;
		this.DAudittime = DAudittime;
		this.DUpdatetme = DUpdatetme;
		this.IUnits = IUnits;
		this.IStages = IStages;
		this.ILessons = ILessons;
		this.DTraintime = DTraintime;
		this.DPlanetime = DPlanetime;
		this.DTrainningdevicetime = DTrainningdevicetime;
		this.DMonijitime = DMonijitime;
		this.VMeterclass = VMeterclass;
		this.VMultipleclass = VMultipleclass;
		this.VTrainequipment = VTrainequipment;
		this.VTrainform = VTrainform;
		this.IStatus = IStatus;
		this.VFilename = VFilename;
		this.TSign = TSign;
		this.DCreatedate = DCreatedate;
		this.trainlessonunits = trainlessonunits;
		this.THistoryrecords = THistoryrecords;
		this.TFlyreports = TFlyreports;
		this.TFlightTrainingrecords = TFlightTrainingrecords;
		this.outLineAudits = outLineAudits;
		this.TChangedoutlinesForVOlddgid = TChangedoutlinesForVOlddgid;
		this.TLessonFitChecks = TLessonFitChecks;
		this.TDgdistributions = TDgdistributions;
		this.TChangedoutlinesForVNewdgid = TChangedoutlinesForVNewdgid;
		this.TTeacherdgdistributions = TTeacherdgdistributions;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUserByVAudituserid() {
		return this.TUserByVAudituserid;
	}

	public void setTUserByVAudituserid(TUser TUserByVAudituserid) {
		this.TUserByVAudituserid = TUserByVAudituserid;
	}

	public TUser getTUserByVCreateuserid() {
		return this.TUserByVCreateuserid;
	}

	public void setTUserByVCreateuserid(TUser TUserByVCreateuserid) {
		this.TUserByVCreateuserid = TUserByVCreateuserid;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public String getVBc() {
		return this.VBc;
	}

	public void setVBc(String VBc) {
		this.VBc = VBc;
	}

	public String getVRange() {
		return this.VRange;
	}

	public void setVRange(String VRange) {
		this.VRange = VRange;
	}

	public String getVTarget() {
		return this.VTarget;
	}

	public void setVTarget(String VTarget) {
		this.VTarget = VTarget;
	}

	public String getVConditions() {
		return this.VConditions;
	}

	public void setVConditions(String VConditions) {
		this.VConditions = VConditions;
	}

	public String getVTraincycle() {
		return this.VTraincycle;
	}

	public void setVTraincycle(String VTraincycle) {
		this.VTraincycle = VTraincycle;
	}

	public String getVChangeschool() {
		return this.VChangeschool;
	}

	public void setVChangeschool(String VChangeschool) {
		this.VChangeschool = VChangeschool;
	}

	public String getVStoptrain() {
		return this.VStoptrain;
	}

	public void setVStoptrain(String VStoptrain) {
		this.VStoptrain = VStoptrain;
	}

	public String getVTrainmethod() {
		return this.VTrainmethod;
	}

	public void setVTrainmethod(String VTrainmethod) {
		this.VTrainmethod = VTrainmethod;
	}

	public String getVScorejudge() {
		return this.VScorejudge;
	}

	public void setVScorejudge(String VScorejudge) {
		this.VScorejudge = VScorejudge;
	}

	public String getVTrainrecord() {
		return this.VTrainrecord;
	}

	public void setVTrainrecord(String VTrainrecord) {
		this.VTrainrecord = VTrainrecord;
	}

	public Date getDAudittime() {
		return this.DAudittime;
	}

	public void setDAudittime(Date DAudittime) {
		this.DAudittime = DAudittime;
	}

	public Date getDUpdatetme() {
		return this.DUpdatetme;
	}

	public void setDUpdatetme(Date DUpdatetme) {
		this.DUpdatetme = DUpdatetme;
	}

	public Integer getIUnits() {
		return this.IUnits;
	}

	public void setIUnits(Integer IUnits) {
		this.IUnits = IUnits;
	}

	public Integer getIStages() {
		return this.IStages;
	}

	public void setIStages(Integer IStages) {
		this.IStages = IStages;
	}

	public Integer getILessons() {
		return this.ILessons;
	}

	public void setILessons(Integer ILessons) {
		this.ILessons = ILessons;
	}

	public double getDTraintime() {
		return this.DTraintime;
	}

	public void setDTraintime(double DTraintime) {
		this.DTraintime = DTraintime;
	}

	public double getDPlanetime() {
		return this.DPlanetime;
	}

	public void setDPlanetime(double DPlanetime) {
		this.DPlanetime = DPlanetime;
	}

	public double getDTrainningdevicetime() {
		return this.DTrainningdevicetime;
	}

	public void setDTrainningdevicetime(double DTrainningdevicetime) {
		this.DTrainningdevicetime = DTrainningdevicetime;
	}

	public double getDMonijitime() {
		return this.DMonijitime;
	}

	public void setDMonijitime(double DMonijitime) {
		this.DMonijitime = DMonijitime;
	}

	public String getVMeterclass() {
		return this.VMeterclass;
	}

	public void setVMeterclass(String VMeterclass) {
		this.VMeterclass = VMeterclass;
	}

	public String getVMultipleclass() {
		return this.VMultipleclass;
	}

	public void setVMultipleclass(String VMultipleclass) {
		this.VMultipleclass = VMultipleclass;
	}

	public String getVTrainequipment() {
		return this.VTrainequipment;
	}

	public void setVTrainequipment(String VTrainequipment) {
		this.VTrainequipment = VTrainequipment;
	}

	public String getVTrainform() {
		return this.VTrainform;
	}

	public void setVTrainform(String VTrainform) {
		this.VTrainform = VTrainform;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public String getVFilename() {
		return this.VFilename;
	}

	public void setVFilename(String VFilename) {
		this.VFilename = VFilename;
	}

	public Clob getTSign() {
		return this.TSign;
	}

	public void setTSign(Clob TSign) {
		this.TSign = TSign;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTrainlessonunits() {
		return this.trainlessonunits;
	}

	public void setTrainlessonunits(Set trainlessonunits) {
		this.trainlessonunits = trainlessonunits;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getTFlyreports() {
		return this.TFlyreports;
	}

	public void setTFlyreports(Set TFlyreports) {
		this.TFlyreports = TFlyreports;
	}

	public Set getTFlightTrainingrecords() {
		return this.TFlightTrainingrecords;
	}

	public void setTFlightTrainingrecords(Set TFlightTrainingrecords) {
		this.TFlightTrainingrecords = TFlightTrainingrecords;
	}

	public Set getOutLineAudits() {
		return this.outLineAudits;
	}

	public void setOutLineAudits(Set outLineAudits) {
		this.outLineAudits = outLineAudits;
	}

	public Set getTChangedoutlinesForVOlddgid() {
		return this.TChangedoutlinesForVOlddgid;
	}

	public void setTChangedoutlinesForVOlddgid(Set TChangedoutlinesForVOlddgid) {
		this.TChangedoutlinesForVOlddgid = TChangedoutlinesForVOlddgid;
	}

	public Set getTLessonFitChecks() {
		return this.TLessonFitChecks;
	}

	public void setTLessonFitChecks(Set TLessonFitChecks) {
		this.TLessonFitChecks = TLessonFitChecks;
	}

	public Set getTDgdistributions() {
		return this.TDgdistributions;
	}

	public void setTDgdistributions(Set TDgdistributions) {
		this.TDgdistributions = TDgdistributions;
	}

	public Set getTChangedoutlinesForVNewdgid() {
		return this.TChangedoutlinesForVNewdgid;
	}

	public void setTChangedoutlinesForVNewdgid(Set TChangedoutlinesForVNewdgid) {
		this.TChangedoutlinesForVNewdgid = TChangedoutlinesForVNewdgid;
	}

	public Set getTTeacherdgdistributions() {
		return this.TTeacherdgdistributions;
	}

	public void setTTeacherdgdistributions(Set TTeacherdgdistributions) {
		this.TTeacherdgdistributions = TTeacherdgdistributions;
	}

}