package com.cauc.training.pojos;

import java.util.Date;

/**
 * TPassrecordeditor entity. @author MyEclipse Persistence Tools
 */

public class TPassrecordeditor implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private String VReason;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TPassrecordeditor() {
	}

	/** full constructor */
	public TPassrecordeditor(TUser TUser,
			TFlightTrainingrecord TFlightTrainingrecord, String VReason,
			Date DCreatedate) {
		this.TUser = TUser;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.VReason = VReason;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}