package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TPhase entity. @author MyEclipse Persistence Tools
 */

public class TPhase implements java.io.Serializable {

	// Fields

	private String VId;
	private Trainlessonunit trainlessonunit;
	private TUser TUser;
	private String VName;
	private String VNo;
	private String VConditions;
	private String VPassstandard;
	private Date DCreatedate;
	private Set traininglessonRelations = new HashSet(0);

	// Constructors

	/** default constructor */
	public TPhase() {
	}

	/** minimal constructor */
	public TPhase(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TPhase(Trainlessonunit trainlessonunit, TUser TUser, String VName,
			String VNo, String VConditions, String VPassstandard,
			Date DCreatedate, Set traininglessonRelations) {
		this.trainlessonunit = trainlessonunit;
		this.TUser = TUser;
		this.VName = VName;
		this.VNo = VNo;
		this.VConditions = VConditions;
		this.VPassstandard = VPassstandard;
		this.DCreatedate = DCreatedate;
		this.traininglessonRelations = traininglessonRelations;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Trainlessonunit getTrainlessonunit() {
		return this.trainlessonunit;
	}

	public void setTrainlessonunit(Trainlessonunit trainlessonunit) {
		this.trainlessonunit = trainlessonunit;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVNo() {
		return this.VNo;
	}

	public void setVNo(String VNo) {
		this.VNo = VNo;
	}

	public String getVConditions() {
		return this.VConditions;
	}

	public void setVConditions(String VConditions) {
		this.VConditions = VConditions;
	}

	public String getVPassstandard() {
		return this.VPassstandard;
	}

	public void setVPassstandard(String VPassstandard) {
		this.VPassstandard = VPassstandard;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTraininglessonRelations() {
		return this.traininglessonRelations;
	}

	public void setTraininglessonRelations(Set traininglessonRelations) {
		this.traininglessonRelations = traininglessonRelations;
	}

}