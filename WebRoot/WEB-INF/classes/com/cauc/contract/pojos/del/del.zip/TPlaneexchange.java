package com.cauc.training.pojos;

import java.util.Date;

/**
 * TPlaneexchange entity. @author MyEclipse Persistence Tools
 */

public class TPlaneexchange implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrgByVOldbase;
	private TUser TUser;
	private TOrg TOrgByVNewbase;
	private Planeinfo planeinfo;
	private Date DEcchange;
	private Date DCreateDate;
	private String VReason;
	private String VAccording;

	// Constructors

	/** default constructor */
	public TPlaneexchange() {
	}

	/** minimal constructor */
	public TPlaneexchange(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TPlaneexchange(TOrg TOrgByVOldbase, TUser TUser,
			TOrg TOrgByVNewbase, Planeinfo planeinfo, Date DEcchange,
			Date DCreateDate, String VReason, String VAccording) {
		this.TOrgByVOldbase = TOrgByVOldbase;
		this.TUser = TUser;
		this.TOrgByVNewbase = TOrgByVNewbase;
		this.planeinfo = planeinfo;
		this.DEcchange = DEcchange;
		this.DCreateDate = DCreateDate;
		this.VReason = VReason;
		this.VAccording = VAccording;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrgByVOldbase() {
		return this.TOrgByVOldbase;
	}

	public void setTOrgByVOldbase(TOrg TOrgByVOldbase) {
		this.TOrgByVOldbase = TOrgByVOldbase;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TOrg getTOrgByVNewbase() {
		return this.TOrgByVNewbase;
	}

	public void setTOrgByVNewbase(TOrg TOrgByVNewbase) {
		this.TOrgByVNewbase = TOrgByVNewbase;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Date getDEcchange() {
		return this.DEcchange;
	}

	public void setDEcchange(Date DEcchange) {
		this.DEcchange = DEcchange;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public String getVAccording() {
		return this.VAccording;
	}

	public void setVAccording(String VAccording) {
		this.VAccording = VAccording;
	}

}