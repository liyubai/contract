package com.cauc.training.pojos;

import java.util.Date;

/**
 * TPlanerelease entity. @author MyEclipse Persistence Tools
 */

public class TPlanerelease implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private Planeinfo planeinfo;
	private double DFlytime;
	private Date DReleasetime;
	private Date DRecycletime;
	private Integer IAuditStatus;
	private Date DCreateDate;
	private Integer IType;
	private String VReason;
	private double DKongzhong;
	private Integer IEngineStart;
	private Integer IEngineEnd;

	// Constructors

	/** default constructor */
	public TPlanerelease() {
	}

	/** minimal constructor */
	public TPlanerelease(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TPlanerelease(TUser TUser, Planeinfo planeinfo, double DFlytime,
			Date DReleasetime, Date DRecycletime, Integer IAuditStatus,
			Date DCreateDate, Integer IType, String VReason, double DKongzhong,
			Integer IEngineStart, Integer IEngineEnd) {
		this.TUser = TUser;
		this.planeinfo = planeinfo;
		this.DFlytime = DFlytime;
		this.DReleasetime = DReleasetime;
		this.DRecycletime = DRecycletime;
		this.IAuditStatus = IAuditStatus;
		this.DCreateDate = DCreateDate;
		this.IType = IType;
		this.VReason = VReason;
		this.DKongzhong = DKongzhong;
		this.IEngineStart = IEngineStart;
		this.IEngineEnd = IEngineEnd;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public double getDFlytime() {
		return this.DFlytime;
	}

	public void setDFlytime(double DFlytime) {
		this.DFlytime = DFlytime;
	}

	public Date getDReleasetime() {
		return this.DReleasetime;
	}

	public void setDReleasetime(Date DReleasetime) {
		this.DReleasetime = DReleasetime;
	}

	public Date getDRecycletime() {
		return this.DRecycletime;
	}

	public void setDRecycletime(Date DRecycletime) {
		this.DRecycletime = DRecycletime;
	}

	public Integer getIAuditStatus() {
		return this.IAuditStatus;
	}

	public void setIAuditStatus(Integer IAuditStatus) {
		this.IAuditStatus = IAuditStatus;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public double getDKongzhong() {
		return this.DKongzhong;
	}

	public void setDKongzhong(double DKongzhong) {
		this.DKongzhong = DKongzhong;
	}

	public Integer getIEngineStart() {
		return this.IEngineStart;
	}

	public void setIEngineStart(Integer IEngineStart) {
		this.IEngineStart = IEngineStart;
	}

	public Integer getIEngineEnd() {
		return this.IEngineEnd;
	}

	public void setIEngineEnd(Integer IEngineEnd) {
		this.IEngineEnd = IEngineEnd;
	}

}