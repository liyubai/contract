package com.cauc.training.pojos;

import java.util.Date;

/**
 * TPointLine entity. @author MyEclipse Persistence Tools
 */

public class TPointLine implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TSetClass TSetClass;
	private TLesson TLesson;
	private double DPointLine;
	private Date DCreatedate;
	private double DBkpointLine;
	private Integer IBktimes;
	private Integer IDays;

	// Constructors

	/** default constructor */
	public TPointLine() {
	}

	/** minimal constructor */
	public TPointLine(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TPointLine(TUser TUser, TSetClass TSetClass, TLesson TLesson,
			double DPointLine, Date DCreatedate, double DBkpointLine,
			Integer IBktimes, Integer IDays) {
		this.TUser = TUser;
		this.TSetClass = TSetClass;
		this.TLesson = TLesson;
		this.DPointLine = DPointLine;
		this.DCreatedate = DCreatedate;
		this.DBkpointLine = DBkpointLine;
		this.IBktimes = IBktimes;
		this.IDays = IDays;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TSetClass getTSetClass() {
		return this.TSetClass;
	}

	public void setTSetClass(TSetClass TSetClass) {
		this.TSetClass = TSetClass;
	}

	public TLesson getTLesson() {
		return this.TLesson;
	}

	public void setTLesson(TLesson TLesson) {
		this.TLesson = TLesson;
	}

	public double getDPointLine() {
		return this.DPointLine;
	}

	public void setDPointLine(double DPointLine) {
		this.DPointLine = DPointLine;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public double getDBkpointLine() {
		return this.DBkpointLine;
	}

	public void setDBkpointLine(double DBkpointLine) {
		this.DBkpointLine = DBkpointLine;
	}

	public Integer getIBktimes() {
		return this.IBktimes;
	}

	public void setIBktimes(Integer IBktimes) {
		this.IBktimes = IBktimes;
	}

	public Integer getIDays() {
		return this.IDays;
	}

	public void setIDays(Integer IDays) {
		this.IDays = IDays;
	}

}