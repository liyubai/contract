package com.cauc.training.pojos;

import java.util.Date;

/**
 * TReplaceapproval entity. @author MyEclipse Persistence Tools
 */

public class TReplaceapproval implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private Date DCreatedate;
	private String VReason;

	// Constructors

	/** default constructor */
	public TReplaceapproval() {
	}

	/** full constructor */
	public TReplaceapproval(TUser TUser,
			TFlightTrainingrecord TFlightTrainingrecord, Date DCreatedate,
			String VReason) {
		this.TUser = TUser;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.DCreatedate = DCreatedate;
		this.VReason = VReason;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

}