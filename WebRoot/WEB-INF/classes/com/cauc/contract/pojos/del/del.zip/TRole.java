package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TRole entity. @author MyEclipse Persistence Tools
 */

public class TRole implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private String VDescription;
	private Date DCreateDate;
	private Set TRoleFunctions = new HashSet(0);
	private Set TUserRightses = new HashSet(0);

	// Constructors

	/** default constructor */
	public TRole() {
	}

	/** minimal constructor */
	public TRole(TUser TUser, String VName, Date DCreateDate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TRole(TUser TUser, String VName, String VDescription,
			Date DCreateDate, Set TRoleFunctions, Set TUserRightses) {
		this.TUser = TUser;
		this.VName = VName;
		this.VDescription = VDescription;
		this.DCreateDate = DCreateDate;
		this.TRoleFunctions = TRoleFunctions;
		this.TUserRightses = TUserRightses;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVDescription() {
		return this.VDescription;
	}

	public void setVDescription(String VDescription) {
		this.VDescription = VDescription;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Set getTRoleFunctions() {
		return this.TRoleFunctions;
	}

	public void setTRoleFunctions(Set TRoleFunctions) {
		this.TRoleFunctions = TRoleFunctions;
	}

	public Set getTUserRightses() {
		return this.TUserRightses;
	}

	public void setTUserRightses(Set TUserRightses) {
		this.TUserRightses = TUserRightses;
	}

}