package com.cauc.training.pojos;

import java.util.Date;

/**
 * TRoleFunction entity. @author MyEclipse Persistence Tools
 */

public class TRoleFunction implements java.io.Serializable {

	// Fields

	private String VId;
	private TRole TRole;
	private TUser TUser;
	private TFunction TFunction;
	private Date DCreateDate;
	private Integer IIsWrite;

	// Constructors

	/** default constructor */
	public TRoleFunction() {
	}

	/** minimal constructor */
	public TRoleFunction(TRole TRole, TUser TUser, TFunction TFunction,
			Date DCreateDate) {
		this.TRole = TRole;
		this.TUser = TUser;
		this.TFunction = TFunction;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TRoleFunction(TRole TRole, TUser TUser, TFunction TFunction,
			Date DCreateDate, Integer IIsWrite) {
		this.TRole = TRole;
		this.TUser = TUser;
		this.TFunction = TFunction;
		this.DCreateDate = DCreateDate;
		this.IIsWrite = IIsWrite;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TRole getTRole() {
		return this.TRole;
	}

	public void setTRole(TRole TRole) {
		this.TRole = TRole;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TFunction getTFunction() {
		return this.TFunction;
	}

	public void setTFunction(TFunction TFunction) {
		this.TFunction = TFunction;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Integer getIIsWrite() {
		return this.IIsWrite;
	}

	public void setIIsWrite(Integer IIsWrite) {
		this.IIsWrite = IIsWrite;
	}

}