package com.cauc.training.pojos;

import java.util.Date;

/**
 * TSchoolchangedbase entity. @author MyEclipse Persistence Tools
 */

public class TSchoolchangedbase implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDiction;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DChangedtime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TSchoolchangedbase() {
	}

	/** minimal constructor */
	public TSchoolchangedbase(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TSchoolchangedbase(TDiction TDiction, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DChangedtime, Date DCreatedate) {
		this.TDiction = TDiction;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DChangedtime = DChangedtime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDChangedtime() {
		return this.DChangedtime;
	}

	public void setDChangedtime(Date DChangedtime) {
		this.DChangedtime = DChangedtime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}