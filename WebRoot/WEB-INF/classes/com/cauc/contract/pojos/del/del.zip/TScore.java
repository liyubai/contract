package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TScore entity. @author MyEclipse Persistence Tools
 */

public class TScore implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUserByVAuditUserId;
	private TUser TUserByVCreateUserId;
	private TSetClass TSetClass;
	private TLesson TLesson;
	private StudentBaseInfo studentBaseInfo;
	private double DScore;
	private Date DExamTime;
	private Integer ITimes;
	private Integer IPass;
	private Integer IAudit;
	private Date DCreateDate;
	private Date DAuditDate;
	private Set THistoryscores = new HashSet(0);
	private Set TScoreAuditRecords = new HashSet(0);

	// Constructors

	/** default constructor */
	public TScore() {
	}

	/** minimal constructor */
	public TScore(TUser TUserByVCreateUserId, Date DCreateDate) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TScore(TUser TUserByVAuditUserId, TUser TUserByVCreateUserId,
			TSetClass TSetClass, TLesson TLesson,
			StudentBaseInfo studentBaseInfo, double DScore, Date DExamTime,
			Integer ITimes, Integer IPass, Integer IAudit, Date DCreateDate,
			Date DAuditDate, Set THistoryscores, Set TScoreAuditRecords) {
		this.TUserByVAuditUserId = TUserByVAuditUserId;
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.TSetClass = TSetClass;
		this.TLesson = TLesson;
		this.studentBaseInfo = studentBaseInfo;
		this.DScore = DScore;
		this.DExamTime = DExamTime;
		this.ITimes = ITimes;
		this.IPass = IPass;
		this.IAudit = IAudit;
		this.DCreateDate = DCreateDate;
		this.DAuditDate = DAuditDate;
		this.THistoryscores = THistoryscores;
		this.TScoreAuditRecords = TScoreAuditRecords;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUserByVAuditUserId() {
		return this.TUserByVAuditUserId;
	}

	public void setTUserByVAuditUserId(TUser TUserByVAuditUserId) {
		this.TUserByVAuditUserId = TUserByVAuditUserId;
	}

	public TUser getTUserByVCreateUserId() {
		return this.TUserByVCreateUserId;
	}

	public void setTUserByVCreateUserId(TUser TUserByVCreateUserId) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
	}

	public TSetClass getTSetClass() {
		return this.TSetClass;
	}

	public void setTSetClass(TSetClass TSetClass) {
		this.TSetClass = TSetClass;
	}

	public TLesson getTLesson() {
		return this.TLesson;
	}

	public void setTLesson(TLesson TLesson) {
		this.TLesson = TLesson;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public Date getDExamTime() {
		return this.DExamTime;
	}

	public void setDExamTime(Date DExamTime) {
		this.DExamTime = DExamTime;
	}

	public Integer getITimes() {
		return this.ITimes;
	}

	public void setITimes(Integer ITimes) {
		this.ITimes = ITimes;
	}

	public Integer getIPass() {
		return this.IPass;
	}

	public void setIPass(Integer IPass) {
		this.IPass = IPass;
	}

	public Integer getIAudit() {
		return this.IAudit;
	}

	public void setIAudit(Integer IAudit) {
		this.IAudit = IAudit;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Date getDAuditDate() {
		return this.DAuditDate;
	}

	public void setDAuditDate(Date DAuditDate) {
		this.DAuditDate = DAuditDate;
	}

	public Set getTHistoryscores() {
		return this.THistoryscores;
	}

	public void setTHistoryscores(Set THistoryscores) {
		this.THistoryscores = THistoryscores;
	}

	public Set getTScoreAuditRecords() {
		return this.TScoreAuditRecords;
	}

	public void setTScoreAuditRecords(Set TScoreAuditRecords) {
		this.TScoreAuditRecords = TScoreAuditRecords;
	}

}