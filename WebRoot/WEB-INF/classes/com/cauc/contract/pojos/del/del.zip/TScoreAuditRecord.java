package com.cauc.training.pojos;

import java.util.Date;

/**
 * TScoreAuditRecord entity. @author MyEclipse Persistence Tools
 */

public class TScoreAuditRecord implements java.io.Serializable {

	// Fields

	private String VId;
	private TScore TScore;
	private TUser TUser;
	private Integer IAudit;
	private String VReason;
	private Date DAuditDate;

	// Constructors

	/** default constructor */
	public TScoreAuditRecord() {
	}

	/** full constructor */
	public TScoreAuditRecord(TScore TScore, TUser TUser, Integer IAudit,
			String VReason, Date DAuditDate) {
		this.TScore = TScore;
		this.TUser = TUser;
		this.IAudit = IAudit;
		this.VReason = VReason;
		this.DAuditDate = DAuditDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TScore getTScore() {
		return this.TScore;
	}

	public void setTScore(TScore TScore) {
		this.TScore = TScore;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Integer getIAudit() {
		return this.IAudit;
	}

	public void setIAudit(Integer IAudit) {
		this.IAudit = IAudit;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDAuditDate() {
		return this.DAuditDate;
	}

	public void setDAuditDate(Date DAuditDate) {
		this.DAuditDate = DAuditDate;
	}

}