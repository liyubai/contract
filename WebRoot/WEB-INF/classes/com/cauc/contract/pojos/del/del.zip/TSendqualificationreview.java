package com.cauc.training.pojos;

import java.util.Date;

/**
 * TSendqualificationreview entity. @author MyEclipse Persistence Tools
 */

public class TSendqualificationreview implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Integer IType;
	private Integer IResult;
	private String VReason;
	private Date DNextchecktime;
	private Date DChecktime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TSendqualificationreview() {
	}

	/** minimal constructor */
	public TSendqualificationreview(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TSendqualificationreview(TUser TUser,
			StudentBaseInfo studentBaseInfo, Integer IType, Integer IResult,
			String VReason, Date DNextchecktime, Date DChecktime,
			Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.IType = IType;
		this.IResult = IResult;
		this.VReason = VReason;
		this.DNextchecktime = DNextchecktime;
		this.DChecktime = DChecktime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Integer getIResult() {
		return this.IResult;
	}

	public void setIResult(Integer IResult) {
		this.IResult = IResult;
	}

	public String getVReason() {
		return this.VReason;
	}

	public void setVReason(String VReason) {
		this.VReason = VReason;
	}

	public Date getDNextchecktime() {
		return this.DNextchecktime;
	}

	public void setDNextchecktime(Date DNextchecktime) {
		this.DNextchecktime = DNextchecktime;
	}

	public Date getDChecktime() {
		return this.DChecktime;
	}

	public void setDChecktime(Date DChecktime) {
		this.DChecktime = DChecktime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}