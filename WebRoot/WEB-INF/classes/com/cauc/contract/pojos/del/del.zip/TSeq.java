package com.cauc.training.pojos;

/**
 * TSeq entity. @author MyEclipse Persistence Tools
 */

public class TSeq implements java.io.Serializable {

	// Fields

	private String id;
	private String obj;
	private long nextId;
	private long cacheSize;

	// Constructors

	/** default constructor */
	public TSeq() {
	}

	/** full constructor */
	public TSeq(String obj, long nextId, long cacheSize) {
		this.obj = obj;
		this.nextId = nextId;
		this.cacheSize = cacheSize;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getObj() {
		return this.obj;
	}

	public void setObj(String obj) {
		this.obj = obj;
	}

	public long getNextId() {
		return this.nextId;
	}

	public void setNextId(long nextId) {
		this.nextId = nextId;
	}

	public long getCacheSize() {
		return this.cacheSize;
	}

	public void setCacheSize(long cacheSize) {
		this.cacheSize = cacheSize;
	}

}