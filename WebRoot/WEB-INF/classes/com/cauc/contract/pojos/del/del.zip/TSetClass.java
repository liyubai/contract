package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TSetClass entity. @author MyEclipse Persistence Tools
 */

public class TSetClass implements java.io.Serializable {

	// Fields

	private String VId;
	private TOtheruser TOtheruser;
	private TUser TUser;
	private String VClassid;
	private String VName;
	private Date DCreateClassTime;
	private Date DBeginLessionTime;
	private Date DEndLessionTime;
	private Integer IModel;
	private Date DCreatedate;
	private Integer IType;
	private Set TPointLines = new HashSet(0);
	private Set studentDistributionClasses = new HashSet(0);
	private Set recommendStudentLicenseExams = new HashSet(0);
	private Set TScores = new HashSet(0);

	// Constructors

	/** default constructor */
	public TSetClass() {
	}

	/** minimal constructor */
	public TSetClass(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TSetClass(TOtheruser TOtheruser, TUser TUser, String VClassid,
			String VName, Date DCreateClassTime, Date DBeginLessionTime,
			Date DEndLessionTime, Integer IModel, Date DCreatedate,
			Integer IType, Set TPointLines, Set studentDistributionClasses,
			Set recommendStudentLicenseExams, Set TScores) {
		this.TOtheruser = TOtheruser;
		this.TUser = TUser;
		this.VClassid = VClassid;
		this.VName = VName;
		this.DCreateClassTime = DCreateClassTime;
		this.DBeginLessionTime = DBeginLessionTime;
		this.DEndLessionTime = DEndLessionTime;
		this.IModel = IModel;
		this.DCreatedate = DCreatedate;
		this.IType = IType;
		this.TPointLines = TPointLines;
		this.studentDistributionClasses = studentDistributionClasses;
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
		this.TScores = TScores;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOtheruser getTOtheruser() {
		return this.TOtheruser;
	}

	public void setTOtheruser(TOtheruser TOtheruser) {
		this.TOtheruser = TOtheruser;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVClassid() {
		return this.VClassid;
	}

	public void setVClassid(String VClassid) {
		this.VClassid = VClassid;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreateClassTime() {
		return this.DCreateClassTime;
	}

	public void setDCreateClassTime(Date DCreateClassTime) {
		this.DCreateClassTime = DCreateClassTime;
	}

	public Date getDBeginLessionTime() {
		return this.DBeginLessionTime;
	}

	public void setDBeginLessionTime(Date DBeginLessionTime) {
		this.DBeginLessionTime = DBeginLessionTime;
	}

	public Date getDEndLessionTime() {
		return this.DEndLessionTime;
	}

	public void setDEndLessionTime(Date DEndLessionTime) {
		this.DEndLessionTime = DEndLessionTime;
	}

	public Integer getIModel() {
		return this.IModel;
	}

	public void setIModel(Integer IModel) {
		this.IModel = IModel;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Set getTPointLines() {
		return this.TPointLines;
	}

	public void setTPointLines(Set TPointLines) {
		this.TPointLines = TPointLines;
	}

	public Set getStudentDistributionClasses() {
		return this.studentDistributionClasses;
	}

	public void setStudentDistributionClasses(Set studentDistributionClasses) {
		this.studentDistributionClasses = studentDistributionClasses;
	}

	public Set getRecommendStudentLicenseExams() {
		return this.recommendStudentLicenseExams;
	}

	public void setRecommendStudentLicenseExams(Set recommendStudentLicenseExams) {
		this.recommendStudentLicenseExams = recommendStudentLicenseExams;
	}

	public Set getTScores() {
		return this.TScores;
	}

	public void setTScores(Set TScores) {
		this.TScores = TScores;
	}

}