package com.cauc.training.pojos;

import java.util.Date;

/**
 * TSimulatorinfo entity. @author MyEclipse Persistence Tools
 */

public class TSimulatorinfo implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrg;
	private TUser TUser;
	private String VPlaneform;
	private String VFrom;
	private Date DEnterdate;
	private Integer ITimes;
	private double DUsetime;
	private String VHgz;
	private Integer IStatus;
	private String VDw;
	private String VBz;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public TSimulatorinfo() {
	}

	/** minimal constructor */
	public TSimulatorinfo(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TSimulatorinfo(TOrg TOrg, TUser TUser, String VPlaneform,
			String VFrom, Date DEnterdate, Integer ITimes, double DUsetime,
			String VHgz, Integer IStatus, String VDw, String VBz,
			Date DCreateDate) {
		this.TOrg = TOrg;
		this.TUser = TUser;
		this.VPlaneform = VPlaneform;
		this.VFrom = VFrom;
		this.DEnterdate = DEnterdate;
		this.ITimes = ITimes;
		this.DUsetime = DUsetime;
		this.VHgz = VHgz;
		this.IStatus = IStatus;
		this.VDw = VDw;
		this.VBz = VBz;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVPlaneform() {
		return this.VPlaneform;
	}

	public void setVPlaneform(String VPlaneform) {
		this.VPlaneform = VPlaneform;
	}

	public String getVFrom() {
		return this.VFrom;
	}

	public void setVFrom(String VFrom) {
		this.VFrom = VFrom;
	}

	public Date getDEnterdate() {
		return this.DEnterdate;
	}

	public void setDEnterdate(Date DEnterdate) {
		this.DEnterdate = DEnterdate;
	}

	public Integer getITimes() {
		return this.ITimes;
	}

	public void setITimes(Integer ITimes) {
		this.ITimes = ITimes;
	}

	public double getDUsetime() {
		return this.DUsetime;
	}

	public void setDUsetime(double DUsetime) {
		this.DUsetime = DUsetime;
	}

	public String getVHgz() {
		return this.VHgz;
	}

	public void setVHgz(String VHgz) {
		this.VHgz = VHgz;
	}

	public Integer getIStatus() {
		return this.IStatus;
	}

	public void setIStatus(Integer IStatus) {
		this.IStatus = IStatus;
	}

	public String getVDw() {
		return this.VDw;
	}

	public void setVDw(String VDw) {
		this.VDw = VDw;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}