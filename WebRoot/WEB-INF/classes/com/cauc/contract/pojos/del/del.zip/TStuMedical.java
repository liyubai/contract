package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TStuMedical entity. @author MyEclipse Persistence Tools
 */

public class TStuMedical implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Integer ILevel;
	private String VNation;
	private String VLimit;
	private Date DResultdate;
	private String VDoctor;
	private String VIssuer;
	private Date DIssueTime;
	private Date DUsedTime;
	private String VCompany;
	private Date DCreateDate;
	private Set TStuMedicalhistories = new HashSet(0);

	// Constructors

	/** default constructor */
	public TStuMedical() {
	}

	/** minimal constructor */
	public TStuMedical(TUser TUser, Date DCreateDate) {
		this.TUser = TUser;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TStuMedical(TUser TUser, StudentBaseInfo studentBaseInfo,
			Integer ILevel, String VNation, String VLimit, Date DResultdate,
			String VDoctor, String VIssuer, Date DIssueTime, Date DUsedTime,
			String VCompany, Date DCreateDate, Set TStuMedicalhistories) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.ILevel = ILevel;
		this.VNation = VNation;
		this.VLimit = VLimit;
		this.DResultdate = DResultdate;
		this.VDoctor = VDoctor;
		this.VIssuer = VIssuer;
		this.DIssueTime = DIssueTime;
		this.DUsedTime = DUsedTime;
		this.VCompany = VCompany;
		this.DCreateDate = DCreateDate;
		this.TStuMedicalhistories = TStuMedicalhistories;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Integer getILevel() {
		return this.ILevel;
	}

	public void setILevel(Integer ILevel) {
		this.ILevel = ILevel;
	}

	public String getVNation() {
		return this.VNation;
	}

	public void setVNation(String VNation) {
		this.VNation = VNation;
	}

	public String getVLimit() {
		return this.VLimit;
	}

	public void setVLimit(String VLimit) {
		this.VLimit = VLimit;
	}

	public Date getDResultdate() {
		return this.DResultdate;
	}

	public void setDResultdate(Date DResultdate) {
		this.DResultdate = DResultdate;
	}

	public String getVDoctor() {
		return this.VDoctor;
	}

	public void setVDoctor(String VDoctor) {
		this.VDoctor = VDoctor;
	}

	public String getVIssuer() {
		return this.VIssuer;
	}

	public void setVIssuer(String VIssuer) {
		this.VIssuer = VIssuer;
	}

	public Date getDIssueTime() {
		return this.DIssueTime;
	}

	public void setDIssueTime(Date DIssueTime) {
		this.DIssueTime = DIssueTime;
	}

	public Date getDUsedTime() {
		return this.DUsedTime;
	}

	public void setDUsedTime(Date DUsedTime) {
		this.DUsedTime = DUsedTime;
	}

	public String getVCompany() {
		return this.VCompany;
	}

	public void setVCompany(String VCompany) {
		this.VCompany = VCompany;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Set getTStuMedicalhistories() {
		return this.TStuMedicalhistories;
	}

	public void setTStuMedicalhistories(Set TStuMedicalhistories) {
		this.TStuMedicalhistories = TStuMedicalhistories;
	}

}