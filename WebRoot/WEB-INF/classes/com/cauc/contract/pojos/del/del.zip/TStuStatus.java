package com.cauc.training.pojos;

import java.util.Date;

/**
 * TStuStatus entity. @author MyEclipse Persistence Tools
 */

public class TStuStatus implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDictionByVOldstatusid;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private TDiction TDictionByVNewstatusid;
	private String VComment;
	private Date DChangestatustime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TStuStatus() {
	}

	/** full constructor */
	public TStuStatus(TDiction TDictionByVOldstatusid, TUser TUser,
			StudentBaseInfo studentBaseInfo, TDiction TDictionByVNewstatusid,
			String VComment, Date DChangestatustime, Date DCreatedate) {
		this.TDictionByVOldstatusid = TDictionByVOldstatusid;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.TDictionByVNewstatusid = TDictionByVNewstatusid;
		this.VComment = VComment;
		this.DChangestatustime = DChangestatustime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDictionByVOldstatusid() {
		return this.TDictionByVOldstatusid;
	}

	public void setTDictionByVOldstatusid(TDiction TDictionByVOldstatusid) {
		this.TDictionByVOldstatusid = TDictionByVOldstatusid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public TDiction getTDictionByVNewstatusid() {
		return this.TDictionByVNewstatusid;
	}

	public void setTDictionByVNewstatusid(TDiction TDictionByVNewstatusid) {
		this.TDictionByVNewstatusid = TDictionByVNewstatusid;
	}

	public String getVComment() {
		return this.VComment;
	}

	public void setVComment(String VComment) {
		this.VComment = VComment;
	}

	public Date getDChangestatustime() {
		return this.DChangestatustime;
	}

	public void setDChangestatustime(Date DChangestatustime) {
		this.DChangestatustime = DChangestatustime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}