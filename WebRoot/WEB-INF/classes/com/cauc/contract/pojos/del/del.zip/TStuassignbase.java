package com.cauc.training.pojos;

import java.util.Date;

/**
 * TStuassignbase entity. @author MyEclipse Persistence Tools
 */

public class TStuassignbase implements java.io.Serializable {

	// Fields

	private String VId;
	private TOrg TOrg;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DReportdate;
	private Date DAssigntime;
	private Date DStarttraindate;
	private Date DFinishtraindate;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TStuassignbase() {
	}

	/** minimal constructor */
	public TStuassignbase(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TStuassignbase(TOrg TOrg, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DReportdate,
			Date DAssigntime, Date DStarttraindate, Date DFinishtraindate,
			Date DCreatedate) {
		this.TOrg = TOrg;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DReportdate = DReportdate;
		this.DAssigntime = DAssigntime;
		this.DStarttraindate = DStarttraindate;
		this.DFinishtraindate = DFinishtraindate;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDReportdate() {
		return this.DReportdate;
	}

	public void setDReportdate(Date DReportdate) {
		this.DReportdate = DReportdate;
	}

	public Date getDAssigntime() {
		return this.DAssigntime;
	}

	public void setDAssigntime(Date DAssigntime) {
		this.DAssigntime = DAssigntime;
	}

	public Date getDStarttraindate() {
		return this.DStarttraindate;
	}

	public void setDStarttraindate(Date DStarttraindate) {
		this.DStarttraindate = DStarttraindate;
	}

	public Date getDFinishtraindate() {
		return this.DFinishtraindate;
	}

	public void setDFinishtraindate(Date DFinishtraindate) {
		this.DFinishtraindate = DFinishtraindate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}