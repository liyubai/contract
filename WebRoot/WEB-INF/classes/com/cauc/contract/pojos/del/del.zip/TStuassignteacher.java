package com.cauc.training.pojos;

import java.util.Date;

/**
 * TStuassignteacher entity. @author MyEclipse Persistence Tools
 */

public class TStuassignteacher implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfo;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DAssigndate;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TStuassignteacher() {
	}

	/** minimal constructor */
	public TStuassignteacher(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TStuassignteacher(TeacherBaseInfo teacherBaseInfo, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DAssigndate, Date DCreatedate) {
		this.teacherBaseInfo = teacherBaseInfo;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DAssigndate = DAssigndate;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDAssigndate() {
		return this.DAssigndate;
	}

	public void setDAssigndate(Date DAssigndate) {
		this.DAssigndate = DAssigndate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}