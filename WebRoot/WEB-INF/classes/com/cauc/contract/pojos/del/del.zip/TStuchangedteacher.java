package com.cauc.training.pojos;

import java.util.Date;

/**
 * TStuchangedteacher entity. @author MyEclipse Persistence Tools
 */

public class TStuchangedteacher implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfoByVNewteacherid;
	private TeacherBaseInfo teacherBaseInfoByVOldteacherid;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DChangeddate;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TStuchangedteacher() {
	}

	/** minimal constructor */
	public TStuchangedteacher(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TStuchangedteacher(TeacherBaseInfo teacherBaseInfoByVNewteacherid,
			TeacherBaseInfo teacherBaseInfoByVOldteacherid, TUser TUser,
			StudentBaseInfo studentBaseInfo, Date DChangeddate, Date DCreatedate) {
		this.teacherBaseInfoByVNewteacherid = teacherBaseInfoByVNewteacherid;
		this.teacherBaseInfoByVOldteacherid = teacherBaseInfoByVOldteacherid;
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DChangeddate = DChangeddate;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVNewteacherid() {
		return this.teacherBaseInfoByVNewteacherid;
	}

	public void setTeacherBaseInfoByVNewteacherid(
			TeacherBaseInfo teacherBaseInfoByVNewteacherid) {
		this.teacherBaseInfoByVNewteacherid = teacherBaseInfoByVNewteacherid;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVOldteacherid() {
		return this.teacherBaseInfoByVOldteacherid;
	}

	public void setTeacherBaseInfoByVOldteacherid(
			TeacherBaseInfo teacherBaseInfoByVOldteacherid) {
		this.teacherBaseInfoByVOldteacherid = teacherBaseInfoByVOldteacherid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDChangeddate() {
		return this.DChangeddate;
	}

	public void setDChangeddate(Date DChangeddate) {
		this.DChangeddate = DChangeddate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}