package com.cauc.training.pojos;

import java.util.Date;

/**
 * TStustopfly entity. @author MyEclipse Persistence Tools
 */

public class TStustopfly implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private StudentBaseInfo studentBaseInfo;
	private Date DStopflytime;
	private String VStopflyreason;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TStustopfly() {
	}

	/** minimal constructor */
	public TStustopfly(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TStustopfly(TUser TUser, StudentBaseInfo studentBaseInfo,
			Date DStopflytime, String VStopflyreason, Date DCreatedate) {
		this.TUser = TUser;
		this.studentBaseInfo = studentBaseInfo;
		this.DStopflytime = DStopflytime;
		this.VStopflyreason = VStopflyreason;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Date getDStopflytime() {
		return this.DStopflytime;
	}

	public void setDStopflytime(Date DStopflytime) {
		this.DStopflytime = DStopflytime;
	}

	public String getVStopflyreason() {
		return this.VStopflyreason;
	}

	public void setVStopflyreason(String VStopflyreason) {
		this.VStopflyreason = VStopflyreason;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}