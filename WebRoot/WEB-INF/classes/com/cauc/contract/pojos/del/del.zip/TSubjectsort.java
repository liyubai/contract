package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TSubjectsort entity. @author MyEclipse Persistence Tools
 */

public class TSubjectsort implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private String VName;
	private Date DCreatedate;
	private Integer IOrder;
	private Set TTrainsubjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public TSubjectsort() {
	}

	/** minimal constructor */
	public TSubjectsort(String VName) {
		this.VName = VName;
	}

	/** full constructor */
	public TSubjectsort(TUser TUser, String VName, Date DCreatedate,
			Integer IOrder, Set TTrainsubjects) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
		this.IOrder = IOrder;
		this.TTrainsubjects = TTrainsubjects;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public Set getTTrainsubjects() {
		return this.TTrainsubjects;
	}

	public void setTTrainsubjects(Set TTrainsubjects) {
		this.TTrainsubjects = TTrainsubjects;
	}

}