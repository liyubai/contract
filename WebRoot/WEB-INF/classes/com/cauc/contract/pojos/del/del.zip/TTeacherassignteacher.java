package com.cauc.training.pojos;

import java.util.Date;

/**
 * TTeacherassignteacher entity. @author MyEclipse Persistence Tools
 */

public class TTeacherassignteacher implements java.io.Serializable {

	// Fields

	private String VId;
	private TeacherBaseInfo teacherBaseInfoByVTeacherasstudentid;
	private TeacherBaseInfo teacherBaseInfoByVTeacherid;
	private TUser TUser;
	private Date DAssigndate;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TTeacherassignteacher() {
	}

	/** full constructor */
	public TTeacherassignteacher(
			TeacherBaseInfo teacherBaseInfoByVTeacherasstudentid,
			TeacherBaseInfo teacherBaseInfoByVTeacherid, TUser TUser,
			Date DAssigndate, Date DCreatedate) {
		this.teacherBaseInfoByVTeacherasstudentid = teacherBaseInfoByVTeacherasstudentid;
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
		this.TUser = TUser;
		this.DAssigndate = DAssigndate;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVTeacherasstudentid() {
		return this.teacherBaseInfoByVTeacherasstudentid;
	}

	public void setTeacherBaseInfoByVTeacherasstudentid(
			TeacherBaseInfo teacherBaseInfoByVTeacherasstudentid) {
		this.teacherBaseInfoByVTeacherasstudentid = teacherBaseInfoByVTeacherasstudentid;
	}

	public TeacherBaseInfo getTeacherBaseInfoByVTeacherid() {
		return this.teacherBaseInfoByVTeacherid;
	}

	public void setTeacherBaseInfoByVTeacherid(
			TeacherBaseInfo teacherBaseInfoByVTeacherid) {
		this.teacherBaseInfoByVTeacherid = teacherBaseInfoByVTeacherid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDAssigndate() {
		return this.DAssigndate;
	}

	public void setDAssigndate(Date DAssigndate) {
		this.DAssigndate = DAssigndate;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}