package com.cauc.training.pojos;

import java.util.Date;

/**
 * TTeacherdgdistribution entity. @author MyEclipse Persistence Tools
 */

public class TTeacherdgdistribution implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutline;
	private TUser TUser;
	private TeacherBaseInfo teacherBaseInfo;
	private String VContact;
	private Date DCreatedate;
	private Integer ICycle;
	private Integer IType;

	// Constructors

	/** default constructor */
	public TTeacherdgdistribution() {
	}

	/** minimal constructor */
	public TTeacherdgdistribution(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	/** full constructor */
	public TTeacherdgdistribution(TOutline TOutline, TUser TUser,
			TeacherBaseInfo teacherBaseInfo, String VContact, Date DCreatedate,
			Integer ICycle, Integer IType) {
		this.TOutline = TOutline;
		this.TUser = TUser;
		this.teacherBaseInfo = teacherBaseInfo;
		this.VContact = VContact;
		this.DCreatedate = DCreatedate;
		this.ICycle = ICycle;
		this.IType = IType;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public String getVContact() {
		return this.VContact;
	}

	public void setVContact(String VContact) {
		this.VContact = VContact;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getICycle() {
		return this.ICycle;
	}

	public void setICycle(Integer ICycle) {
		this.ICycle = ICycle;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

}