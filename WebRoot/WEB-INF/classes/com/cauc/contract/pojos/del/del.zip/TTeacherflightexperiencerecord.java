package com.cauc.training.pojos;

import java.util.Date;

/**
 * TTeacherflightexperiencerecord entity. @author MyEclipse Persistence Tools
 */

public class TTeacherflightexperiencerecord implements java.io.Serializable {

	// Fields

	private String VId;
	private Station stationByVLandpos;
	private TDiction TDiction;
	private TeacherBaseInfo teacherBaseInfo;
	private Station stationByVFlypos;
	private TTrainingLesson TTrainingLesson;
	private TFlightTrainingrecord TFlightTrainingrecord;
	private Planeinfo planeinfo;
	private Date DFlydate;
	private Date DStarttime;
	private Date DEndtime;
	private Integer IDaytimes;
	private Integer INeighttimes;
	private double DJiashiyuantime;
	private double DJizhangtime;
	private double DDanfeitime;
	private double DZhuanchangtime;
	private double DYejiantime;
	private double DFujiashitime;
	private double DDaifeitime;
	private double DFjszhuanchangtime;
	private double DFjszcyjtime;
	private double DMoniyibiaotime;
	private double DZhenshiyibiao;
	private String VTranpos;
	private double DMnjsj;
	private double DXlqsj;
	private double DTeachertime;
	private String VLhy;
	private String VTxy;
	private String VJxy;
	private String VBz;
	private String VImgname;

	// Constructors

	/** default constructor */
	public TTeacherflightexperiencerecord() {
	}

	/** minimal constructor */
	public TTeacherflightexperiencerecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	/** full constructor */
	public TTeacherflightexperiencerecord(Station stationByVLandpos,
			TDiction TDiction, TeacherBaseInfo teacherBaseInfo,
			Station stationByVFlypos, TTrainingLesson TTrainingLesson,
			TFlightTrainingrecord TFlightTrainingrecord, Planeinfo planeinfo,
			Date DFlydate, Date DStarttime, Date DEndtime, Integer IDaytimes,
			Integer INeighttimes, double DJiashiyuantime, double DJizhangtime,
			double DDanfeitime, double DZhuanchangtime, double DYejiantime,
			double DFujiashitime, double DDaifeitime,
			double DFjszhuanchangtime, double DFjszcyjtime,
			double DMoniyibiaotime, double DZhenshiyibiao, String VTranpos,
			double DMnjsj, double DXlqsj, double DTeachertime, String VLhy,
			String VTxy, String VJxy, String VBz, String VImgname) {
		this.stationByVLandpos = stationByVLandpos;
		this.TDiction = TDiction;
		this.teacherBaseInfo = teacherBaseInfo;
		this.stationByVFlypos = stationByVFlypos;
		this.TTrainingLesson = TTrainingLesson;
		this.TFlightTrainingrecord = TFlightTrainingrecord;
		this.planeinfo = planeinfo;
		this.DFlydate = DFlydate;
		this.DStarttime = DStarttime;
		this.DEndtime = DEndtime;
		this.IDaytimes = IDaytimes;
		this.INeighttimes = INeighttimes;
		this.DJiashiyuantime = DJiashiyuantime;
		this.DJizhangtime = DJizhangtime;
		this.DDanfeitime = DDanfeitime;
		this.DZhuanchangtime = DZhuanchangtime;
		this.DYejiantime = DYejiantime;
		this.DFujiashitime = DFujiashitime;
		this.DDaifeitime = DDaifeitime;
		this.DFjszhuanchangtime = DFjszhuanchangtime;
		this.DFjszcyjtime = DFjszcyjtime;
		this.DMoniyibiaotime = DMoniyibiaotime;
		this.DZhenshiyibiao = DZhenshiyibiao;
		this.VTranpos = VTranpos;
		this.DMnjsj = DMnjsj;
		this.DXlqsj = DXlqsj;
		this.DTeachertime = DTeachertime;
		this.VLhy = VLhy;
		this.VTxy = VTxy;
		this.VJxy = VJxy;
		this.VBz = VBz;
		this.VImgname = VImgname;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Station getStationByVLandpos() {
		return this.stationByVLandpos;
	}

	public void setStationByVLandpos(Station stationByVLandpos) {
		this.stationByVLandpos = stationByVLandpos;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public Station getStationByVFlypos() {
		return this.stationByVFlypos;
	}

	public void setStationByVFlypos(Station stationByVFlypos) {
		this.stationByVFlypos = stationByVFlypos;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public TFlightTrainingrecord getTFlightTrainingrecord() {
		return this.TFlightTrainingrecord;
	}

	public void setTFlightTrainingrecord(
			TFlightTrainingrecord TFlightTrainingrecord) {
		this.TFlightTrainingrecord = TFlightTrainingrecord;
	}

	public Planeinfo getPlaneinfo() {
		return this.planeinfo;
	}

	public void setPlaneinfo(Planeinfo planeinfo) {
		this.planeinfo = planeinfo;
	}

	public Date getDFlydate() {
		return this.DFlydate;
	}

	public void setDFlydate(Date DFlydate) {
		this.DFlydate = DFlydate;
	}

	public Date getDStarttime() {
		return this.DStarttime;
	}

	public void setDStarttime(Date DStarttime) {
		this.DStarttime = DStarttime;
	}

	public Date getDEndtime() {
		return this.DEndtime;
	}

	public void setDEndtime(Date DEndtime) {
		this.DEndtime = DEndtime;
	}

	public Integer getIDaytimes() {
		return this.IDaytimes;
	}

	public void setIDaytimes(Integer IDaytimes) {
		this.IDaytimes = IDaytimes;
	}

	public Integer getINeighttimes() {
		return this.INeighttimes;
	}

	public void setINeighttimes(Integer INeighttimes) {
		this.INeighttimes = INeighttimes;
	}

	public double getDJiashiyuantime() {
		return this.DJiashiyuantime;
	}

	public void setDJiashiyuantime(double DJiashiyuantime) {
		this.DJiashiyuantime = DJiashiyuantime;
	}

	public double getDJizhangtime() {
		return this.DJizhangtime;
	}

	public void setDJizhangtime(double DJizhangtime) {
		this.DJizhangtime = DJizhangtime;
	}

	public double getDDanfeitime() {
		return this.DDanfeitime;
	}

	public void setDDanfeitime(double DDanfeitime) {
		this.DDanfeitime = DDanfeitime;
	}

	public double getDZhuanchangtime() {
		return this.DZhuanchangtime;
	}

	public void setDZhuanchangtime(double DZhuanchangtime) {
		this.DZhuanchangtime = DZhuanchangtime;
	}

	public double getDYejiantime() {
		return this.DYejiantime;
	}

	public void setDYejiantime(double DYejiantime) {
		this.DYejiantime = DYejiantime;
	}

	public double getDFujiashitime() {
		return this.DFujiashitime;
	}

	public void setDFujiashitime(double DFujiashitime) {
		this.DFujiashitime = DFujiashitime;
	}

	public double getDDaifeitime() {
		return this.DDaifeitime;
	}

	public void setDDaifeitime(double DDaifeitime) {
		this.DDaifeitime = DDaifeitime;
	}

	public double getDFjszhuanchangtime() {
		return this.DFjszhuanchangtime;
	}

	public void setDFjszhuanchangtime(double DFjszhuanchangtime) {
		this.DFjszhuanchangtime = DFjszhuanchangtime;
	}

	public double getDFjszcyjtime() {
		return this.DFjszcyjtime;
	}

	public void setDFjszcyjtime(double DFjszcyjtime) {
		this.DFjszcyjtime = DFjszcyjtime;
	}

	public double getDMoniyibiaotime() {
		return this.DMoniyibiaotime;
	}

	public void setDMoniyibiaotime(double DMoniyibiaotime) {
		this.DMoniyibiaotime = DMoniyibiaotime;
	}

	public double getDZhenshiyibiao() {
		return this.DZhenshiyibiao;
	}

	public void setDZhenshiyibiao(double DZhenshiyibiao) {
		this.DZhenshiyibiao = DZhenshiyibiao;
	}

	public String getVTranpos() {
		return this.VTranpos;
	}

	public void setVTranpos(String VTranpos) {
		this.VTranpos = VTranpos;
	}

	public double getDMnjsj() {
		return this.DMnjsj;
	}

	public void setDMnjsj(double DMnjsj) {
		this.DMnjsj = DMnjsj;
	}

	public double getDXlqsj() {
		return this.DXlqsj;
	}

	public void setDXlqsj(double DXlqsj) {
		this.DXlqsj = DXlqsj;
	}

	public double getDTeachertime() {
		return this.DTeachertime;
	}

	public void setDTeachertime(double DTeachertime) {
		this.DTeachertime = DTeachertime;
	}

	public String getVLhy() {
		return this.VLhy;
	}

	public void setVLhy(String VLhy) {
		this.VLhy = VLhy;
	}

	public String getVTxy() {
		return this.VTxy;
	}

	public void setVTxy(String VTxy) {
		this.VTxy = VTxy;
	}

	public String getVJxy() {
		return this.VJxy;
	}

	public void setVJxy(String VJxy) {
		this.VJxy = VJxy;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public String getVImgname() {
		return this.VImgname;
	}

	public void setVImgname(String VImgname) {
		this.VImgname = VImgname;
	}

}