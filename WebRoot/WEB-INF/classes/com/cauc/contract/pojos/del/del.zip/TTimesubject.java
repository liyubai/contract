package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TTimesubject entity. @author MyEclipse Persistence Tools
 */

public class TTimesubject implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private TDiction TDiction;
	private String VName;
	private String VUnitid;
	private Date DCreatedate;
	private Set traininglessonSubjectRelations = new HashSet(0);

	// Constructors

	/** default constructor */
	public TTimesubject() {
	}

	/** minimal constructor */
	public TTimesubject(TUser TUser, TDiction TDiction, String VName,
			Date DCreatedate) {
		this.TUser = TUser;
		this.TDiction = TDiction;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TTimesubject(TUser TUser, TDiction TDiction, String VName,
			String VUnitid, Date DCreatedate, Set traininglessonSubjectRelations) {
		this.TUser = TUser;
		this.TDiction = TDiction;
		this.VName = VName;
		this.VUnitid = VUnitid;
		this.DCreatedate = DCreatedate;
		this.traininglessonSubjectRelations = traininglessonSubjectRelations;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TDiction getTDiction() {
		return this.TDiction;
	}

	public void setTDiction(TDiction TDiction) {
		this.TDiction = TDiction;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVUnitid() {
		return this.VUnitid;
	}

	public void setVUnitid(String VUnitid) {
		this.VUnitid = VUnitid;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Set getTraininglessonSubjectRelations() {
		return this.traininglessonSubjectRelations;
	}

	public void setTraininglessonSubjectRelations(
			Set traininglessonSubjectRelations) {
		this.traininglessonSubjectRelations = traininglessonSubjectRelations;
	}

}