package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TTrainingLesson entity. @author MyEclipse Persistence Tools
 */

public class TTrainingLesson implements java.io.Serializable {

	// Fields

	private String VId;
	private Station stationByVStartpos;
	private TUser TUser;
	private Station stationByVEndpos;
	private Integer IOrder;
	private String VNo;
	private Integer IAsciino;
	private String VName;
	private String VVersion;
	private Integer IAsciiversion;
	private Integer IType;
	private Integer IPlaneproperty;
	private Integer ITrainType;
	private Integer IDaynightproperty;
	private Integer IFxxz;
	private Integer IKcxz;
	private Integer ITj;
	private double DFjsj;
	private double DXlqsj;
	private double DMnjsj;
	private double DYbsj;
	private String VTrainpurpose;
	private String VNeirong;
	private String VTiaojian;
	private String VShebei;
	private String VXiangmu;
	private String VTsyq;
	private String VBz;
	private String VBeiyong;
	private Date DCreatedate;
	private Integer IIsthree;
	private Integer IOneNum;
	private Integer ITotalNum;
	private Set addHoursAndAddLessons = new HashSet(0);
	private Set traininglessonRelations = new HashSet(0);
	private Set TFlyreports = new HashSet(0);
	private Set TExperiencerecordEdits = new HashSet(0);
	private Set traininglessonSubjectRelations = new HashSet(0);
	private Set TOtherflyrecords = new HashSet(0);
	private Set TTeacherflightexperiencerecords = new HashSet(0);
	private Set TFlyteachrecords = new HashSet(0);
	private Set TFlightexperiencerecords = new HashSet(0);
	private Set THistoryrecords = new HashSet(0);
	private Set TTeacherpaytimes = new HashSet(0);
	private Set TFlightTrainingrecords = new HashSet(0);
	private Set lessonchangedbaseflylines = new HashSet(0);
	private Set TTrainlessonsubjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public TTrainingLesson() {
	}

	/** minimal constructor */
	public TTrainingLesson(TUser TUser, Integer IOrder, String VNo,
			String VName, Date DCreatedate) {
		this.TUser = TUser;
		this.IOrder = IOrder;
		this.VNo = VNo;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TTrainingLesson(Station stationByVStartpos, TUser TUser,
			Station stationByVEndpos, Integer IOrder, String VNo,
			Integer IAsciino, String VName, String VVersion,
			Integer IAsciiversion, Integer IType, Integer IPlaneproperty,
			Integer ITrainType, Integer IDaynightproperty, Integer IFxxz,
			Integer IKcxz, Integer ITj, double DFjsj, double DXlqsj,
			double DMnjsj, double DYbsj, String VTrainpurpose, String VNeirong,
			String VTiaojian, String VShebei, String VXiangmu, String VTsyq,
			String VBz, String VBeiyong, Date DCreatedate, Integer IIsthree,
			Integer IOneNum, Integer ITotalNum, Set addHoursAndAddLessons,
			Set traininglessonRelations, Set TFlyreports,
			Set TExperiencerecordEdits, Set traininglessonSubjectRelations,
			Set TOtherflyrecords, Set TTeacherflightexperiencerecords,
			Set TFlyteachrecords, Set TFlightexperiencerecords,
			Set THistoryrecords, Set TTeacherpaytimes,
			Set TFlightTrainingrecords, Set lessonchangedbaseflylines,
			Set TTrainlessonsubjects) {
		this.stationByVStartpos = stationByVStartpos;
		this.TUser = TUser;
		this.stationByVEndpos = stationByVEndpos;
		this.IOrder = IOrder;
		this.VNo = VNo;
		this.IAsciino = IAsciino;
		this.VName = VName;
		this.VVersion = VVersion;
		this.IAsciiversion = IAsciiversion;
		this.IType = IType;
		this.IPlaneproperty = IPlaneproperty;
		this.ITrainType = ITrainType;
		this.IDaynightproperty = IDaynightproperty;
		this.IFxxz = IFxxz;
		this.IKcxz = IKcxz;
		this.ITj = ITj;
		this.DFjsj = DFjsj;
		this.DXlqsj = DXlqsj;
		this.DMnjsj = DMnjsj;
		this.DYbsj = DYbsj;
		this.VTrainpurpose = VTrainpurpose;
		this.VNeirong = VNeirong;
		this.VTiaojian = VTiaojian;
		this.VShebei = VShebei;
		this.VXiangmu = VXiangmu;
		this.VTsyq = VTsyq;
		this.VBz = VBz;
		this.VBeiyong = VBeiyong;
		this.DCreatedate = DCreatedate;
		this.IIsthree = IIsthree;
		this.IOneNum = IOneNum;
		this.ITotalNum = ITotalNum;
		this.addHoursAndAddLessons = addHoursAndAddLessons;
		this.traininglessonRelations = traininglessonRelations;
		this.TFlyreports = TFlyreports;
		this.TExperiencerecordEdits = TExperiencerecordEdits;
		this.traininglessonSubjectRelations = traininglessonSubjectRelations;
		this.TOtherflyrecords = TOtherflyrecords;
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
		this.TFlyteachrecords = TFlyteachrecords;
		this.TFlightexperiencerecords = TFlightexperiencerecords;
		this.THistoryrecords = THistoryrecords;
		this.TTeacherpaytimes = TTeacherpaytimes;
		this.TFlightTrainingrecords = TFlightTrainingrecords;
		this.lessonchangedbaseflylines = lessonchangedbaseflylines;
		this.TTrainlessonsubjects = TTrainlessonsubjects;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public Station getStationByVStartpos() {
		return this.stationByVStartpos;
	}

	public void setStationByVStartpos(Station stationByVStartpos) {
		this.stationByVStartpos = stationByVStartpos;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Station getStationByVEndpos() {
		return this.stationByVEndpos;
	}

	public void setStationByVEndpos(Station stationByVEndpos) {
		this.stationByVEndpos = stationByVEndpos;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public String getVNo() {
		return this.VNo;
	}

	public void setVNo(String VNo) {
		this.VNo = VNo;
	}

	public Integer getIAsciino() {
		return this.IAsciino;
	}

	public void setIAsciino(Integer IAsciino) {
		this.IAsciino = IAsciino;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVVersion() {
		return this.VVersion;
	}

	public void setVVersion(String VVersion) {
		this.VVersion = VVersion;
	}

	public Integer getIAsciiversion() {
		return this.IAsciiversion;
	}

	public void setIAsciiversion(Integer IAsciiversion) {
		this.IAsciiversion = IAsciiversion;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Integer getIPlaneproperty() {
		return this.IPlaneproperty;
	}

	public void setIPlaneproperty(Integer IPlaneproperty) {
		this.IPlaneproperty = IPlaneproperty;
	}

	public Integer getITrainType() {
		return this.ITrainType;
	}

	public void setITrainType(Integer ITrainType) {
		this.ITrainType = ITrainType;
	}

	public Integer getIDaynightproperty() {
		return this.IDaynightproperty;
	}

	public void setIDaynightproperty(Integer IDaynightproperty) {
		this.IDaynightproperty = IDaynightproperty;
	}

	public Integer getIFxxz() {
		return this.IFxxz;
	}

	public void setIFxxz(Integer IFxxz) {
		this.IFxxz = IFxxz;
	}

	public Integer getIKcxz() {
		return this.IKcxz;
	}

	public void setIKcxz(Integer IKcxz) {
		this.IKcxz = IKcxz;
	}

	public Integer getITj() {
		return this.ITj;
	}

	public void setITj(Integer ITj) {
		this.ITj = ITj;
	}

	public double getDFjsj() {
		return this.DFjsj;
	}

	public void setDFjsj(double DFjsj) {
		this.DFjsj = DFjsj;
	}

	public double getDXlqsj() {
		return this.DXlqsj;
	}

	public void setDXlqsj(double DXlqsj) {
		this.DXlqsj = DXlqsj;
	}

	public double getDMnjsj() {
		return this.DMnjsj;
	}

	public void setDMnjsj(double DMnjsj) {
		this.DMnjsj = DMnjsj;
	}

	public double getDYbsj() {
		return this.DYbsj;
	}

	public void setDYbsj(double DYbsj) {
		this.DYbsj = DYbsj;
	}

	public String getVTrainpurpose() {
		return this.VTrainpurpose;
	}

	public void setVTrainpurpose(String VTrainpurpose) {
		this.VTrainpurpose = VTrainpurpose;
	}

	public String getVNeirong() {
		return this.VNeirong;
	}

	public void setVNeirong(String VNeirong) {
		this.VNeirong = VNeirong;
	}

	public String getVTiaojian() {
		return this.VTiaojian;
	}

	public void setVTiaojian(String VTiaojian) {
		this.VTiaojian = VTiaojian;
	}

	public String getVShebei() {
		return this.VShebei;
	}

	public void setVShebei(String VShebei) {
		this.VShebei = VShebei;
	}

	public String getVXiangmu() {
		return this.VXiangmu;
	}

	public void setVXiangmu(String VXiangmu) {
		this.VXiangmu = VXiangmu;
	}

	public String getVTsyq() {
		return this.VTsyq;
	}

	public void setVTsyq(String VTsyq) {
		this.VTsyq = VTsyq;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public String getVBeiyong() {
		return this.VBeiyong;
	}

	public void setVBeiyong(String VBeiyong) {
		this.VBeiyong = VBeiyong;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIIsthree() {
		return this.IIsthree;
	}

	public void setIIsthree(Integer IIsthree) {
		this.IIsthree = IIsthree;
	}

	public Integer getIOneNum() {
		return this.IOneNum;
	}

	public void setIOneNum(Integer IOneNum) {
		this.IOneNum = IOneNum;
	}

	public Integer getITotalNum() {
		return this.ITotalNum;
	}

	public void setITotalNum(Integer ITotalNum) {
		this.ITotalNum = ITotalNum;
	}

	public Set getAddHoursAndAddLessons() {
		return this.addHoursAndAddLessons;
	}

	public void setAddHoursAndAddLessons(Set addHoursAndAddLessons) {
		this.addHoursAndAddLessons = addHoursAndAddLessons;
	}

	public Set getTraininglessonRelations() {
		return this.traininglessonRelations;
	}

	public void setTraininglessonRelations(Set traininglessonRelations) {
		this.traininglessonRelations = traininglessonRelations;
	}

	public Set getTFlyreports() {
		return this.TFlyreports;
	}

	public void setTFlyreports(Set TFlyreports) {
		this.TFlyreports = TFlyreports;
	}

	public Set getTExperiencerecordEdits() {
		return this.TExperiencerecordEdits;
	}

	public void setTExperiencerecordEdits(Set TExperiencerecordEdits) {
		this.TExperiencerecordEdits = TExperiencerecordEdits;
	}

	public Set getTraininglessonSubjectRelations() {
		return this.traininglessonSubjectRelations;
	}

	public void setTraininglessonSubjectRelations(
			Set traininglessonSubjectRelations) {
		this.traininglessonSubjectRelations = traininglessonSubjectRelations;
	}

	public Set getTOtherflyrecords() {
		return this.TOtherflyrecords;
	}

	public void setTOtherflyrecords(Set TOtherflyrecords) {
		this.TOtherflyrecords = TOtherflyrecords;
	}

	public Set getTTeacherflightexperiencerecords() {
		return this.TTeacherflightexperiencerecords;
	}

	public void setTTeacherflightexperiencerecords(
			Set TTeacherflightexperiencerecords) {
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

	public Set getTFlyteachrecords() {
		return this.TFlyteachrecords;
	}

	public void setTFlyteachrecords(Set TFlyteachrecords) {
		this.TFlyteachrecords = TFlyteachrecords;
	}

	public Set getTFlightexperiencerecords() {
		return this.TFlightexperiencerecords;
	}

	public void setTFlightexperiencerecords(Set TFlightexperiencerecords) {
		this.TFlightexperiencerecords = TFlightexperiencerecords;
	}

	public Set getTHistoryrecords() {
		return this.THistoryrecords;
	}

	public void setTHistoryrecords(Set THistoryrecords) {
		this.THistoryrecords = THistoryrecords;
	}

	public Set getTTeacherpaytimes() {
		return this.TTeacherpaytimes;
	}

	public void setTTeacherpaytimes(Set TTeacherpaytimes) {
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

	public Set getTFlightTrainingrecords() {
		return this.TFlightTrainingrecords;
	}

	public void setTFlightTrainingrecords(Set TFlightTrainingrecords) {
		this.TFlightTrainingrecords = TFlightTrainingrecords;
	}

	public Set getLessonchangedbaseflylines() {
		return this.lessonchangedbaseflylines;
	}

	public void setLessonchangedbaseflylines(Set lessonchangedbaseflylines) {
		this.lessonchangedbaseflylines = lessonchangedbaseflylines;
	}

	public Set getTTrainlessonsubjects() {
		return this.TTrainlessonsubjects;
	}

	public void setTTrainlessonsubjects(Set TTrainlessonsubjects) {
		this.TTrainlessonsubjects = TTrainlessonsubjects;
	}

}