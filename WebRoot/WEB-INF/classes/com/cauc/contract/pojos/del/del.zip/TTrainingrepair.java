package com.cauc.training.pojos;

import java.util.Date;

/**
 * TTrainingrepair entity. @author MyEclipse Persistence Tools
 */

public class TTrainingrepair implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private Traininginfo traininginfo;
	private String VRepairperson;
	private String VContent;
	private String VRepairresult;
	private Date DStarttime;
	private Date DEndtime;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public TTrainingrepair() {
	}

	/** minimal constructor */
	public TTrainingrepair(TUser TUser, Traininginfo traininginfo,
			Date DCreateDate) {
		this.TUser = TUser;
		this.traininginfo = traininginfo;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TTrainingrepair(TUser TUser, Traininginfo traininginfo,
			String VRepairperson, String VContent, String VRepairresult,
			Date DStarttime, Date DEndtime, Date DCreateDate) {
		this.TUser = TUser;
		this.traininginfo = traininginfo;
		this.VRepairperson = VRepairperson;
		this.VContent = VContent;
		this.VRepairresult = VRepairresult;
		this.DStarttime = DStarttime;
		this.DEndtime = DEndtime;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Traininginfo getTraininginfo() {
		return this.traininginfo;
	}

	public void setTraininginfo(Traininginfo traininginfo) {
		this.traininginfo = traininginfo;
	}

	public String getVRepairperson() {
		return this.VRepairperson;
	}

	public void setVRepairperson(String VRepairperson) {
		this.VRepairperson = VRepairperson;
	}

	public String getVContent() {
		return this.VContent;
	}

	public void setVContent(String VContent) {
		this.VContent = VContent;
	}

	public String getVRepairresult() {
		return this.VRepairresult;
	}

	public void setVRepairresult(String VRepairresult) {
		this.VRepairresult = VRepairresult;
	}

	public Date getDStarttime() {
		return this.DStarttime;
	}

	public void setDStarttime(Date DStarttime) {
		this.DStarttime = DStarttime;
	}

	public Date getDEndtime() {
		return this.DEndtime;
	}

	public void setDEndtime(Date DEndtime) {
		this.DEndtime = DEndtime;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}