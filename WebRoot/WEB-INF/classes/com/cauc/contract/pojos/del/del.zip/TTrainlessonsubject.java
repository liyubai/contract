package com.cauc.training.pojos;

import java.util.Date;

/**
 * TTrainlessonsubject entity. @author MyEclipse Persistence Tools
 */

public class TTrainlessonsubject implements java.io.Serializable {

	// Fields

	private String VId;
	private TTrainsubject TTrainsubject;
	private TUser TUser;
	private TTrainingLesson TTrainingLesson;
	private double DScore;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TTrainlessonsubject() {
	}

	/** full constructor */
	public TTrainlessonsubject(TTrainsubject TTrainsubject, TUser TUser,
			TTrainingLesson TTrainingLesson, double DScore, Date DCreatedate) {
		this.TTrainsubject = TTrainsubject;
		this.TUser = TUser;
		this.TTrainingLesson = TTrainingLesson;
		this.DScore = DScore;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TTrainsubject getTTrainsubject() {
		return this.TTrainsubject;
	}

	public void setTTrainsubject(TTrainsubject TTrainsubject) {
		this.TTrainsubject = TTrainsubject;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public double getDScore() {
		return this.DScore;
	}

	public void setDScore(double DScore) {
		this.DScore = DScore;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}