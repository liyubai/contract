package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TTrainsubject entity. @author MyEclipse Persistence Tools
 */

public class TTrainsubject implements java.io.Serializable {

	// Fields

	private String VId;
	private TSubjectsort TSubjectsort;
	private TUser TUser;
	private String VName;
	private Integer ISort;
	private String VSubname;
	private Date DCreatedate;
	private Integer IOrder;
	private Set studentsubjectscores = new HashSet(0);
	private Set TTrainlessonsubjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public TTrainsubject() {
	}

	/** minimal constructor */
	public TTrainsubject(String VName) {
		this.VName = VName;
	}

	/** full constructor */
	public TTrainsubject(TSubjectsort TSubjectsort, TUser TUser, String VName,
			Integer ISort, String VSubname, Date DCreatedate, Integer IOrder,
			Set studentsubjectscores, Set TTrainlessonsubjects) {
		this.TSubjectsort = TSubjectsort;
		this.TUser = TUser;
		this.VName = VName;
		this.ISort = ISort;
		this.VSubname = VSubname;
		this.DCreatedate = DCreatedate;
		this.IOrder = IOrder;
		this.studentsubjectscores = studentsubjectscores;
		this.TTrainlessonsubjects = TTrainlessonsubjects;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TSubjectsort getTSubjectsort() {
		return this.TSubjectsort;
	}

	public void setTSubjectsort(TSubjectsort TSubjectsort) {
		this.TSubjectsort = TSubjectsort;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Integer getISort() {
		return this.ISort;
	}

	public void setISort(Integer ISort) {
		this.ISort = ISort;
	}

	public String getVSubname() {
		return this.VSubname;
	}

	public void setVSubname(String VSubname) {
		this.VSubname = VSubname;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public Set getStudentsubjectscores() {
		return this.studentsubjectscores;
	}

	public void setStudentsubjectscores(Set studentsubjectscores) {
		this.studentsubjectscores = studentsubjectscores;
	}

	public Set getTTrainlessonsubjects() {
		return this.TTrainlessonsubjects;
	}

	public void setTTrainlessonsubjects(Set TTrainlessonsubjects) {
		this.TTrainlessonsubjects = TTrainlessonsubjects;
	}

}