package com.cauc.training.pojos;

import java.util.Date;

/**
 * TUserOnline entity. @author MyEclipse Persistence Tools
 */

public class TUserOnline implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private Date DLoginDate;
	private Date DOffDate;

	// Constructors

	/** default constructor */
	public TUserOnline() {
	}

	/** minimal constructor */
	public TUserOnline(TUser TUser) {
		this.TUser = TUser;
	}

	/** full constructor */
	public TUserOnline(TUser TUser, Date DLoginDate, Date DOffDate) {
		this.TUser = TUser;
		this.DLoginDate = DLoginDate;
		this.DOffDate = DOffDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDLoginDate() {
		return this.DLoginDate;
	}

	public void setDLoginDate(Date DLoginDate) {
		this.DLoginDate = DLoginDate;
	}

	public Date getDOffDate() {
		return this.DOffDate;
	}

	public void setDOffDate(Date DOffDate) {
		this.DOffDate = DOffDate;
	}

}