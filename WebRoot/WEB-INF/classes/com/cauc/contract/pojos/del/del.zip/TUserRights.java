package com.cauc.training.pojos;

import java.util.Date;

/**
 * TUserRights entity. @author MyEclipse Persistence Tools
 */

public class TUserRights implements java.io.Serializable {

	// Fields

	private String VId;
	private TRole TRole;
	private TUser TUserByVCreateUserId;
	private TUser TUserByVUserid;
	private Date DCreateDate;
	private Integer IIsWrite;

	// Constructors

	/** default constructor */
	public TUserRights() {
	}

	/** minimal constructor */
	public TUserRights(TRole TRole, TUser TUserByVCreateUserId,
			TUser TUserByVUserid, Date DCreateDate) {
		this.TRole = TRole;
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.TUserByVUserid = TUserByVUserid;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public TUserRights(TRole TRole, TUser TUserByVCreateUserId,
			TUser TUserByVUserid, Date DCreateDate, Integer IIsWrite) {
		this.TRole = TRole;
		this.TUserByVCreateUserId = TUserByVCreateUserId;
		this.TUserByVUserid = TUserByVUserid;
		this.DCreateDate = DCreateDate;
		this.IIsWrite = IIsWrite;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TRole getTRole() {
		return this.TRole;
	}

	public void setTRole(TRole TRole) {
		this.TRole = TRole;
	}

	public TUser getTUserByVCreateUserId() {
		return this.TUserByVCreateUserId;
	}

	public void setTUserByVCreateUserId(TUser TUserByVCreateUserId) {
		this.TUserByVCreateUserId = TUserByVCreateUserId;
	}

	public TUser getTUserByVUserid() {
		return this.TUserByVUserid;
	}

	public void setTUserByVUserid(TUser TUserByVUserid) {
		this.TUserByVUserid = TUserByVUserid;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

	public Integer getIIsWrite() {
		return this.IIsWrite;
	}

	public void setIIsWrite(Integer IIsWrite) {
		this.IIsWrite = IIsWrite;
	}

}