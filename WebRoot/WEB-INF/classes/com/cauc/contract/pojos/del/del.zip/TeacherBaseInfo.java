package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TeacherBaseInfo entity. @author MyEclipse Persistence Tools
 */

public class TeacherBaseInfo implements java.io.Serializable {

	// Fields

	private String VId;
	private TDiction TDictionByVFlyform;
	private TDiction TDictionByVGeneraltype;
	private TDiction TDictionByVFlytype;
	private TDiction TDictionByVWhcd;
	private TDiction TDictionByVMz;
	private TUser TUser;
	private TOrg TOrg;
	private TDiction TDictionByVTecdengji;
	private String VName;
	private String VCode;
	private Integer IExam;
	private String VSafedengji;
	private Date DRxrq;
	private String VSfz;
	private String VXb;
	private Date DCsrq;
	private String VZzmm;
	private String VLxfs;
	private String VJg;
	private String VJtzz;
	private Date DCreatedate;
	private String VByyx;
	private String VZw;
	private String VYysp;
	private Date DMhyytgsj;
	private Date DCjgzsj;
	private String VSzdw;
	private String VSzdwzw;
	private Integer openStatus;
	private Set TFlightTrainingrecordsForVMonitorteacherid = new HashSet(0);
	private Set TFlightTrainingrecordsForVTeacherid = new HashSet(0);
	private Set TDispatchs = new HashSet(0);
	private Set TTeacherdgdistributions = new HashSet(0);
	private Set TTeaLicenses = new HashSet(0);
	private Set TFlyreportsForVMonitorTeacher = new HashSet(0);
	private Set assignExamTeachers = new HashSet(0);
	private Set TFlyreportsForVTeaid = new HashSet(0);
	private Set TFlyreportsForVSingleTeacher = new HashSet(0);
	private Set TFlightTrainingrecordsForVFlyTeaId = new HashSet(0);
	private Set TTeacherassignteachersForVTeacherasstudentid = new HashSet(0);
	private Set TTeaMedicalhistories = new HashSet(0);
	private Set TStuchangedteachersForVNewteacherid = new HashSet(0);
	private Set THistoryrecordsForVFlyTeaId = new HashSet(0);
	private Set TTeacherflightexperiencerecords = new HashSet(0);
	private Set TTeacherpaytimes = new HashSet(0);
	private Set THistoryrecordsForVTeacherid = new HashSet(0);
	private Set practiceTests = new HashSet(0);
	private Set TStuchangedteachersForVOldteacherid = new HashSet(0);
	private Set TStuassignteachers = new HashSet(0);
	private Set THistoryrecordsForVMonitorteacherid = new HashSet(0);
	private Set TFlyteachrecords = new HashSet(0);
	private Set flytaskbooks = new HashSet(0);
	private Set TTeacherassignteachersForVTeacherid = new HashSet(0);
	private Set TTeaMedicals = new HashSet(0);
	private Set teacherLicenseupdates = new HashSet(0);

	// Constructors

	/** default constructor */
	public TeacherBaseInfo() {
	}

	/** minimal constructor */
	public TeacherBaseInfo(TUser TUser, String VName, Integer IExam,
			Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.IExam = IExam;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TeacherBaseInfo(TDiction TDictionByVFlyform,
			TDiction TDictionByVGeneraltype, TDiction TDictionByVFlytype,
			TDiction TDictionByVWhcd, TDiction TDictionByVMz, TUser TUser,
			TOrg TOrg, TDiction TDictionByVTecdengji, String VName,
			String VCode, Integer IExam, String VSafedengji, Date DRxrq,
			String VSfz, String VXb, Date DCsrq, String VZzmm, String VLxfs,
			String VJg, String VJtzz, Date DCreatedate, String VByyx,
			String VZw, String VYysp, Date DMhyytgsj, Date DCjgzsj,
			String VSzdw, String VSzdwzw, Integer openStatus,
			Set TFlightTrainingrecordsForVMonitorteacherid,
			Set TFlightTrainingrecordsForVTeacherid, Set TDispatchs,
			Set TTeacherdgdistributions, Set TTeaLicenses,
			Set TFlyreportsForVMonitorTeacher, Set assignExamTeachers,
			Set TFlyreportsForVTeaid, Set TFlyreportsForVSingleTeacher,
			Set TFlightTrainingrecordsForVFlyTeaId,
			Set TTeacherassignteachersForVTeacherasstudentid,
			Set TTeaMedicalhistories, Set TStuchangedteachersForVNewteacherid,
			Set THistoryrecordsForVFlyTeaId,
			Set TTeacherflightexperiencerecords, Set TTeacherpaytimes,
			Set THistoryrecordsForVTeacherid, Set practiceTests,
			Set TStuchangedteachersForVOldteacherid, Set TStuassignteachers,
			Set THistoryrecordsForVMonitorteacherid, Set TFlyteachrecords,
			Set flytaskbooks, Set TTeacherassignteachersForVTeacherid,
			Set TTeaMedicals, Set teacherLicenseupdates) {
		this.TDictionByVFlyform = TDictionByVFlyform;
		this.TDictionByVGeneraltype = TDictionByVGeneraltype;
		this.TDictionByVFlytype = TDictionByVFlytype;
		this.TDictionByVWhcd = TDictionByVWhcd;
		this.TDictionByVMz = TDictionByVMz;
		this.TUser = TUser;
		this.TOrg = TOrg;
		this.TDictionByVTecdengji = TDictionByVTecdengji;
		this.VName = VName;
		this.VCode = VCode;
		this.IExam = IExam;
		this.VSafedengji = VSafedengji;
		this.DRxrq = DRxrq;
		this.VSfz = VSfz;
		this.VXb = VXb;
		this.DCsrq = DCsrq;
		this.VZzmm = VZzmm;
		this.VLxfs = VLxfs;
		this.VJg = VJg;
		this.VJtzz = VJtzz;
		this.DCreatedate = DCreatedate;
		this.VByyx = VByyx;
		this.VZw = VZw;
		this.VYysp = VYysp;
		this.DMhyytgsj = DMhyytgsj;
		this.DCjgzsj = DCjgzsj;
		this.VSzdw = VSzdw;
		this.VSzdwzw = VSzdwzw;
		this.openStatus = openStatus;
		this.TFlightTrainingrecordsForVMonitorteacherid = TFlightTrainingrecordsForVMonitorteacherid;
		this.TFlightTrainingrecordsForVTeacherid = TFlightTrainingrecordsForVTeacherid;
		this.TDispatchs = TDispatchs;
		this.TTeacherdgdistributions = TTeacherdgdistributions;
		this.TTeaLicenses = TTeaLicenses;
		this.TFlyreportsForVMonitorTeacher = TFlyreportsForVMonitorTeacher;
		this.assignExamTeachers = assignExamTeachers;
		this.TFlyreportsForVTeaid = TFlyreportsForVTeaid;
		this.TFlyreportsForVSingleTeacher = TFlyreportsForVSingleTeacher;
		this.TFlightTrainingrecordsForVFlyTeaId = TFlightTrainingrecordsForVFlyTeaId;
		this.TTeacherassignteachersForVTeacherasstudentid = TTeacherassignteachersForVTeacherasstudentid;
		this.TTeaMedicalhistories = TTeaMedicalhistories;
		this.TStuchangedteachersForVNewteacherid = TStuchangedteachersForVNewteacherid;
		this.THistoryrecordsForVFlyTeaId = THistoryrecordsForVFlyTeaId;
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
		this.TTeacherpaytimes = TTeacherpaytimes;
		this.THistoryrecordsForVTeacherid = THistoryrecordsForVTeacherid;
		this.practiceTests = practiceTests;
		this.TStuchangedteachersForVOldteacherid = TStuchangedteachersForVOldteacherid;
		this.TStuassignteachers = TStuassignteachers;
		this.THistoryrecordsForVMonitorteacherid = THistoryrecordsForVMonitorteacherid;
		this.TFlyteachrecords = TFlyteachrecords;
		this.flytaskbooks = flytaskbooks;
		this.TTeacherassignteachersForVTeacherid = TTeacherassignteachersForVTeacherid;
		this.TTeaMedicals = TTeaMedicals;
		this.teacherLicenseupdates = teacherLicenseupdates;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TDiction getTDictionByVFlyform() {
		return this.TDictionByVFlyform;
	}

	public void setTDictionByVFlyform(TDiction TDictionByVFlyform) {
		this.TDictionByVFlyform = TDictionByVFlyform;
	}

	public TDiction getTDictionByVGeneraltype() {
		return this.TDictionByVGeneraltype;
	}

	public void setTDictionByVGeneraltype(TDiction TDictionByVGeneraltype) {
		this.TDictionByVGeneraltype = TDictionByVGeneraltype;
	}

	public TDiction getTDictionByVFlytype() {
		return this.TDictionByVFlytype;
	}

	public void setTDictionByVFlytype(TDiction TDictionByVFlytype) {
		this.TDictionByVFlytype = TDictionByVFlytype;
	}

	public TDiction getTDictionByVWhcd() {
		return this.TDictionByVWhcd;
	}

	public void setTDictionByVWhcd(TDiction TDictionByVWhcd) {
		this.TDictionByVWhcd = TDictionByVWhcd;
	}

	public TDiction getTDictionByVMz() {
		return this.TDictionByVMz;
	}

	public void setTDictionByVMz(TDiction TDictionByVMz) {
		this.TDictionByVMz = TDictionByVMz;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TOrg getTOrg() {
		return this.TOrg;
	}

	public void setTOrg(TOrg TOrg) {
		this.TOrg = TOrg;
	}

	public TDiction getTDictionByVTecdengji() {
		return this.TDictionByVTecdengji;
	}

	public void setTDictionByVTecdengji(TDiction TDictionByVTecdengji) {
		this.TDictionByVTecdengji = TDictionByVTecdengji;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVCode() {
		return this.VCode;
	}

	public void setVCode(String VCode) {
		this.VCode = VCode;
	}

	public Integer getIExam() {
		return this.IExam;
	}

	public void setIExam(Integer IExam) {
		this.IExam = IExam;
	}

	public String getVSafedengji() {
		return this.VSafedengji;
	}

	public void setVSafedengji(String VSafedengji) {
		this.VSafedengji = VSafedengji;
	}

	public Date getDRxrq() {
		return this.DRxrq;
	}

	public void setDRxrq(Date DRxrq) {
		this.DRxrq = DRxrq;
	}

	public String getVSfz() {
		return this.VSfz;
	}

	public void setVSfz(String VSfz) {
		this.VSfz = VSfz;
	}

	public String getVXb() {
		return this.VXb;
	}

	public void setVXb(String VXb) {
		this.VXb = VXb;
	}

	public Date getDCsrq() {
		return this.DCsrq;
	}

	public void setDCsrq(Date DCsrq) {
		this.DCsrq = DCsrq;
	}

	public String getVZzmm() {
		return this.VZzmm;
	}

	public void setVZzmm(String VZzmm) {
		this.VZzmm = VZzmm;
	}

	public String getVLxfs() {
		return this.VLxfs;
	}

	public void setVLxfs(String VLxfs) {
		this.VLxfs = VLxfs;
	}

	public String getVJg() {
		return this.VJg;
	}

	public void setVJg(String VJg) {
		this.VJg = VJg;
	}

	public String getVJtzz() {
		return this.VJtzz;
	}

	public void setVJtzz(String VJtzz) {
		this.VJtzz = VJtzz;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVByyx() {
		return this.VByyx;
	}

	public void setVByyx(String VByyx) {
		this.VByyx = VByyx;
	}

	public String getVZw() {
		return this.VZw;
	}

	public void setVZw(String VZw) {
		this.VZw = VZw;
	}

	public String getVYysp() {
		return this.VYysp;
	}

	public void setVYysp(String VYysp) {
		this.VYysp = VYysp;
	}

	public Date getDMhyytgsj() {
		return this.DMhyytgsj;
	}

	public void setDMhyytgsj(Date DMhyytgsj) {
		this.DMhyytgsj = DMhyytgsj;
	}

	public Date getDCjgzsj() {
		return this.DCjgzsj;
	}

	public void setDCjgzsj(Date DCjgzsj) {
		this.DCjgzsj = DCjgzsj;
	}

	public String getVSzdw() {
		return this.VSzdw;
	}

	public void setVSzdw(String VSzdw) {
		this.VSzdw = VSzdw;
	}

	public String getVSzdwzw() {
		return this.VSzdwzw;
	}

	public void setVSzdwzw(String VSzdwzw) {
		this.VSzdwzw = VSzdwzw;
	}

	public Integer getOpenStatus() {
		return this.openStatus;
	}

	public void setOpenStatus(Integer openStatus) {
		this.openStatus = openStatus;
	}

	public Set getTFlightTrainingrecordsForVMonitorteacherid() {
		return this.TFlightTrainingrecordsForVMonitorteacherid;
	}

	public void setTFlightTrainingrecordsForVMonitorteacherid(
			Set TFlightTrainingrecordsForVMonitorteacherid) {
		this.TFlightTrainingrecordsForVMonitorteacherid = TFlightTrainingrecordsForVMonitorteacherid;
	}

	public Set getTFlightTrainingrecordsForVTeacherid() {
		return this.TFlightTrainingrecordsForVTeacherid;
	}

	public void setTFlightTrainingrecordsForVTeacherid(
			Set TFlightTrainingrecordsForVTeacherid) {
		this.TFlightTrainingrecordsForVTeacherid = TFlightTrainingrecordsForVTeacherid;
	}

	public Set getTDispatchs() {
		return this.TDispatchs;
	}

	public void setTDispatchs(Set TDispatchs) {
		this.TDispatchs = TDispatchs;
	}

	public Set getTTeacherdgdistributions() {
		return this.TTeacherdgdistributions;
	}

	public void setTTeacherdgdistributions(Set TTeacherdgdistributions) {
		this.TTeacherdgdistributions = TTeacherdgdistributions;
	}

	public Set getTTeaLicenses() {
		return this.TTeaLicenses;
	}

	public void setTTeaLicenses(Set TTeaLicenses) {
		this.TTeaLicenses = TTeaLicenses;
	}

	public Set getTFlyreportsForVMonitorTeacher() {
		return this.TFlyreportsForVMonitorTeacher;
	}

	public void setTFlyreportsForVMonitorTeacher(
			Set TFlyreportsForVMonitorTeacher) {
		this.TFlyreportsForVMonitorTeacher = TFlyreportsForVMonitorTeacher;
	}

	public Set getAssignExamTeachers() {
		return this.assignExamTeachers;
	}

	public void setAssignExamTeachers(Set assignExamTeachers) {
		this.assignExamTeachers = assignExamTeachers;
	}

	public Set getTFlyreportsForVTeaid() {
		return this.TFlyreportsForVTeaid;
	}

	public void setTFlyreportsForVTeaid(Set TFlyreportsForVTeaid) {
		this.TFlyreportsForVTeaid = TFlyreportsForVTeaid;
	}

	public Set getTFlyreportsForVSingleTeacher() {
		return this.TFlyreportsForVSingleTeacher;
	}

	public void setTFlyreportsForVSingleTeacher(Set TFlyreportsForVSingleTeacher) {
		this.TFlyreportsForVSingleTeacher = TFlyreportsForVSingleTeacher;
	}

	public Set getTFlightTrainingrecordsForVFlyTeaId() {
		return this.TFlightTrainingrecordsForVFlyTeaId;
	}

	public void setTFlightTrainingrecordsForVFlyTeaId(
			Set TFlightTrainingrecordsForVFlyTeaId) {
		this.TFlightTrainingrecordsForVFlyTeaId = TFlightTrainingrecordsForVFlyTeaId;
	}

	public Set getTTeacherassignteachersForVTeacherasstudentid() {
		return this.TTeacherassignteachersForVTeacherasstudentid;
	}

	public void setTTeacherassignteachersForVTeacherasstudentid(
			Set TTeacherassignteachersForVTeacherasstudentid) {
		this.TTeacherassignteachersForVTeacherasstudentid = TTeacherassignteachersForVTeacherasstudentid;
	}

	public Set getTTeaMedicalhistories() {
		return this.TTeaMedicalhistories;
	}

	public void setTTeaMedicalhistories(Set TTeaMedicalhistories) {
		this.TTeaMedicalhistories = TTeaMedicalhistories;
	}

	public Set getTStuchangedteachersForVNewteacherid() {
		return this.TStuchangedteachersForVNewteacherid;
	}

	public void setTStuchangedteachersForVNewteacherid(
			Set TStuchangedteachersForVNewteacherid) {
		this.TStuchangedteachersForVNewteacherid = TStuchangedteachersForVNewteacherid;
	}

	public Set getTHistoryrecordsForVFlyTeaId() {
		return this.THistoryrecordsForVFlyTeaId;
	}

	public void setTHistoryrecordsForVFlyTeaId(Set THistoryrecordsForVFlyTeaId) {
		this.THistoryrecordsForVFlyTeaId = THistoryrecordsForVFlyTeaId;
	}

	public Set getTTeacherflightexperiencerecords() {
		return this.TTeacherflightexperiencerecords;
	}

	public void setTTeacherflightexperiencerecords(
			Set TTeacherflightexperiencerecords) {
		this.TTeacherflightexperiencerecords = TTeacherflightexperiencerecords;
	}

	public Set getTTeacherpaytimes() {
		return this.TTeacherpaytimes;
	}

	public void setTTeacherpaytimes(Set TTeacherpaytimes) {
		this.TTeacherpaytimes = TTeacherpaytimes;
	}

	public Set getTHistoryrecordsForVTeacherid() {
		return this.THistoryrecordsForVTeacherid;
	}

	public void setTHistoryrecordsForVTeacherid(Set THistoryrecordsForVTeacherid) {
		this.THistoryrecordsForVTeacherid = THistoryrecordsForVTeacherid;
	}

	public Set getPracticeTests() {
		return this.practiceTests;
	}

	public void setPracticeTests(Set practiceTests) {
		this.practiceTests = practiceTests;
	}

	public Set getTStuchangedteachersForVOldteacherid() {
		return this.TStuchangedteachersForVOldteacherid;
	}

	public void setTStuchangedteachersForVOldteacherid(
			Set TStuchangedteachersForVOldteacherid) {
		this.TStuchangedteachersForVOldteacherid = TStuchangedteachersForVOldteacherid;
	}

	public Set getTStuassignteachers() {
		return this.TStuassignteachers;
	}

	public void setTStuassignteachers(Set TStuassignteachers) {
		this.TStuassignteachers = TStuassignteachers;
	}

	public Set getTHistoryrecordsForVMonitorteacherid() {
		return this.THistoryrecordsForVMonitorteacherid;
	}

	public void setTHistoryrecordsForVMonitorteacherid(
			Set THistoryrecordsForVMonitorteacherid) {
		this.THistoryrecordsForVMonitorteacherid = THistoryrecordsForVMonitorteacherid;
	}

	public Set getTFlyteachrecords() {
		return this.TFlyteachrecords;
	}

	public void setTFlyteachrecords(Set TFlyteachrecords) {
		this.TFlyteachrecords = TFlyteachrecords;
	}

	public Set getFlytaskbooks() {
		return this.flytaskbooks;
	}

	public void setFlytaskbooks(Set flytaskbooks) {
		this.flytaskbooks = flytaskbooks;
	}

	public Set getTTeacherassignteachersForVTeacherid() {
		return this.TTeacherassignteachersForVTeacherid;
	}

	public void setTTeacherassignteachersForVTeacherid(
			Set TTeacherassignteachersForVTeacherid) {
		this.TTeacherassignteachersForVTeacherid = TTeacherassignteachersForVTeacherid;
	}

	public Set getTTeaMedicals() {
		return this.TTeaMedicals;
	}

	public void setTTeaMedicals(Set TTeaMedicals) {
		this.TTeaMedicals = TTeaMedicals;
	}

	public Set getTeacherLicenseupdates() {
		return this.teacherLicenseupdates;
	}

	public void setTeacherLicenseupdates(Set teacherLicenseupdates) {
		this.teacherLicenseupdates = teacherLicenseupdates;
	}

}