package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * TeacherLicenseupdate entity. @author MyEclipse Persistence Tools
 */

public class TeacherLicenseupdate implements java.io.Serializable {

	// Fields

	private String VId;
	private TTeaLicense TTeaLicense;
	private TUser TUser;
	private TeacherBaseInfo teacherBaseInfo;
	private String VCardid;
	private Date DEffectdate;
	private String VIssuer;
	private String VQfdw;
	private Date DQfsj;
	private Date DUpdatedate;
	private String VDengji;
	private String VJyzzlx;
	private String VZzlx;
	private String VXingzhi;
	private String VYbdj;
	private String VFjjbdj;
	private String VHkqlb;
	private Date DLastchecktime;
	private Date DChecktime;
	private Date DExamtime;
	private Date DNextchecktime;
	private Date DCreatedate;
	private String VHkqdj;
	private String VXyjdj;
	private String VYszzdj;
	private Integer IHgz;
	private Integer IJiankong;
	private Set TTeaLicenseskilledchecks = new HashSet(0);

	// Constructors

	/** default constructor */
	public TeacherLicenseupdate() {
	}

	/** minimal constructor */
	public TeacherLicenseupdate(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TeacherLicenseupdate(TTeaLicense TTeaLicense, TUser TUser,
			TeacherBaseInfo teacherBaseInfo, String VCardid, Date DEffectdate,
			String VIssuer, String VQfdw, Date DQfsj, Date DUpdatedate,
			String VDengji, String VJyzzlx, String VZzlx, String VXingzhi,
			String VYbdj, String VFjjbdj, String VHkqlb, Date DLastchecktime,
			Date DChecktime, Date DExamtime, Date DNextchecktime,
			Date DCreatedate, String VHkqdj, String VXyjdj, String VYszzdj,
			Integer IHgz, Integer IJiankong, Set TTeaLicenseskilledchecks) {
		this.TTeaLicense = TTeaLicense;
		this.TUser = TUser;
		this.teacherBaseInfo = teacherBaseInfo;
		this.VCardid = VCardid;
		this.DEffectdate = DEffectdate;
		this.VIssuer = VIssuer;
		this.VQfdw = VQfdw;
		this.DQfsj = DQfsj;
		this.DUpdatedate = DUpdatedate;
		this.VDengji = VDengji;
		this.VJyzzlx = VJyzzlx;
		this.VZzlx = VZzlx;
		this.VXingzhi = VXingzhi;
		this.VYbdj = VYbdj;
		this.VFjjbdj = VFjjbdj;
		this.VHkqlb = VHkqlb;
		this.DLastchecktime = DLastchecktime;
		this.DChecktime = DChecktime;
		this.DExamtime = DExamtime;
		this.DNextchecktime = DNextchecktime;
		this.DCreatedate = DCreatedate;
		this.VHkqdj = VHkqdj;
		this.VXyjdj = VXyjdj;
		this.VYszzdj = VYszzdj;
		this.IHgz = IHgz;
		this.IJiankong = IJiankong;
		this.TTeaLicenseskilledchecks = TTeaLicenseskilledchecks;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TTeaLicense getTTeaLicense() {
		return this.TTeaLicense;
	}

	public void setTTeaLicense(TTeaLicense TTeaLicense) {
		this.TTeaLicense = TTeaLicense;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TeacherBaseInfo getTeacherBaseInfo() {
		return this.teacherBaseInfo;
	}

	public void setTeacherBaseInfo(TeacherBaseInfo teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public String getVCardid() {
		return this.VCardid;
	}

	public void setVCardid(String VCardid) {
		this.VCardid = VCardid;
	}

	public Date getDEffectdate() {
		return this.DEffectdate;
	}

	public void setDEffectdate(Date DEffectdate) {
		this.DEffectdate = DEffectdate;
	}

	public String getVIssuer() {
		return this.VIssuer;
	}

	public void setVIssuer(String VIssuer) {
		this.VIssuer = VIssuer;
	}

	public String getVQfdw() {
		return this.VQfdw;
	}

	public void setVQfdw(String VQfdw) {
		this.VQfdw = VQfdw;
	}

	public Date getDQfsj() {
		return this.DQfsj;
	}

	public void setDQfsj(Date DQfsj) {
		this.DQfsj = DQfsj;
	}

	public Date getDUpdatedate() {
		return this.DUpdatedate;
	}

	public void setDUpdatedate(Date DUpdatedate) {
		this.DUpdatedate = DUpdatedate;
	}

	public String getVDengji() {
		return this.VDengji;
	}

	public void setVDengji(String VDengji) {
		this.VDengji = VDengji;
	}

	public String getVJyzzlx() {
		return this.VJyzzlx;
	}

	public void setVJyzzlx(String VJyzzlx) {
		this.VJyzzlx = VJyzzlx;
	}

	public String getVZzlx() {
		return this.VZzlx;
	}

	public void setVZzlx(String VZzlx) {
		this.VZzlx = VZzlx;
	}

	public String getVXingzhi() {
		return this.VXingzhi;
	}

	public void setVXingzhi(String VXingzhi) {
		this.VXingzhi = VXingzhi;
	}

	public String getVYbdj() {
		return this.VYbdj;
	}

	public void setVYbdj(String VYbdj) {
		this.VYbdj = VYbdj;
	}

	public String getVFjjbdj() {
		return this.VFjjbdj;
	}

	public void setVFjjbdj(String VFjjbdj) {
		this.VFjjbdj = VFjjbdj;
	}

	public String getVHkqlb() {
		return this.VHkqlb;
	}

	public void setVHkqlb(String VHkqlb) {
		this.VHkqlb = VHkqlb;
	}

	public Date getDLastchecktime() {
		return this.DLastchecktime;
	}

	public void setDLastchecktime(Date DLastchecktime) {
		this.DLastchecktime = DLastchecktime;
	}

	public Date getDChecktime() {
		return this.DChecktime;
	}

	public void setDChecktime(Date DChecktime) {
		this.DChecktime = DChecktime;
	}

	public Date getDExamtime() {
		return this.DExamtime;
	}

	public void setDExamtime(Date DExamtime) {
		this.DExamtime = DExamtime;
	}

	public Date getDNextchecktime() {
		return this.DNextchecktime;
	}

	public void setDNextchecktime(Date DNextchecktime) {
		this.DNextchecktime = DNextchecktime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVHkqdj() {
		return this.VHkqdj;
	}

	public void setVHkqdj(String VHkqdj) {
		this.VHkqdj = VHkqdj;
	}

	public String getVXyjdj() {
		return this.VXyjdj;
	}

	public void setVXyjdj(String VXyjdj) {
		this.VXyjdj = VXyjdj;
	}

	public String getVYszzdj() {
		return this.VYszzdj;
	}

	public void setVYszzdj(String VYszzdj) {
		this.VYszzdj = VYszzdj;
	}

	public Integer getIHgz() {
		return this.IHgz;
	}

	public void setIHgz(Integer IHgz) {
		this.IHgz = IHgz;
	}

	public Integer getIJiankong() {
		return this.IJiankong;
	}

	public void setIJiankong(Integer IJiankong) {
		this.IJiankong = IJiankong;
	}

	public Set getTTeaLicenseskilledchecks() {
		return this.TTeaLicenseskilledchecks;
	}

	public void setTTeaLicenseskilledchecks(Set TTeaLicenseskilledchecks) {
		this.TTeaLicenseskilledchecks = TTeaLicenseskilledchecks;
	}

}