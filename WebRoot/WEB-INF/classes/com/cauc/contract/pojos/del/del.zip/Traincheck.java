package com.cauc.training.pojos;

import java.util.Date;

/**
 * Traincheck entity. @author MyEclipse Persistence Tools
 */

public class Traincheck implements java.io.Serializable {

	// Fields

	private String VId;
	private TUser TUser;
	private Traininginfo traininginfo;
	private Date DChecktime;
	private String VCheckperson;
	private String VCheckresult;
	private String VChecktype;
	private Date DCreateDate;

	// Constructors

	/** default constructor */
	public Traincheck() {
	}

	/** minimal constructor */
	public Traincheck(TUser TUser, Traininginfo traininginfo, Date DChecktime,
			Date DCreateDate) {
		this.TUser = TUser;
		this.traininginfo = traininginfo;
		this.DChecktime = DChecktime;
		this.DCreateDate = DCreateDate;
	}

	/** full constructor */
	public Traincheck(TUser TUser, Traininginfo traininginfo, Date DChecktime,
			String VCheckperson, String VCheckresult, String VChecktype,
			Date DCreateDate) {
		this.TUser = TUser;
		this.traininginfo = traininginfo;
		this.DChecktime = DChecktime;
		this.VCheckperson = VCheckperson;
		this.VCheckresult = VCheckresult;
		this.VChecktype = VChecktype;
		this.DCreateDate = DCreateDate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Traininginfo getTraininginfo() {
		return this.traininginfo;
	}

	public void setTraininginfo(Traininginfo traininginfo) {
		this.traininginfo = traininginfo;
	}

	public Date getDChecktime() {
		return this.DChecktime;
	}

	public void setDChecktime(Date DChecktime) {
		this.DChecktime = DChecktime;
	}

	public String getVCheckperson() {
		return this.VCheckperson;
	}

	public void setVCheckperson(String VCheckperson) {
		this.VCheckperson = VCheckperson;
	}

	public String getVCheckresult() {
		return this.VCheckresult;
	}

	public void setVCheckresult(String VCheckresult) {
		this.VCheckresult = VCheckresult;
	}

	public String getVChecktype() {
		return this.VChecktype;
	}

	public void setVChecktype(String VChecktype) {
		this.VChecktype = VChecktype;
	}

	public Date getDCreateDate() {
		return this.DCreateDate;
	}

	public void setDCreateDate(Date DCreateDate) {
		this.DCreateDate = DCreateDate;
	}

}