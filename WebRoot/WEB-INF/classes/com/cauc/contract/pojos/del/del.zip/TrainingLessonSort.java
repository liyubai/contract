package com.cauc.training.pojos;

import java.util.Date;

/**
 * TrainingLessonSort entity. @author MyEclipse Persistence Tools
 */

public class TrainingLessonSort implements java.io.Serializable {

	// Fields

	private String VId;
	private String VName;
	private Date DCreatedate;
	private String VCreateuserid;

	// Constructors

	/** default constructor */
	public TrainingLessonSort() {
	}

	/** full constructor */
	public TrainingLessonSort(String VName, Date DCreatedate,
			String VCreateuserid) {
		this.VName = VName;
		this.DCreatedate = DCreatedate;
		this.VCreateuserid = VCreateuserid;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public String getVCreateuserid() {
		return this.VCreateuserid;
	}

	public void setVCreateuserid(String VCreateuserid) {
		this.VCreateuserid = VCreateuserid;
	}

}