package com.cauc.training.pojos;

import java.util.Date;

/**
 * TrainingPlane entity. @author MyEclipse Persistence Tools
 */

public class TrainingPlane implements java.io.Serializable {

	// Fields

	private String VId;
	private StudentBaseInfo studentBaseInfo;
	private Integer IWeek;
	private double DTime;
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public TrainingPlane() {
	}

	/** full constructor */
	public TrainingPlane(StudentBaseInfo studentBaseInfo, Integer IWeek,
			double DTime, Date DCreatedate) {
		this.studentBaseInfo = studentBaseInfo;
		this.IWeek = IWeek;
		this.DTime = DTime;
		this.DCreatedate = DCreatedate;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public StudentBaseInfo getStudentBaseInfo() {
		return this.studentBaseInfo;
	}

	public void setStudentBaseInfo(StudentBaseInfo studentBaseInfo) {
		this.studentBaseInfo = studentBaseInfo;
	}

	public Integer getIWeek() {
		return this.IWeek;
	}

	public void setIWeek(Integer IWeek) {
		this.IWeek = IWeek;
	}

	public double getDTime() {
		return this.DTime;
	}

	public void setDTime(double DTime) {
		this.DTime = DTime;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}