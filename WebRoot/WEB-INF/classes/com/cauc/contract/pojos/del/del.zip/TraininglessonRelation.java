package com.cauc.training.pojos;

import java.util.Date;

/**
 * TraininglessonRelation entity. @author MyEclipse Persistence Tools
 */

public class TraininglessonRelation implements java.io.Serializable {

	// Fields

	private String VId;
	private TPhase TPhase;
	private TUser TUser;
	private TTrainingLesson TTrainingLesson;
	private Date DCreatedate;
	private Integer IOrder;
	private String VSecondName;

	// Constructors

	/** default constructor */
	public TraininglessonRelation() {
	}

	/** minimal constructor */
	public TraininglessonRelation(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public TraininglessonRelation(TPhase TPhase, TUser TUser,
			TTrainingLesson TTrainingLesson, Date DCreatedate, Integer IOrder,
			String VSecondName) {
		this.TPhase = TPhase;
		this.TUser = TUser;
		this.TTrainingLesson = TTrainingLesson;
		this.DCreatedate = DCreatedate;
		this.IOrder = IOrder;
		this.VSecondName = VSecondName;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TPhase getTPhase() {
		return this.TPhase;
	}

	public void setTPhase(TPhase TPhase) {
		this.TPhase = TPhase;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIOrder() {
		return this.IOrder;
	}

	public void setIOrder(Integer IOrder) {
		this.IOrder = IOrder;
	}

	public String getVSecondName() {
		return this.VSecondName;
	}

	public void setVSecondName(String VSecondName) {
		this.VSecondName = VSecondName;
	}

}