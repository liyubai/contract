package com.cauc.training.pojos;

/**
 * TraininglessonSubjectRelation entity. @author MyEclipse Persistence Tools
 */

public class TraininglessonSubjectRelation implements java.io.Serializable {

	// Fields

	private String VId;
	private TTimesubject TTimesubject;
	private TTrainingLesson TTrainingLesson;
	private double DTime;

	// Constructors

	/** default constructor */
	public TraininglessonSubjectRelation() {
	}

	/** full constructor */
	public TraininglessonSubjectRelation(TTimesubject TTimesubject,
			TTrainingLesson TTrainingLesson, double DTime) {
		this.TTimesubject = TTimesubject;
		this.TTrainingLesson = TTrainingLesson;
		this.DTime = DTime;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TTimesubject getTTimesubject() {
		return this.TTimesubject;
	}

	public void setTTimesubject(TTimesubject TTimesubject) {
		this.TTimesubject = TTimesubject;
	}

	public TTrainingLesson getTTrainingLesson() {
		return this.TTrainingLesson;
	}

	public void setTTrainingLesson(TTrainingLesson TTrainingLesson) {
		this.TTrainingLesson = TTrainingLesson;
	}

	public double getDTime() {
		return this.DTime;
	}

	public void setDTime(double DTime) {
		this.DTime = DTime;
	}

}