package com.cauc.training.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Trainlessonunit entity. @author MyEclipse Persistence Tools
 */

public class Trainlessonunit implements java.io.Serializable {

	// Fields

	private String VId;
	private TOutline TOutline;
	private TUser TUser;
	private String VName;
	private String VNo;
	private String VLicenseform;
	private String VConditions;
	private String VPassstandard;
	private Date DCreatedate;
	private Integer IType;
	private Set TPhases = new HashSet(0);

	// Constructors

	/** default constructor */
	public Trainlessonunit() {
	}

	/** minimal constructor */
	public Trainlessonunit(TUser TUser, String VName, Date DCreatedate) {
		this.TUser = TUser;
		this.VName = VName;
		this.DCreatedate = DCreatedate;
	}

	/** full constructor */
	public Trainlessonunit(TOutline TOutline, TUser TUser, String VName,
			String VNo, String VLicenseform, String VConditions,
			String VPassstandard, Date DCreatedate, Integer IType, Set TPhases) {
		this.TOutline = TOutline;
		this.TUser = TUser;
		this.VName = VName;
		this.VNo = VNo;
		this.VLicenseform = VLicenseform;
		this.VConditions = VConditions;
		this.VPassstandard = VPassstandard;
		this.DCreatedate = DCreatedate;
		this.IType = IType;
		this.TPhases = TPhases;
	}

	// Property accessors

	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TOutline getTOutline() {
		return this.TOutline;
	}

	public void setTOutline(TOutline TOutline) {
		this.TOutline = TOutline;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getVName() {
		return this.VName;
	}

	public void setVName(String VName) {
		this.VName = VName;
	}

	public String getVNo() {
		return this.VNo;
	}

	public void setVNo(String VNo) {
		this.VNo = VNo;
	}

	public String getVLicenseform() {
		return this.VLicenseform;
	}

	public void setVLicenseform(String VLicenseform) {
		this.VLicenseform = VLicenseform;
	}

	public String getVConditions() {
		return this.VConditions;
	}

	public void setVConditions(String VConditions) {
		this.VConditions = VConditions;
	}

	public String getVPassstandard() {
		return this.VPassstandard;
	}

	public void setVPassstandard(String VPassstandard) {
		this.VPassstandard = VPassstandard;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

	public Integer getIType() {
		return this.IType;
	}

	public void setIType(Integer IType) {
		this.IType = IType;
	}

	public Set getTPhases() {
		return this.TPhases;
	}

	public void setTPhases(Set TPhases) {
		this.TPhases = TPhases;
	}

}