package com.cauc.training.vo;

public class AdvancedSearchBean implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1005586408911947068L;
	
	private String isAndName;
	private String name;
	
	private String isAndAssign; 
	private String isAssignid;
	
	private String isAndStuType;
	private String xstuTypeid;
	
	private String isAndCompany;
	private String xcompanyid;
	
	private String isAndStatus;
	private String xstatusid;
	
	private String isAndXjStatus;
	private String xxjstatusid;
	
	private String isAndForm;
	private String xformid;
	
	private String isAndFreeType;
	private String xfreetypeid;
	
	private String isAndYear;
	private String xYear;
	
	private String isAndClass;
	private String xClass;
	
	private Integer paraNum;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIsAssignid() {
		return isAssignid;
	}
	public void setIsAssignid(String isAssignid) {
		this.isAssignid = isAssignid;
	}
	public String getXstuTypeid() {
		return xstuTypeid;
	}
	public void setXstuTypeid(String xstuTypeid) {
		this.xstuTypeid = xstuTypeid;
	}
	public String getXcompanyid() {
		return xcompanyid;
	}
	public void setXcompanyid(String xcompanyid) {
		this.xcompanyid = xcompanyid;
	}
	public String getXstatusid() {
		return xstatusid;
	}
	public void setXstatusid(String xstatusid) {
		this.xstatusid = xstatusid;
	}
	public String getXxjstatusid() {
		return xxjstatusid;
	}
	public void setXxjstatusid(String xxjstatusid) {
		this.xxjstatusid = xxjstatusid;
	}
	public String getXformid() {
		return xformid;
	}
	public void setXformid(String xformid) {
		this.xformid = xformid;
	}
	public String getXfreetypeid() {
		return xfreetypeid;
	}
	public void setXfreetypeid(String xfreetypeid) {
		this.xfreetypeid = xfreetypeid;
	}
	public String getIsAndName() {
		return isAndName;
	}
	public void setIsAndName(String isAndName) {
		this.isAndName = isAndName;
	}
	public String getIsAndAssign() {
		return isAndAssign;
	}
	public void setIsAndAssign(String isAndAssign) {
		this.isAndAssign = isAndAssign;
	}
	public String getIsAndStuType() {
		return isAndStuType;
	}
	public void setIsAndStuType(String isAndStuType) {
		this.isAndStuType = isAndStuType;
	}
	public String getIsAndCompany() {
		return isAndCompany;
	}
	public void setIsAndCompany(String isAndCompany) {
		this.isAndCompany = isAndCompany;
	}
	public String getIsAndStatus() {
		return isAndStatus;
	}
	public void setIsAndStatus(String isAndStatus) {
		this.isAndStatus = isAndStatus;
	}
	public String getIsAndXjStatus() {
		return isAndXjStatus;
	}
	public void setIsAndXjStatus(String isAndXjStatus) {
		this.isAndXjStatus = isAndXjStatus;
	}
	public String getIsAndForm() {
		return isAndForm;
	}
	public void setIsAndForm(String isAndForm) {
		this.isAndForm = isAndForm;
	}
	public String getIsAndFreeType() {
		return isAndFreeType;
	}
	public void setIsAndFreeType(String isAndFreeType) {
		this.isAndFreeType = isAndFreeType;
	}
	public Integer getParaNum() {
		return paraNum;
	}
	public void setParaNum(Integer paraNum) {
		this.paraNum = paraNum;
	}
	public String getIsAndYear() {
		return isAndYear;
	}
	public void setIsAndYear(String isAndYear) {
		this.isAndYear = isAndYear;
	}
	public String getXYear() {
		return xYear;
	}
	public void setXYear(String year) {
		xYear = year;
	}
	public String getIsAndClass() {
		return isAndClass;
	}
	public void setIsAndClass(String isAndClass) {
		this.isAndClass = isAndClass;
	}
	public String getXClass() {
		return xClass;
	}
	public void setXClass(String class1) {
		xClass = class1;
	}


}
