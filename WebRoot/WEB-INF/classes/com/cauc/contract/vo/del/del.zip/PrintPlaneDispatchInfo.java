package com.cauc.training.vo;

public class PrintPlaneDispatchInfo implements java.io.Serializable {

	private static final long serialVersionUID = 3456547158596848315L;

	private String planeform;
	private String VPlanecode;
	private String teacher;
	private String datetime;
	
	public String getPlaneform() {
		return planeform;
	}
	public void setPlaneform(String planeform) {
		this.planeform = planeform;
	}
	public String getVPlanecode() {
		return VPlanecode;
	}
	public void setVPlanecode(String vPlanecode) {
		VPlanecode = vPlanecode;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	
	
}
