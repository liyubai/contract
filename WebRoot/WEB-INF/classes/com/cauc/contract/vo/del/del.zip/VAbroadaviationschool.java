package com.cauc.training.vo;


public class VAbroadaviationschool implements java.io.Serializable {

	private static final long serialVersionUID = -2171751378026924432L;
	private String VSchoolname;
	private String VIntroduction;
	private String VCountry;
	private String VAddress;
	private String VWeb;
	private String VCode;
	private String DEffectdate;
	public String getVSchoolname() {
		return VSchoolname;
	}
	public void setVSchoolname(String vSchoolname) {
		VSchoolname = vSchoolname;
	}
	public String getVIntroduction() {
		return VIntroduction;
	}
	public void setVIntroduction(String vIntroduction) {
		VIntroduction = vIntroduction;
	}
	public String getVCountry() {
		return VCountry;
	}
	public void setVCountry(String vCountry) {
		VCountry = vCountry;
	}
	public String getVAddress() {
		return VAddress;
	}
	public void setVAddress(String vAddress) {
		VAddress = vAddress;
	}
	public String getVWeb() {
		return VWeb;
	}
	public void setVWeb(String vWeb) {
		VWeb = vWeb;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getDEffectdate() {
		return DEffectdate;
	}
	public void setDEffectdate(String dEffectdate) {
		DEffectdate = dEffectdate;
	}
	
	

}
