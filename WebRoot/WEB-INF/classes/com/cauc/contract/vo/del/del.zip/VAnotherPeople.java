package com.cauc.training.vo;

import java.util.Date;

public class VAnotherPeople implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6446772198367064453L;
	private String VId;
	private String VName;//姓名
	private String VCode;//编号
	private String VLxfs;//联系方式
	private String VCardid;
	private String VSex;//性别
	private Date DCsrq;
	private String VMz;
	private String VZzmm;
	private String VJg;
	private String VJtzz;
	private String VWhcd;
	private Date DCrgzsj;
	private Date DCreatedate;
	private String deptId;//部门ID
	private String deptName;//部门名称
	/**
	 * 创建人ID	
	 */
	private String userId;
	public VAnotherPeople(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVLxfs() {
		return VLxfs;
	}
	public void setVLxfs(String vLxfs) {
		VLxfs = vLxfs;
	}
	public String getVCardid() {
		return VCardid;
	}
	public void setVCardid(String vCardid) {
		VCardid = vCardid;
	}
	public String getVSex() {
		return VSex;
	}
	public void setVSex(String vSex) {
		VSex = vSex;
	}
	public Date getDCsrq() {
		return DCsrq;
	}
	public void setDCsrq(Date dCsrq) {
		DCsrq = dCsrq;
	}
	public String getVMz() {
		return VMz;
	}
	public void setVMz(String vMz) {
		VMz = vMz;
	}
	public String getVZzmm() {
		return VZzmm;
	}
	public void setVZzmm(String vZzmm) {
		VZzmm = vZzmm;
	}
	public String getVJg() {
		return VJg;
	}
	public void setVJg(String vJg) {
		VJg = vJg;
	}
	public String getVJtzz() {
		return VJtzz;
	}
	public void setVJtzz(String vJtzz) {
		VJtzz = vJtzz;
	}
	public String getVWhcd() {
		return VWhcd;
	}
	public void setVWhcd(String vWhcd) {
		VWhcd = vWhcd;
	}
	public Date getDCrgzsj() {
		return DCrgzsj;
	}
	public void setDCrgzsj(Date dCrgzsj) {
		DCrgzsj = dCrgzsj;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
