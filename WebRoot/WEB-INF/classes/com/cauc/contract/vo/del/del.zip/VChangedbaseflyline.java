package com.cauc.training.vo;


public class VChangedbaseflyline implements java.io.Serializable{
	
	
	private static final long serialVersionUID = -8217633351225498149L;
	private String VId;
	private String startStationId;
	private String endStationId;
	private double DCourse;
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getStartStationId() {
		return startStationId;
	}
	public void setStartStationId(String startStationId) {
		this.startStationId = startStationId;
	}
	public String getEndStationId() {
		return endStationId;
	}
	public void setEndStationId(String endStationId) {
		this.endStationId = endStationId;
	}
	public double getDCourse() {
		return DCourse;
	}
	public void setDCourse(double dCourse) {
		DCourse = dCourse;
	}
	
	
}
