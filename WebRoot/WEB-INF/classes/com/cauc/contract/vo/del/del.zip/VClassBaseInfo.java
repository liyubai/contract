package com.cauc.training.vo;

//
public class VClassBaseInfo implements java.io.Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4348585352171311793L;

	private String VId;
	
	private String VClassId;
	
	private String VTeacherId;
	
	private String DCreateClassTime;
	
	private String DBeginLessionTime;
	
	private String DEndLessionTime;
	
	private int iModel;
	
	private String DCreateDate;
	
	private String VCreateUserId;

	public String getVId() {
		return VId;
	}

	public void setVId(String id) {
		VId = id;
	}

	public String getVClassId() {
		return VClassId;
	}

	public void setVClassId(String classId) {
		VClassId = classId;
	}

	public String getVTeacherId() {
		return VTeacherId;
	}

	public void setVTeacherId(String teacherId) {
		VTeacherId = teacherId;
	}

	public String getDCreateClassTime() {
		return DCreateClassTime;
	}

	public void setDCreateClassTime(String createClassTime) {
		DCreateClassTime = createClassTime;
	}

	public String getDBeginLessionTime() {
		return DBeginLessionTime;
	}

	public void setDBeginLessionTime(String beginLessionTime) {
		DBeginLessionTime = beginLessionTime;
	}

	public String getDEndLessionTime() {
		return DEndLessionTime;
	}

	public void setDEndLessionTime(String endLessionTime) {
		DEndLessionTime = endLessionTime;
	}

	public int getIModel() {
		return iModel;
	}

	public void setIModel(int model) {
		iModel = model;
	}

	public String getDCreateDate() {
		return DCreateDate;
	}

	public void setDCreateDate(String createDate) {
		DCreateDate = createDate;
	}

	public String getVCreateUserId() {
		return VCreateUserId;
	}

	public void setVCreateUserId(String createUserId) {
		VCreateUserId = createUserId;
	}

	
}
