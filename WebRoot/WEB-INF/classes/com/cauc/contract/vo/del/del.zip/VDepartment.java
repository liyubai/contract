package com.cauc.training.vo;

import java.util.Date;

public class VDepartment implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5237839587923233539L;
	private String VId;
	private String VName;
	private String VParentid;
	private Integer IOrder;
	private Date DCreatedate;
	/**
	 * 创建人ID	
	 */
	private String userId;
	public VDepartment(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public Integer getIOrder() {
		return IOrder;
	}
	public void setIOrder(Integer iOrder) {
		IOrder = iOrder;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
