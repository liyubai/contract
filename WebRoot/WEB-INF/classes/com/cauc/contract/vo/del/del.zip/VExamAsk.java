package com.cauc.training.vo;

public class VExamAsk implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7132109534812567474L;

}
