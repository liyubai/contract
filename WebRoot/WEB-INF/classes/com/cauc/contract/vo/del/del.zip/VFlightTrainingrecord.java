package com.cauc.training.vo;

public class VFlightTrainingrecord  implements java.io.Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3179308395273315747L;
	private String VCode;
	private String VName;
	private String sex;
	private String teaName;
	private String DFlymoment;
	private String DEndmoment;
	private String VPlanecode;
	private String DTrantime;
	
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getDFlymoment() {
		return DFlymoment;
	}
	public void setDFlymoment(String dFlymoment) {
		DFlymoment = dFlymoment;
	}
	public String getDEndmoment() {
		return DEndmoment;
	}
	public void setDEndmoment(String dEndmoment) {
		DEndmoment = dEndmoment;
	}
	public String getVPlanecode() {
		return VPlanecode;
	}
	public void setVPlanecode(String vPlanecode) {
		VPlanecode = vPlanecode;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDTrantime() {
		return DTrantime;
	}
	public void setDTrantime(String dTrantime) {
		DTrantime = dTrantime;
	}
	
	
}
