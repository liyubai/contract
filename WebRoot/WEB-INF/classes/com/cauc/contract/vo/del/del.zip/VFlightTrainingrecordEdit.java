package com.cauc.training.vo;

import java.util.List;

public class VFlightTrainingrecordEdit implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7797202373068004242L;
	
	private String VId;
	private String VFlytype;
	private String VFlytypeid;
	private String studentName;
	private String studentVCode;
	private String studentid;
	private String outlineid;
	private String VFpos;
	private String VLpos;
	private String VJtpos;	
	private String teacherVcode;
	private String teacherName;
	private String teacherid;
	private String monitorteacherName;
	private String monitorteacherid;
	
	private String VNo;
	private String lessonName;
	private String lessonId;
	private Integer IIsthree;
	private Integer IOneNum;
	private Integer ITotalNum;
	
	private Integer kxzx;
	private String planeid;
	private String planeCode;
	private String planeForm;
	private Integer ISeat;
	private Integer time;


	private String DFlydate;
	private String DFlymoment;
	private String DEndmoment;
	private String DTrantime;
	private Integer ILanddaytimes;
	private Integer ILangnighttimes;
	private String VSecondstudent;
	private Integer IAuditstatus;
	
	//以下经历时间
	
	private String DJizhangtime;
	private String DDanfeitime;
	private String DZhuanchangtime;
	private String DYejiantime;
	private String DJiashiyuantime;
	private String DFujiashitime;
	private String DDaifeitime;
	private String DFjszhuanchangtime;
	private String DFjszcyjtime;
	private String DMoniyibiaotime;
	private String DZhenshiyibiao;
	private String VTranpos;
	private String DMnjsj;
	private String DXlqsj;
	private String DTeachertime;
	private String VLhy;
	private String VTxy;
	private String VJxy;
	private String VBz;
	private String DCreatedate;
	
	private List<VFlightTrainingrecordDetail> historyList;

	public String getVId() {
		return VId;
	}

	public void setVId(String vId) {
		VId = vId;
	}

	public String getVFlytype() {
		return VFlytype;
	}

	public void setVFlytype(String vFlytype) {
		VFlytype = vFlytype;
	}

	public String getVFlytypeid() {
		return VFlytypeid;
	}

	public void setVFlytypeid(String vFlytypeid) {
		VFlytypeid = vFlytypeid;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentVCode() {
		return studentVCode;
	}

	public void setStudentVCode(String studentVCode) {
		this.studentVCode = studentVCode;
	}

	public String getStudentid() {
		return studentid;
	}

	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}

	public String getOutlineid() {
		return outlineid;
	}

	public void setOutlineid(String outlineid) {
		this.outlineid = outlineid;
	}

	public String getVFpos() {
		return VFpos;
	}

	public void setVFpos(String vFpos) {
		VFpos = vFpos;
	}

	public String getVLpos() {
		return VLpos;
	}

	public void setVLpos(String vLpos) {
		VLpos = vLpos;
	}

	public String getVJtpos() {
		return VJtpos;
	}

	public void setVJtpos(String vJtpos) {
		VJtpos = vJtpos;
	}

	public String getTeacherVcode() {
		return teacherVcode;
	}

	public void setTeacherVcode(String teacherVcode) {
		this.teacherVcode = teacherVcode;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(String teacherid) {
		this.teacherid = teacherid;
	}

	public String getMonitorteacherName() {
		return monitorteacherName;
	}

	public void setMonitorteacherName(String monitorteacherName) {
		this.monitorteacherName = monitorteacherName;
	}

	public String getMonitorteacherid() {
		return monitorteacherid;
	}

	public void setMonitorteacherid(String monitorteacherid) {
		this.monitorteacherid = monitorteacherid;
	}

	public String getVNo() {
		return VNo;
	}

	public void setVNo(String vNo) {
		VNo = vNo;
	}

	public String getLessonName() {
		return lessonName;
	}

	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}

	public String getLessonId() {
		return lessonId;
	}

	public void setLessonId(String lessonId) {
		this.lessonId = lessonId;
	}

	public Integer getKxzx() {
		return kxzx;
	}

	public void setKxzx(Integer kxzx) {
		this.kxzx = kxzx;
	}

	public String getPlaneid() {
		return planeid;
	}

	public void setPlaneid(String planeid) {
		this.planeid = planeid;
	}

	public String getPlaneCode() {
		return planeCode;
	}

	public void setPlaneCode(String planeCode) {
		this.planeCode = planeCode;
	}

	public String getPlaneForm() {
		return planeForm;
	}

	public void setPlaneForm(String planeForm) {
		this.planeForm = planeForm;
	}

	public Integer getISeat() {
		return ISeat;
	}

	public void setISeat(Integer iSeat) {
		ISeat = iSeat;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public String getDFlydate() {
		return DFlydate;
	}

	public void setDFlydate(String dFlydate) {
		DFlydate = dFlydate;
	}

	public String getDFlymoment() {
		return DFlymoment;
	}

	public void setDFlymoment(String dFlymoment) {
		DFlymoment = dFlymoment;
	}

	public String getDEndmoment() {
		return DEndmoment;
	}

	public void setDEndmoment(String dEndmoment) {
		DEndmoment = dEndmoment;
	}

	public String getDTrantime() {
		return DTrantime;
	}

	public void setDTrantime(String dTrantime) {
		DTrantime = dTrantime;
	}

	public Integer getILanddaytimes() {
		return ILanddaytimes;
	}

	public void setILanddaytimes(Integer iLanddaytimes) {
		ILanddaytimes = iLanddaytimes;
	}

	public Integer getILangnighttimes() {
		return ILangnighttimes;
	}

	public void setILangnighttimes(Integer iLangnighttimes) {
		ILangnighttimes = iLangnighttimes;
	}

	public String getVSecondstudent() {
		return VSecondstudent;
	}

	public void setVSecondstudent(String vSecondstudent) {
		VSecondstudent = vSecondstudent;
	}

	public Integer getIAuditstatus() {
		return IAuditstatus;
	}

	public void setIAuditstatus(Integer iAuditstatus) {
		IAuditstatus = iAuditstatus;
	}

	public String getDJizhangtime() {
		return DJizhangtime;
	}

	public void setDJizhangtime(String dJizhangtime) {
		DJizhangtime = dJizhangtime;
	}

	public String getDDanfeitime() {
		return DDanfeitime;
	}

	public void setDDanfeitime(String dDanfeitime) {
		DDanfeitime = dDanfeitime;
	}

	public String getDZhuanchangtime() {
		return DZhuanchangtime;
	}

	public void setDZhuanchangtime(String dZhuanchangtime) {
		DZhuanchangtime = dZhuanchangtime;
	}

	public String getDYejiantime() {
		return DYejiantime;
	}

	public void setDYejiantime(String dYejiantime) {
		DYejiantime = dYejiantime;
	}

	public String getDJiashiyuantime() {
		return DJiashiyuantime;
	}

	public void setDJiashiyuantime(String dJiashiyuantime) {
		DJiashiyuantime = dJiashiyuantime;
	}

	public String getDFujiashitime() {
		return DFujiashitime;
	}

	public void setDFujiashitime(String dFujiashitime) {
		DFujiashitime = dFujiashitime;
	}

	public String getDDaifeitime() {
		return DDaifeitime;
	}

	public void setDDaifeitime(String dDaifeitime) {
		DDaifeitime = dDaifeitime;
	}

	public String getDFjszhuanchangtime() {
		return DFjszhuanchangtime;
	}

	public void setDFjszhuanchangtime(String dFjszhuanchangtime) {
		DFjszhuanchangtime = dFjszhuanchangtime;
	}

	public String getDFjszcyjtime() {
		return DFjszcyjtime;
	}

	public void setDFjszcyjtime(String dFjszcyjtime) {
		DFjszcyjtime = dFjszcyjtime;
	}

	public String getDMoniyibiaotime() {
		return DMoniyibiaotime;
	}

	public void setDMoniyibiaotime(String dMoniyibiaotime) {
		DMoniyibiaotime = dMoniyibiaotime;
	}

	public String getDZhenshiyibiao() {
		return DZhenshiyibiao;
	}

	public void setDZhenshiyibiao(String dZhenshiyibiao) {
		DZhenshiyibiao = dZhenshiyibiao;
	}

	public String getVTranpos() {
		return VTranpos;
	}

	public void setVTranpos(String vTranpos) {
		VTranpos = vTranpos;
	}

	public String getDMnjsj() {
		return DMnjsj;
	}

	public void setDMnjsj(String dMnjsj) {
		DMnjsj = dMnjsj;
	}

	public String getDXlqsj() {
		return DXlqsj;
	}

	public void setDXlqsj(String dXlqsj) {
		DXlqsj = dXlqsj;
	}

	public String getDTeachertime() {
		return DTeachertime;
	}

	public void setDTeachertime(String dTeachertime) {
		DTeachertime = dTeachertime;
	}

	public String getVLhy() {
		return VLhy;
	}

	public void setVLhy(String vLhy) {
		VLhy = vLhy;
	}

	public String getVTxy() {
		return VTxy;
	}

	public void setVTxy(String vTxy) {
		VTxy = vTxy;
	}

	public String getVJxy() {
		return VJxy;
	}

	public void setVJxy(String vJxy) {
		VJxy = vJxy;
	}

	public String getVBz() {
		return VBz;
	}

	public void setVBz(String vBz) {
		VBz = vBz;
	}

	public List<VFlightTrainingrecordDetail> getHistoryList() {
		return historyList;
	}

	public void setHistoryList(List<VFlightTrainingrecordDetail> historyList) {
		this.historyList = historyList;
	}

	public String getDCreatedate() {
		return DCreatedate;
	}

	public void setDCreatedate(String dCreatedate) {
		DCreatedate = dCreatedate;
	}

	public Integer getIIsthree() {
		return IIsthree;
	}

	public void setIIsthree(Integer iIsthree) {
		IIsthree = iIsthree;
	}

	public Integer getIOneNum() {
		return IOneNum;
	}

	public void setIOneNum(Integer iOneNum) {
		IOneNum = iOneNum;
	}

	public Integer getITotalNum() {
		return ITotalNum;
	}

	public void setITotalNum(Integer iTotalNum) {
		ITotalNum = iTotalNum;
	}
	
	

}
