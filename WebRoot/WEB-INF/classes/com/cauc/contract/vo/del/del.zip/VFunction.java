package com.cauc.training.vo;

import java.util.Date;


public class VFunction implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3091029207867777423L;
	private String VId;
	private String VName;
	private String VParentid;
	private Integer IOrder;
	private String VUrl;
	private Date DCreateDate;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public Integer getIOrder() {
		return IOrder;
	}
	public void setIOrder(Integer iOrder) {
		IOrder = iOrder;
	}
	public String getVUrl() {
		return VUrl;
	}
	public void setVUrl(String vUrl) {
		VUrl = vUrl;
	}
	public Date getDCreateDate() {
		return DCreateDate;
	}
	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}
	
	
}
