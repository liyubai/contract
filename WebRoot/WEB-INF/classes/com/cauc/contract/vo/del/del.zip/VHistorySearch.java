package com.cauc.training.vo;

import java.util.Date;

public class VHistorySearch implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -340398063238002109L;
	private String VId;
	private String VName;
	private String deptName;
	private int ILevel;
	private String VNation;
	private Date DResultdate;
	private Date DResultdate1;
	private String VDoctor;
	private String VIssuer;
	private String VCompany;
	private Date DIssueTime;
	private Date DIssueTime1;
	private Date DUsedTime;
	private Date DUsedTime1;
	
	public VHistorySearch(){}
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public int getILevel() {
		return ILevel;
	}
	public void setILevel(int iLevel) {
		ILevel = iLevel;
	}
	public String getVNation() {
		return VNation;
	}
	public void setVNation(String vNation) {
		VNation = vNation;
	}
	public Date getDResultdate() {
		return DResultdate;
	}
	public void setDResultdate(Date dResultdate) {
		DResultdate = dResultdate;
	}
	public Date getDResultdate1() {
		return DResultdate1;
	}
	public void setDResultdate1(Date dResultdate1) {
		DResultdate1 = dResultdate1;
	}
	public String getVDoctor() {
		return VDoctor;
	}
	public void setVDoctor(String vDoctor) {
		VDoctor = vDoctor;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}
	public String getVCompany() {
		return VCompany;
	}
	public void setVCompany(String vCompany) {
		VCompany = vCompany;
	}
	public Date getDIssueTime() {
		return DIssueTime;
	}
	public void setDIssueTime(Date dIssueTime) {
		DIssueTime = dIssueTime;
	}
	public Date getDIssueTime1() {
		return DIssueTime1;
	}
	public void setDIssueTime1(Date dIssueTime1) {
		DIssueTime1 = dIssueTime1;
	}
	public Date getDUsedTime() {
		return DUsedTime;
	}
	public void setDUsedTime(Date dUsedTime) {
		DUsedTime = dUsedTime;
	}
	public Date getDUsedTime1() {
		return DUsedTime1;
	}
	public void setDUsedTime1(Date dUsedTime1) {
		DUsedTime1 = dUsedTime1;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}
