package com.cauc.training.vo;

import java.util.List;



public class VLeftNavigation implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5598332665347062996L;
	private String VName;
	private String VParentid;
	private String VUrl;
	 
	private List<VLeftNavigationNext> functionList;
	private Integer isnext;//0：无下级、大于0代表有
	
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public String getVUrl() {
		return VUrl;
	}
	public void setVUrl(String vUrl) {
		VUrl = vUrl;
	}

	public Integer getIsnext() {
		return isnext;
	}
	public void setIsnext(Integer isnext) {
		this.isnext = isnext;
	}
	public List<VLeftNavigationNext> getFunctionList() {
		return functionList;
	}
	public void setFunctionList(List<VLeftNavigationNext> functionList) {
		this.functionList = functionList;
	}



	
}
