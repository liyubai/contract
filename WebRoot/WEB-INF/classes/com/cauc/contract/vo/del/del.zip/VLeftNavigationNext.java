package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.TFunction;

public class VLeftNavigationNext implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7084507979326636101L;
	private String VName;
	private String VParentid;
	private String VUrl;
	private Integer IDh;
	private List<TFunction> functionNextList;
	private Integer isnext;//0：无下级、大于0代表有
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public String getVUrl() {
		return VUrl;
	}
	public void setVUrl(String vUrl) {
		VUrl = vUrl;
	}


	public List<TFunction> getFunctionNextList() {
		return functionNextList;
	}
	public void setFunctionNextList(List<TFunction> functionNextList) {
		this.functionNextList = functionNextList;
	}
	public Integer getIsnext() {
		return isnext;
	}
	public void setIsnext(Integer isnext) {
		this.isnext = isnext;
	}
	public Integer getIDh() {
		return IDh;
	}
	public void setIDh(Integer iDh) {
		IDh = iDh;
	}
	
	
}
