package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.RecommendStudentLicenseExam;


public class VLessonScore implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1537534830338540270L;
	private String VId;//学员id
	private String VCode;
	private String VName;
	private Integer tuijian;
	private String vday;
	private String lastTime;
	private String tjTime;
	
	private List<VScore> scoreList;
	
	private List<RecommendStudentLicenseExam> recomlist;
	

	public String getVId() {
		return VId;
	}

	public void setVId(String vId) {
		VId = vId;
	}

	public String getVCode() {
		return VCode;
	}

	public void setVCode(String vCode) {
		VCode = vCode;
	}

	public String getVName() {
		return VName;
	}

	public void setVName(String vName) {
		VName = vName;
	}

	public List<VScore> getScoreList() {
		return scoreList;
	}

	public void setScoreList(List<VScore> scoreList) {
		this.scoreList = scoreList;
	}

	public Integer getTuijian() {
		return tuijian;
	}

	public void setTuijian(Integer tuijian) {
		this.tuijian = tuijian;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public String getTjTime() {
		return tjTime;
	}

	public void setTjTime(String tjTime) {
		this.tjTime = tjTime;
	}

	public String getVday() {
		return vday;
	}

	public void setVday(String vday) {
		this.vday = vday;
	}

	public List<RecommendStudentLicenseExam> getRecomlist() {
		return recomlist;
	}

	public void setRecomlist(List<RecommendStudentLicenseExam> recomlist) {
		this.recomlist = recomlist;
	}

	
}
