package com.cauc.training.vo;

import java.util.Date;

/**
 * TDiction与TDictype实体类对应的VO类
 * 
 * */
public class VODicInfoOrDicType implements java.io.Serializable {
	
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -5015663735761856184L;
	//TDiction自己的属性，将使用到的属性提取出来，属性名称可以根据需要任意命名
    private String VId;
    private String usernameForTDic;
    private String VName;
    private Date DCreatedate;
    
    //TDictype的属性，即关联类，将使用到的属性提取出来，属性名称可以根据需要任意命名
    private String typeVId;
    private String typeVName;
    
	public String getVId() {
		return VId;
	}
	
	public void setVId(String vId) {
		VId = vId;
	}
	
	public String getUsernameForTDic() {
		return usernameForTDic;
	}
	
	public void setUsernameForTDic(String usernameForTDic) {
		this.usernameForTDic = usernameForTDic;
	}
	
	public String getVName() {
		return VName;
	}
	
	public void setVName(String vName) {
		VName = vName;
	}
	
	public Date getDCreatedate() {
		return DCreatedate;
	}
	
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}

	public String getTypeVId() {
		return typeVId;
	}

	public void setTypeVId(String typeVId) {
		this.typeVId = typeVId;
	}

	public String getTypeVName() {
		return typeVName;
	}

	public void setTypeVName(String typeVName) {
		this.typeVName = typeVName;
	}
	

    
}
