package com.cauc.training.vo;

public class VODicType implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3163855972831690618L;
	

}
