package com.cauc.training.vo;

import java.util.Date;

public class VOPolicyLaws implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3983561065819840092L;
	private String VId;
	private Integer INo;
	private Integer IType;
	private String VContent;
	private Integer IContentType;
	private Integer IContentTime;
	private Integer ILimitTime;
	private Date DCreatedate;
	
	
	public String getVId() {
		return VId;
	}
	
	public void setVId(String vId) {
		VId = vId;
	}
	
	public Integer getINo() {
		return INo;
	}
	
	public void setINo(Integer iNo) {
		INo = iNo;
	}
	
	public Integer getIType() {
		return IType;
	}
	
	public void setIType(Integer iType) {
		IType = iType;
	}
	
	public String getVContent() {
		return VContent;
	}
	
	public void setVContent(String vContent) {
		VContent = vContent;
	}
	
	public Integer getIContentType() {
		return IContentType;
	}
	
	public void setIContentType(Integer iContentType) {
		IContentType = iContentType;
	}
	
	public Integer getIContentTime() {
		return IContentTime;
	}
	
	public void setIContentTime(Integer iContentTime) {
		IContentTime = iContentTime;
	}
	
	public Integer getILimitTime() {
		return ILimitTime;
	}
	
	public void setILimitTime(Integer iLimitTime) {
		ILimitTime = iLimitTime;
	}
	
	public Date getDCreatedate() {
		return DCreatedate;
	}
	
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}

}
