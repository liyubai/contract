package com.cauc.training.vo;


public class VORole implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4316901506657866887L;

	private String VId;

	private String VName;
	private String VDescription;
	
	
	public String getVId() {
		return VId;
	}
	
	public void setVId(String vId) {
		VId = vId;
	}
		
	public String getVName() {
		return VName;
	}
	
	public void setVName(String vName) {
		VName = vName;
	}
	
	public String getVDescription() {
		return VDescription;
	}
	
	public void setVDescription(String vDescription) {
		VDescription = vDescription;
	}

	

}
