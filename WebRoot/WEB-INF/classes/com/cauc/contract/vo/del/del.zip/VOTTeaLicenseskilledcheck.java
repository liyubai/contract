package com.cauc.training.vo;

import java.util.Date;

public class VOTTeaLicenseskilledcheck implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4583495681792692508L;
	private String VId;
	private String teacherLicenseupdate;
	private String TTeaLicense;
	private String TUser;
	private Date DCheckdate;
	private String VCheckcontent;
	private String VCheckteacher;
	private String VBz;
	private Date DEffectdate;
	private String VFlyform;
	private Integer IChecktype;
	private Date DCreatedate;
	private String teacherCode;
	private String deptName;
	
	private String viewDCheckdate;
	private String typeName;
	private int iday;
	private String viewDEffectdate;
	
	public VOTTeaLicenseskilledcheck(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getTeacherLicenseupdate() {
		return teacherLicenseupdate;
	}
	public void setTeacherLicenseupdate(String teacherLicenseupdate) {
		this.teacherLicenseupdate = teacherLicenseupdate;
	}
	public String getTTeaLicense() {
		return TTeaLicense;
	}
	public void setTTeaLicense(String tTeaLicense) {
		TTeaLicense = tTeaLicense;
	}
	public String getTUser() {
		return TUser;
	}
	public void setTUser(String tUser) {
		TUser = tUser;
	}
	public Date getDCheckdate() {
		return DCheckdate;
	}
	public void setDCheckdate(Date dCheckdate) {
		DCheckdate = dCheckdate;
	}
	public String getVCheckcontent() {
		return VCheckcontent;
	}
	public void setVCheckcontent(String vCheckcontent) {
		VCheckcontent = vCheckcontent;
	}
	public String getVCheckteacher() {
		return VCheckteacher;
	}
	public void setVCheckteacher(String vCheckteacher) {
		VCheckteacher = vCheckteacher;
	}
	public String getVBz() {
		return VBz;
	}
	public void setVBz(String vBz) {
		VBz = vBz;
	}
	public Date getDEffectdate() {
		return DEffectdate;
	}
	public void setDEffectdate(Date dEffectdate) {
		DEffectdate = dEffectdate;
	}
	public String getVFlyform() {
		return VFlyform;
	}
	public void setVFlyform(String vFlyform) {
		VFlyform = vFlyform;
	}
	public Integer getIChecktype() {
		return IChecktype;
	}
	public void setIChecktype(Integer iChecktype) {
		IChecktype = iChecktype;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getTeacherCode() {
		return teacherCode;
	}
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getViewDCheckdate() {
		return viewDCheckdate;
	}
	public void setViewDCheckdate(String viewDCheckdate) {
		this.viewDCheckdate = viewDCheckdate;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public int getIday() {
		return iday;
	}
	public void setIday(int iday) {
		this.iday = iday;
	}
	public String getViewDEffectdate() {
		return viewDEffectdate;
	}
	public void setViewDEffectdate(String viewDEffectdate) {
		this.viewDEffectdate = viewDEffectdate;
	}
	
}
