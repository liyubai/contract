package com.cauc.training.vo;

import java.util.Date;

public class VOTUser  implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1552659808930280714L;
	private String VId;
	private String VUsername;
	private String VPassword;
	private Integer IStatus;
	private Integer IAdminStatus;
	private String IUserType;
	private Date DCreateDate;
	private String VRealname;
	private String VJob;
	private String org;
	private String roleName;
	private String sign;
	private String ldap;
	
	public String getVId() {
		return VId;
	}
	
	public void setVId(String vId) {
		VId = vId;
	}
	
	public String getVUsername() {
		return VUsername;
	}
	
	public void setVUsername(String vUsername) {
		VUsername = vUsername;
	}
	
	public String getVPassword() {
		return VPassword;
	}
	
	public void setVPassword(String vPassword) {
		VPassword = vPassword;
	}
	
	public Integer getIStatus() {
		return IStatus;
	}

	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}

	public Integer getIAdminStatus() {
		return IAdminStatus;
	}
	
	public void setIAdminStatus(Integer iAdminStatus) {
		IAdminStatus = iAdminStatus;
	}

	public String getIUserType() {
		return IUserType;
	}

	public void setIUserType(String iUserType) {
		IUserType = iUserType;
	}

	public Date getDCreateDate() {
		return DCreateDate;
	}

	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}

	public String getVRealname() {
		return VRealname;
	}

	public void setVRealname(String vRealname) {
		VRealname = vRealname;
	}

	public String getVJob() {
		return VJob;
	}

	public void setVJob(String vJob) {
		VJob = vJob;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getLdap() {
		return ldap;
	}

	public void setLdap(String ldap) {
		this.ldap = ldap;
	}
	
	
	
	
}
