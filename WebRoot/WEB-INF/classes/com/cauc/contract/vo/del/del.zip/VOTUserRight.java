package com.cauc.training.vo;

/**
 * 用于封装TRole，在TRole的基础上添加了一个属性binding，用于表示该TRole对象是否与当前待绑定的用户有关联
 *  其他属性均用于封装TRole的相关属性值
 * */
public class VOTUserRight implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5218223944853291314L;
	private String VId;
	private String VName;
	private String VDescription;
	private Integer isWrite;
	
	//用于表示该TRole对象是否与当前待绑定的用户有关联
	private int binding;

	public String getVId() {
		return VId;
	}

	public void setVId(String vId) {
		VId = vId;
	}

	public String getVName() {
		return VName;
	}

	public void setVName(String vName) {
		VName = vName;
	}

	public String getVDescription() {
		return VDescription;
	}

	public void setVDescription(String vDescription) {
		VDescription = vDescription;
	}

	public int getBinding() {
		return binding;
	}

	public void setBinding(int binding) {
		this.binding = binding;
	}

	public Integer getIsWrite() {
		return isWrite;
	}

	public void setIsWrite(Integer isWrite) {
		this.isWrite = isWrite;
	}
	
	
	
}
