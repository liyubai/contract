package com.cauc.training.vo;

public class VOperateBean implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6059503806118446385L;
	String id;
	String userid;
	String name;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
