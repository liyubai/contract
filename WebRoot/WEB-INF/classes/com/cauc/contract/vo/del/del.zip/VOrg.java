package com.cauc.training.vo;

import java.util.Date;
import java.util.List;


public class VOrg implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5607220127859152406L;
	private boolean flag;
	private String VId;
	private String message;
	private String VParentid;
	private Integer IStatus;
	private Integer IDh;
	private Integer IRootid;
	private Date DCreateDate;
	private List<VTeacherBaseInfo> teacherBaseInfoList;
	
	private String VJishu;
	private String VZongjie;
	private String IPass;
	private String VCheckcomment;
	private String IZpzb;
	private String IZpjs;
	private String IZp;
	private Integer xue;
	private Integer si;
	private Integer shang;
	private Integer heji;
	public boolean getFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public Integer getIStatus() {
		return IStatus;
	}
	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}
	public Date getDCreateDate() {
		return DCreateDate;
	}
	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public Integer getIDh() {
		return IDh;
	}
	public void setIDh(Integer iDh) {
		IDh = iDh;
	}
	public List<VTeacherBaseInfo> getTeacherBaseInfoList() {
		return teacherBaseInfoList;
	}
	public void setTeacherBaseInfoList(List<VTeacherBaseInfo> teacherBaseInfoList) {
		this.teacherBaseInfoList = teacherBaseInfoList;
	}
	public Integer getIRootid() {
		return IRootid;
	}
	public void setIRootid(Integer iRootid) {
		IRootid = iRootid;
	}
	public String getVJishu() {
		return VJishu;
	}
	public void setVJishu(String vJishu) {
		VJishu = vJishu;
	}
	public String getVZongjie() {
		return VZongjie;
	}
	public void setVZongjie(String vZongjie) {
		VZongjie = vZongjie;
	}

	public String getVCheckcomment() {
		return VCheckcomment;
	}
	public void setVCheckcomment(String vCheckcomment) {
		VCheckcomment = vCheckcomment;
	}
	public String getIPass() {
		return IPass;
	}
	public void setIPass(String iPass) {
		IPass = iPass;
	}
	public String getIZpzb() {
		return IZpzb;
	}
	public void setIZpzb(String iZpzb) {
		IZpzb = iZpzb;
	}
	public String getIZpjs() {
		return IZpjs;
	}
	public void setIZpjs(String iZpjs) {
		IZpjs = iZpjs;
	}
	public String getIZp() {
		return IZp;
	}
	public void setIZp(String iZp) {
		IZp = iZp;
	}
	public Integer getXue() {
		return xue;
	}
	public void setXue(Integer xue) {
		this.xue = xue;
	}
	public Integer getSi() {
		return si;
	}
	public void setSi(Integer si) {
		this.si = si;
	}
	public Integer getShang() {
		return shang;
	}
	public void setShang(Integer shang) {
		this.shang = shang;
	}
	public Integer getHeji() {
		return heji;
	}
	public void setHeji(Integer heji) {
		this.heji = heji;
	}
	
}
