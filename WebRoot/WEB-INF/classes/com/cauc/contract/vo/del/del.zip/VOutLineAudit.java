package com.cauc.training.vo;


public class VOutLineAudit implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4043113183477232554L;
	private String userName;
	private String viewAudittime;
	private Integer IStatus;
	private String VReason;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getViewAudittime() {
		return viewAudittime;
	}
	public void setViewAudittime(String viewAudittime) {
		this.viewAudittime = viewAudittime;
	}
	public Integer getIStatus() {
		return IStatus;
	}
	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}
	public String getVReason() {
		return VReason;
	}
	public void setVReason(String vReason) {
		VReason = vReason;
	}
	
	
}
