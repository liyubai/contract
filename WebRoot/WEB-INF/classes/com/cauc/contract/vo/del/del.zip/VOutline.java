package com.cauc.training.vo;

public class VOutline implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3095125174703674241L;
	private String VId;
	private String VName;
	private String VParentid;
	private Integer IStatus;
	private String VNo;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public Integer getIStatus() {
		return IStatus;
	}
	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public String getVNo() {
		return VNo;
	}
	public void setVNo(String vNo) {
		VNo = vNo;
	}
	
	
}
