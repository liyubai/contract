package com.cauc.training.vo;

import java.util.Date;
import java.util.List;


public class VOutlineDetail implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2759323234772759838L;
	private String VId;
	private String VName;
	private String VCode;
	private String VBc;
	private String VRange;
	private String VTarget;
	private String VConditions;
	private String VTraincycle;
	private String VChangeschool;
	private String VStoptrain;
	private String VTrainmethod;
	private String VScorejudge;
	private String VTrainrecord;
	private Date DAudittime;
	private Date DUpdatetme;
	private Integer IUnits;
	private Integer IStages;
	private Integer ILessons;
	
	private Integer ILessonUnits;
	private Integer ILessonStages;
	private Integer ILessonLessons;
	
	private double DTraintime;
	private double DPlanetime;
	private double DTrainningdevicetime;
	private double DMonijitime;
		
	private double DLessonTraintime;
	private double DLessonDPlanetime;
	private double DLessonDTrainningdevicetime;
	private double DLessonMonijitime;
	
	private String VMeterclass;
	private String VMultipleclass;
	private String VTrainequipment;
	private String VTrainform;
	private Integer IStatus;
	private Integer hege;
	private String VFilename;
	private Date DCreatedate;
	
	private String STraintime;
	private String SPlanetime;
	private String STrainningdevicetime;
	private String SMonijitime;
		
	private String SLessonTraintime;
	private String SLessonDPlanetime;
	private String SLessonDTrainningdevicetime;
	private String SLessonMonijitime;
	
	private List<VOutLineAudit> viewOutLineAuditList;
	
	private String viewCreatedate;
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVBc() {
		return VBc;
	}
	public void setVBc(String vBc) {
		VBc = vBc;
	}
	public String getVRange() {
		return VRange;
	}
	public void setVRange(String vRange) {
		VRange = vRange;
	}
	public String getVTarget() {
		return VTarget;
	}
	public void setVTarget(String vTarget) {
		VTarget = vTarget;
	}
	public String getVConditions() {
		return VConditions;
	}
	public void setVConditions(String vConditions) {
		VConditions = vConditions;
	}
	public String getVTraincycle() {
		return VTraincycle;
	}
	public void setVTraincycle(String vTraincycle) {
		VTraincycle = vTraincycle;
	}
	public String getVChangeschool() {
		return VChangeschool;
	}
	public void setVChangeschool(String vChangeschool) {
		VChangeschool = vChangeschool;
	}
	public String getVStoptrain() {
		return VStoptrain;
	}
	public void setVStoptrain(String vStoptrain) {
		VStoptrain = vStoptrain;
	}
	public String getVTrainmethod() {
		return VTrainmethod;
	}
	public void setVTrainmethod(String vTrainmethod) {
		VTrainmethod = vTrainmethod;
	}
	public String getVScorejudge() {
		return VScorejudge;
	}
	public void setVScorejudge(String vScorejudge) {
		VScorejudge = vScorejudge;
	}
	public String getVTrainrecord() {
		return VTrainrecord;
	}
	public void setVTrainrecord(String vTrainrecord) {
		VTrainrecord = vTrainrecord;
	}
	public Date getDAudittime() {
		return DAudittime;
	}
	public void setDAudittime(Date dAudittime) {
		DAudittime = dAudittime;
	}
	public Date getDUpdatetme() {
		return DUpdatetme;
	}
	public void setDUpdatetme(Date dUpdatetme) {
		DUpdatetme = dUpdatetme;
	}
	public Integer getIUnits() {
		return IUnits;
	}
	public void setIUnits(Integer iUnits) {
		IUnits = iUnits;
	}
	public Integer getIStages() {
		return IStages;
	}
	public void setIStages(Integer iStages) {
		IStages = iStages;
	}
	public Integer getILessons() {
		return ILessons;
	}
	public void setILessons(Integer iLessons) {
		ILessons = iLessons;
	}
	public double getDTraintime() {
		return DTraintime;
	}
	public void setDTraintime(double dTraintime) {
		DTraintime = dTraintime;
	}
	public double getDPlanetime() {
		return DPlanetime;
	}
	public void setDPlanetime(double dPlanetime) {
		DPlanetime = dPlanetime;
	}
	public double getDTrainningdevicetime() {
		return DTrainningdevicetime;
	}
	public void setDTrainningdevicetime(double dTrainningdevicetime) {
		DTrainningdevicetime = dTrainningdevicetime;
	}
	public String getVMeterclass() {
		return VMeterclass;
	}
	public void setVMeterclass(String vMeterclass) {
		VMeterclass = vMeterclass;
	}
	public String getVMultipleclass() {
		return VMultipleclass;
	}
	public void setVMultipleclass(String vMultipleclass) {
		VMultipleclass = vMultipleclass;
	}
	public String getVTrainequipment() {
		return VTrainequipment;
	}
	public void setVTrainequipment(String vTrainequipment) {
		VTrainequipment = vTrainequipment;
	}
	public String getVTrainform() {
		return VTrainform;
	}
	public void setVTrainform(String vTrainform) {
		VTrainform = vTrainform;
	}
	public Integer getIStatus() {
		return IStatus;
	}
	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}
	public String getVFilename() {
		return VFilename;
	}
	public void setVFilename(String vFilename) {
		VFilename = vFilename;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public double getDLessonTraintime() {
		return DLessonTraintime;
	}
	public void setDLessonTraintime(double dLessonTraintime) {
		DLessonTraintime = dLessonTraintime;
	}
	public double getDLessonDPlanetime() {
		return DLessonDPlanetime;
	}
	public void setDLessonDPlanetime(double dLessonDPlanetime) {
		DLessonDPlanetime = dLessonDPlanetime;
	}
	public double getDLessonDTrainningdevicetime() {
		return DLessonDTrainningdevicetime;
	}
	public void setDLessonDTrainningdevicetime(double dLessonDTrainningdevicetime) {
		DLessonDTrainningdevicetime = dLessonDTrainningdevicetime;
	}
	public Integer getILessonUnits() {
		return ILessonUnits;
	}
	public void setILessonUnits(Integer iLessonUnits) {
		ILessonUnits = iLessonUnits;
	}
	public Integer getILessonStages() {
		return ILessonStages;
	}
	public void setILessonStages(Integer iLessonStages) {
		ILessonStages = iLessonStages;
	}
	public Integer getILessonLessons() {
		return ILessonLessons;
	}
	public void setILessonLessons(Integer iLessonLessons) {
		ILessonLessons = iLessonLessons;
	}
	public String getViewCreatedate() {
		return viewCreatedate;
	}
	public void setViewCreatedate(String viewCreatedate) {
		this.viewCreatedate = viewCreatedate;
	}
	public List<VOutLineAudit> getViewOutLineAuditList() {
		return viewOutLineAuditList;
	}
	public void setViewOutLineAuditList(List<VOutLineAudit> viewOutLineAuditList) {
		this.viewOutLineAuditList = viewOutLineAuditList;
	}
	public Integer getHege() {
		return hege;
	}
	public void setHege(Integer hege) {
		this.hege = hege;
	}
	public double getDMonijitime() {
		return DMonijitime;
	}
	public void setDMonijitime(double dMonijitime) {
		DMonijitime = dMonijitime;
	}
	public double getDLessonMonijitime() {
		return DLessonMonijitime;
	}
	public void setDLessonMonijitime(double dLessonMonijitime) {
		DLessonMonijitime = dLessonMonijitime;
	}
	public String getSTraintime() {
		return STraintime;
	}
	public void setSTraintime(String sTraintime) {
		STraintime = sTraintime;
	}
	public String getSPlanetime() {
		return SPlanetime;
	}
	public void setSPlanetime(String sPlanetime) {
		SPlanetime = sPlanetime;
	}
	public String getSTrainningdevicetime() {
		return STrainningdevicetime;
	}
	public void setSTrainningdevicetime(String sTrainningdevicetime) {
		STrainningdevicetime = sTrainningdevicetime;
	}
	public String getSMonijitime() {
		return SMonijitime;
	}
	public void setSMonijitime(String sMonijitime) {
		SMonijitime = sMonijitime;
	}
	public String getSLessonTraintime() {
		return SLessonTraintime;
	}
	public void setSLessonTraintime(String sLessonTraintime) {
		SLessonTraintime = sLessonTraintime;
	}
	public String getSLessonDPlanetime() {
		return SLessonDPlanetime;
	}
	public void setSLessonDPlanetime(String sLessonDPlanetime) {
		SLessonDPlanetime = sLessonDPlanetime;
	}
	public String getSLessonDTrainningdevicetime() {
		return SLessonDTrainningdevicetime;
	}
	public void setSLessonDTrainningdevicetime(String sLessonDTrainningdevicetime) {
		SLessonDTrainningdevicetime = sLessonDTrainningdevicetime;
	}
	public String getSLessonMonijitime() {
		return SLessonMonijitime;
	}
	public void setSLessonMonijitime(String sLessonMonijitime) {
		SLessonMonijitime = sLessonMonijitime;
	}



}
