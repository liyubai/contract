package com.cauc.training.vo;

public class VPlaneCheckCycle implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1485734159519849896L;

	private String VId;
	private Integer ICycle;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public Integer getICycle() {
		return ICycle;
	}
	public void setICycle(Integer iCycle) {
		ICycle = iCycle;
	}
	
	
}
