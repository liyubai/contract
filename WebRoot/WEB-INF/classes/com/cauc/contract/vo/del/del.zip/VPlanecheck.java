package com.cauc.training.vo;


public class VPlanecheck  implements java.io.Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1980805822476966772L;
	private String DChecktime;
	private String VCheckperson;
	private String VCheckresult;
	private String VChecktype;
	private double shengValue;
	private Integer formValue;
	private double times;
	private Double surpValue;
	private Integer isChange;
	
	public String getDChecktime() {
		return DChecktime;
	}
	public void setDChecktime(String dChecktime) {
		DChecktime = dChecktime;
	}
	public String getVCheckperson() {
		return VCheckperson;
	}
	public void setVCheckperson(String vCheckperson) {
		VCheckperson = vCheckperson;
	}
	public String getVCheckresult() {
		return VCheckresult;
	}
	public void setVCheckresult(String vCheckresult) {
		VCheckresult = vCheckresult;
	}
	public String getVChecktype() {
		return VChecktype;
	}
	public void setVChecktype(String vChecktype) {
		VChecktype = vChecktype;
	}

	public Integer getFormValue() {
		return formValue;
	}
	public void setFormValue(Integer formValue) {
		this.formValue = formValue;
	}


	public double getTimes() {
		return times;
	}
	public void setTimes(double times) {
		this.times = times;
	}
	public Integer getIsChange() {
		return isChange;
	}
	public void setIsChange(Integer isChange) {
		this.isChange = isChange;
	}
	public Double getSurpValue() {
		return surpValue;
	}
	public void setSurpValue(Double surpValue) {
		this.surpValue = surpValue;
	}
	public double getShengValue() {
		return shengValue;
	}
	public void setShengValue(double shengValue) {
		this.shengValue = shengValue;
	}


	
}
