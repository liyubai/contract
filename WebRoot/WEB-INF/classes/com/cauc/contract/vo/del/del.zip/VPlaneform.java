package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.PlaneCheckCycle;



public class VPlaneform implements java.io.Serializable{
	
	private static final long serialVersionUID = -2538931252832991736L;
	
	private String VId;
	private String VName;
	private String VChangshang;
	private String VXingzhi;
	private String VFtd;
	private String DShouming;
	private String DJbweight;
	private String DFweight;
	private String DLweight;
	private String DJgweight;
	private String VBz;
	private List<PlaneCheckCycle> checkList;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVChangshang() {
		return VChangshang;
	}
	public void setVChangshang(String vChangshang) {
		VChangshang = vChangshang;
	}
	public String getVXingzhi() {
		return VXingzhi;
	}
	public void setVXingzhi(String vXingzhi) {
		VXingzhi = vXingzhi;
	}
	public String getVFtd() {
		return VFtd;
	}
	public void setVFtd(String vFtd) {
		VFtd = vFtd;
	}

	public String getDShouming() {
		return DShouming;
	}
	public void setDShouming(String dShouming) {
		DShouming = dShouming;
	}
	public String getDJbweight() {
		return DJbweight;
	}
	public void setDJbweight(String dJbweight) {
		DJbweight = dJbweight;
	}
	public String getDFweight() {
		return DFweight;
	}
	public void setDFweight(String dFweight) {
		DFweight = dFweight;
	}
	public String getDLweight() {
		return DLweight;
	}
	public void setDLweight(String dLweight) {
		DLweight = dLweight;
	}
	public String getDJgweight() {
		return DJgweight;
	}
	public void setDJgweight(String dJgweight) {
		DJgweight = dJgweight;
	}
	public String getVBz() {
		return VBz;
	}
	public void setVBz(String vBz) {
		VBz = vBz;
	}
	public List<PlaneCheckCycle> getCheckList() {
		return checkList;
	}
	public void setCheckList(List<PlaneCheckCycle> checkList) {
		this.checkList = checkList;
	}

	
	
	
}
