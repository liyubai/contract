package com.cauc.training.vo;

import java.util.Date;
import java.util.List;

public class VPlaneinfo implements java.io.Serializable {
	
	private static final long serialVersionUID = 6307374260834171261L;
	private String VId;
	private String baseid;
	private String planeform;
	private String VPlanecode;
	private String DEnterdate;
	private Integer ITimes;
	private String DUsetime;
	private String DCsdjtime;
	private double DActflytime;
	private double DSjdjflytime;
	private String VHgz;
	private Integer IStatus;
	private String VDw;
	private String VBz;
	private Date DCreateDate;
	private double DWstime;
	private String DYbtime;
	private double DEbtime;
	private double DYqwbtime;
	private Integer IDeviceType;
	private String VZhuce;
	private String VCountry;
	private List<VPlanecheck> checkList;
	
	public Integer getIDeviceType() {
		return IDeviceType;
	}
	public void setIDeviceType(Integer iDeviceType) {
		IDeviceType = iDeviceType;
	}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getBaseid() {
		return baseid;
	}
	public void setBaseid(String baseid) {
		this.baseid = baseid;
	}
	public String getPlaneform() {
		return planeform;
	}
	public void setPlaneform(String planeform) {
		this.planeform = planeform;
	}
	public String getVPlanecode() {
		return VPlanecode;
	}
	public void setVPlanecode(String vPlanecode) {
		VPlanecode = vPlanecode;
	}

	public Integer getITimes() {
		return ITimes;
	}
	public void setITimes(Integer iTimes) {
		ITimes = iTimes;
	}

	public double getDActflytime() {
		return DActflytime;
	}
	public void setDActflytime(double dActflytime) {
		DActflytime = dActflytime;
	}
	public double getDSjdjflytime() {
		return DSjdjflytime;
	}
	public void setDSjdjflytime(double dSjdjflytime) {
		DSjdjflytime = dSjdjflytime;
	}
	public String getVHgz() {
		return VHgz;
	}
	public void setVHgz(String vHgz) {
		VHgz = vHgz;
	}
	public Integer getIStatus() {
		return IStatus;
	}
	public void setIStatus(Integer iStatus) {
		IStatus = iStatus;
	}
	public String getVDw() {
		return VDw;
	}
	public void setVDw(String vDw) {
		VDw = vDw;
	}
	public String getVBz() {
		return VBz;
	}
	public void setVBz(String vBz) {
		VBz = vBz;
	}
	public Date getDCreateDate() {
		return DCreateDate;
	}
	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}
	public double getDWstime() {
		return DWstime;
	}
	public void setDWstime(double dWstime) {
		DWstime = dWstime;
	}

	public double getDEbtime() {
		return DEbtime;
	}
	public void setDEbtime(double dEbtime) {
		DEbtime = dEbtime;
	}
	public double getDYqwbtime() {
		return DYqwbtime;
	}
	public void setDYqwbtime(double dYqwbtime) {
		DYqwbtime = dYqwbtime;
	}
	public String getDEnterdate() {
		return DEnterdate;
	}
	public void setDEnterdate(String dEnterdate) {
		DEnterdate = dEnterdate;
	}
	public String getVZhuce() {
		return VZhuce;
	}
	public void setVZhuce(String vZhuce) {
		VZhuce = vZhuce;
	}
	public String getVCountry() {
		return VCountry;
	}
	public void setVCountry(String vCountry) {
		VCountry = vCountry;
	}
	public String getDUsetime() {
		return DUsetime;
	}
	public void setDUsetime(String dUsetime) {
		DUsetime = dUsetime;
	}
	public String getDCsdjtime() {
		return DCsdjtime;
	}
	public void setDCsdjtime(String dCsdjtime) {
		DCsdjtime = dCsdjtime;
	}
	public String getDYbtime() {
		return DYbtime;
	}
	public void setDYbtime(String dYbtime) {
		DYbtime = dYbtime;
	}
	public List<VPlanecheck> getCheckList() {
		return checkList;
	}
	public void setCheckList(List<VPlanecheck> checkList) {
		this.checkList = checkList;
	}
	
	
}
