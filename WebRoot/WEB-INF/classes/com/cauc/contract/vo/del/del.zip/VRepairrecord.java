package com.cauc.training.vo;


public class VRepairrecord implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5332753504199252217L;
	private String VRepairperson;
	private String VContent;
	private String VRepairresult;
	private String DStarttime;
	private String DEndtime;
	
	public String getVRepairperson() {
		return VRepairperson;
	}
	public void setVRepairperson(String vRepairperson) {
		VRepairperson = vRepairperson;
	}
	public String getVContent() {
		return VContent;
	}
	public void setVContent(String vContent) {
		VContent = vContent;
	}
	public String getVRepairresult() {
		return VRepairresult;
	}
	public void setVRepairresult(String vRepairresult) {
		VRepairresult = vRepairresult;
	}
	public String getDStarttime() {
		return DStarttime;
	}
	public void setDStarttime(String dStarttime) {
		DStarttime = dStarttime;
	}
	public String getDEndtime() {
		return DEndtime;
	}
	public void setDEndtime(String dEndtime) {
		DEndtime = dEndtime;
	}
	
	
}
