package com.cauc.training.vo;

import java.util.Date;

/**
 * 用于封装TFunction，在TFunction的基础上添加了一个属性rolec，用于表示该TFunction对象是否与当前待绑定的角色有关联
 * 其他属性均用于封装TFunction的相关属性值
 * */

public class VRoleFunction implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2623394926112719721L;
	private String VId;
	private String VName;
	private String VParentid;
	private Integer IOrder;
	private String VUrl;
	private Date DCreateDate;
	private String rolec;
	private Integer isWrite;
	public VRoleFunction(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getRolec() {
		return rolec;
	}
	public void setRolec(String rolec) {
		this.rolec = rolec;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVParentid() {
		return VParentid;
	}
	public void setVParentid(String vParentid) {
		VParentid = vParentid;
	}
	public Integer getIOrder() {
		return IOrder;
	}
	public void setIOrder(Integer iOrder) {
		IOrder = iOrder;
	}
	public String getVUrl() {
		return VUrl;
	}
	public void setVUrl(String vUrl) {
		VUrl = vUrl;
	}
	public Date getDCreateDate() {
		return DCreateDate;
	}
	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}
	public Integer getIsWrite() {
		return isWrite;
	}
	public void setIsWrite(Integer isWrite) {
		this.isWrite = isWrite;
	}
	
	
}
