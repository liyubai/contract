package com.cauc.training.vo;

import java.util.Date;
import java.util.List;

import com.cauc.training.pojos.THistoryscore;

public class VScore implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6935020225772441399L;

	private String VId;
	private String lessonid;
	private double DScore;
	private Date DExamTime;
	private String viewTime;
	private Integer ITimes;
	private Integer IPass;
	private Integer IAudit;
	private String lessonName;
	private String classid;
	private String className;
	private List<THistoryscore> historyList;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getLessonid() {
		return lessonid;
	}
	public void setLessonid(String lessonid) {
		this.lessonid = lessonid;
	}
	public double getDScore() {
		return DScore;
	}
	public void setDScore(double dScore) {
		DScore = dScore;
	}
	public Date getDExamTime() {
		return DExamTime;
	}
	public void setDExamTime(Date dExamTime) {
		DExamTime = dExamTime;
	}
	public Integer getITimes() {
		return ITimes;
	}
	public void setITimes(Integer iTimes) {
		ITimes = iTimes;
	}
	public Integer getIPass() {
		return IPass;
	}
	public void setIPass(Integer iPass) {
		IPass = iPass;
	}
	public Integer getIAudit() {
		return IAudit;
	}
	public void setIAudit(Integer iAudit) {
		IAudit = iAudit;
	}
	public List<THistoryscore> getHistoryList() {
		return historyList;
	}
	public void setHistoryList(List<THistoryscore> historyList) {
		this.historyList = historyList;
	}
	public String getLessonName() {
		return lessonName;
	}
	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}
	public String getViewTime() {
		return viewTime;
	}
	public void setViewTime(String viewTime) {
		this.viewTime = viewTime;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	
}
