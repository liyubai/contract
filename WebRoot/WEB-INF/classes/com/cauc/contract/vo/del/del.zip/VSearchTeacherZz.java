package com.cauc.training.vo;

import java.util.Date;

public class VSearchTeacherZz implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -267066035508429038L;
	private String VId;
	private String VName;
	private String deptName;
	private String VCardid;//执照号
	private Date DEffectdate;//有效期
	private Date DEffectdate1;//有效期
	private String VIssuer;//局长授权签发
	private String VCompany;//签发单位
	private Date DIssuetime;//签发时间
	private Date DIssuetime1;//签发时间
	private Date DUpdatedate;//更新日期
	private Date DUpdatedate1;//更新日期
	private String VDengji;//教员执照等级
	private String VJyzzlx;//教员执照类型
	private String VZzlx;//执照类型
	private String VXingzhi;//执照性质
	private String VYbdj;//仪表等级
	private String VFjjbdj;//飞机级别等级
	private String VHkqlb;//航空器类别
	private Date DLastchecktime;//上次熟练检查时间
	private Date DLastchecktime1;//上次熟练检查时间
	private Date DChecktime;//定期检查时间
	private Date DChecktime1;//定期检查时间
	private Date DExamtime;//实践考试时间
	private Date DExamtime1;//实践考试时间
	private Date DNextchecktime;//下一次熟练检查时间
	private Date DNextchecktime1;//下一次熟练检查时间
	private String VHkqdj;//航空器型别等级
	private String VXyjdj;//旋翼机级别等级
	private String VYszzdj;//运输航空公司飞行教员执照等级
	private Integer IHgz;//合格证
	private Integer IJiankong;//监控
	
	private VSearchTeacherZz(){}
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getVCardid() {
		return VCardid;
	}
	public void setVCardid(String vCardid) {
		VCardid = vCardid;
	}
	public Date getDEffectdate() {
		return DEffectdate;
	}
	public void setDEffectdate(Date dEffectdate) {
		DEffectdate = dEffectdate;
	}
	public Date getDEffectdate1() {
		return DEffectdate1;
	}
	public void setDEffectdate1(Date dEffectdate1) {
		DEffectdate1 = dEffectdate1;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}
	public String getVCompany() {
		return VCompany;
	}
	public void setVCompany(String vCompany) {
		VCompany = vCompany;
	}
	public Date getDIssuetime() {
		return DIssuetime;
	}
	public void setDIssuetime(Date dIssuetime) {
		DIssuetime = dIssuetime;
	}
	public Date getDIssuetime1() {
		return DIssuetime1;
	}
	public void setDIssuetime1(Date dIssuetime1) {
		DIssuetime1 = dIssuetime1;
	}
	public Date getDUpdatedate() {
		return DUpdatedate;
	}
	public void setDUpdatedate(Date dUpdatedate) {
		DUpdatedate = dUpdatedate;
	}
	public Date getDUpdatedate1() {
		return DUpdatedate1;
	}
	public void setDUpdatedate1(Date dUpdatedate1) {
		DUpdatedate1 = dUpdatedate1;
	}
	public String getVDengji() {
		return VDengji;
	}
	public void setVDengji(String vDengji) {
		VDengji = vDengji;
	}
	public String getVJyzzlx() {
		return VJyzzlx;
	}
	public void setVJyzzlx(String vJyzzlx) {
		VJyzzlx = vJyzzlx;
	}
	public String getVZzlx() {
		return VZzlx;
	}
	public void setVZzlx(String vZzlx) {
		VZzlx = vZzlx;
	}
	public String getVXingzhi() {
		return VXingzhi;
	}
	public void setVXingzhi(String vXingzhi) {
		VXingzhi = vXingzhi;
	}
	public String getVYbdj() {
		return VYbdj;
	}
	public void setVYbdj(String vYbdj) {
		VYbdj = vYbdj;
	}
	public String getVFjjbdj() {
		return VFjjbdj;
	}
	public void setVFjjbdj(String vFjjbdj) {
		VFjjbdj = vFjjbdj;
	}
	public String getVHkqlb() {
		return VHkqlb;
	}
	public void setVHkqlb(String vHkqlb) {
		VHkqlb = vHkqlb;
	}
	public Date getDLastchecktime() {
		return DLastchecktime;
	}
	public void setDLastchecktime(Date dLastchecktime) {
		DLastchecktime = dLastchecktime;
	}
	public Date getDLastchecktime1() {
		return DLastchecktime1;
	}
	public void setDLastchecktime1(Date dLastchecktime1) {
		DLastchecktime1 = dLastchecktime1;
	}
	public Date getDChecktime() {
		return DChecktime;
	}
	public void setDChecktime(Date dChecktime) {
		DChecktime = dChecktime;
	}
	public Date getDChecktime1() {
		return DChecktime1;
	}
	public void setDChecktime1(Date dChecktime1) {
		DChecktime1 = dChecktime1;
	}
	public Date getDExamtime() {
		return DExamtime;
	}
	public void setDExamtime(Date dExamtime) {
		DExamtime = dExamtime;
	}
	public Date getDExamtime1() {
		return DExamtime1;
	}
	public void setDExamtime1(Date dExamtime1) {
		DExamtime1 = dExamtime1;
	}
	public Date getDNextchecktime() {
		return DNextchecktime;
	}
	public void setDNextchecktime(Date dNextchecktime) {
		DNextchecktime = dNextchecktime;
	}
	public Date getDNextchecktime1() {
		return DNextchecktime1;
	}
	public void setDNextchecktime1(Date dNextchecktime1) {
		DNextchecktime1 = dNextchecktime1;
	}
	public String getVHkqdj() {
		return VHkqdj;
	}
	public void setVHkqdj(String vHkqdj) {
		VHkqdj = vHkqdj;
	}
	public String getVXyjdj() {
		return VXyjdj;
	}
	public void setVXyjdj(String vXyjdj) {
		VXyjdj = vXyjdj;
	}
	public String getVYszzdj() {
		return VYszzdj;
	}
	public void setVYszzdj(String vYszzdj) {
		VYszzdj = vYszzdj;
	}
	public Integer getIHgz() {
		return IHgz;
	}
	public void setIHgz(Integer iHgz) {
		IHgz = iHgz;
	}
	public Integer getIJiankong() {
		return IJiankong;
	}
	public void setIJiankong(Integer iJiankong) {
		IJiankong = iJiankong;
	}
}
