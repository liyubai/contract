package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.TPointLine;
import com.cauc.training.pojos.TSetClass;

public class VSetClass  implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2625022119111975614L;
	
	private TSetClass setClass;
	
	private List<TPointLine> list;

	public TSetClass getSetClass() {
		return setClass;
	}

	public void setSetClass(TSetClass setClass) {
		this.setClass = setClass;
	}

	public List<TPointLine> getList() {
		return list;
	}

	public void setList(List<TPointLine> list) {
		this.list = list;
	}
	
	
	

}
