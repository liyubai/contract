package com.cauc.training.vo;


public class VSetClassContent implements java.io.Serializable {
	
	private static final long serialVersionUID = -2930760878243559440L;
	
	private String VId;
	private String VName;
	private String DCreateClassTime;
	private String DBeginLessionTime;
	private String DEndLessionTime;
	private Integer IModel;
	private String userid;
	
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getDCreateClassTime() {
		return DCreateClassTime;
	}
	public void setDCreateClassTime(String dCreateClassTime) {
		DCreateClassTime = dCreateClassTime;
	}
	public String getDBeginLessionTime() {
		return DBeginLessionTime;
	}
	public void setDBeginLessionTime(String dBeginLessionTime) {
		DBeginLessionTime = dBeginLessionTime;
	}
	public String getDEndLessionTime() {
		return DEndLessionTime;
	}
	public void setDEndLessionTime(String dEndLessionTime) {
		DEndLessionTime = dEndLessionTime;
	}
	public Integer getIModel() {
		return IModel;
	}
	public void setIModel(Integer iModel) {
		IModel = iModel;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	
	
}
