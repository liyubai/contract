package com.cauc.training.vo;

import java.util.Date;

public class VStation implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4844035072047534103L;
	private String VId;
	private String VName;
	private String VNo;
	private String VLicenseform;
	private String VConditions;
	private String VPassstandard;
	private Date DCreateDate;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public Date getDCreateDate() {
		return DCreateDate;
	}
	public void setDCreateDate(Date dCreateDate) {
		DCreateDate = dCreateDate;
	}
	public String getVNo() {
		return VNo;
	}
	public void setVNo(String vNo) {
		VNo = vNo;
	}
	public String getVLicenseform() {
		return VLicenseform;
	}
	public void setVLicenseform(String vLicenseform) {
		VLicenseform = vLicenseform;
	}
	public String getVConditions() {
		return VConditions;
	}
	public void setVConditions(String vConditions) {
		VConditions = vConditions;
	}
	public String getVPassstandard() {
		return VPassstandard;
	}
	public void setVPassstandard(String vPassstandard) {
		VPassstandard = vPassstandard;
	}
	
	
}
