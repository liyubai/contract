package com.cauc.training.vo;

public class VStatisticsByDay implements java.io.Serializable {

	/**
	 * 运行简报数据统计，是图层对象
	 */
	private static final long serialVersionUID = 7906826114846714782L;

	private String flyDate;
	private String c90;
	private String da42;
	private String da40;
	private String da20;
	private String ftd42;
	private String ftd40;
	
	private String flyNumber;
	private String flyTime;
	private String mnjTime;
	
	private String c90Time;
	private String da42Time;
	private String da40Time;
	private String da20Time;
	
	private String zcNumber;
	private String zcdfNumber;
	
	private Integer flag;
	public String getFlyDate() {
		return flyDate;
	}
	public void setFlyDate(String flyDate) {
		this.flyDate = flyDate;
	}
	public String getC90() {
		return c90;
	}
	public void setC90(String c90) {
		this.c90 = c90;
	}
	public String getDa42() {
		return da42;
	}
	public void setDa42(String da42) {
		this.da42 = da42;
	}
	public String getDa40() {
		return da40;
	}
	public void setDa40(String da40) {
		this.da40 = da40;
	}
	public String getDa20() {
		return da20;
	}
	public void setDa20(String da20) {
		this.da20 = da20;
	}
	public String getFtd42() {
		return ftd42;
	}
	public void setFtd42(String ftd42) {
		this.ftd42 = ftd42;
	}
	public String getFtd40() {
		return ftd40;
	}
	public void setFtd40(String ftd40) {
		this.ftd40 = ftd40;
	}
	public String getFlyNumber() {
		return flyNumber;
	}
	public void setFlyNumber(String flyNumber) {
		this.flyNumber = flyNumber;
	}
	public String getFlyTime() {
		return flyTime;
	}
	public void setFlyTime(String flyTime) {
		this.flyTime = flyTime;
	}
	public String getMnjTime() {
		return mnjTime;
	}
	public void setMnjTime(String mnjTime) {
		this.mnjTime = mnjTime;
	}
	public String getC90Time() {
		return c90Time;
	}
	public void setC90Time(String c90Time) {
		this.c90Time = c90Time;
	}
	public String getDa42Time() {
		return da42Time;
	}
	public void setDa42Time(String da42Time) {
		this.da42Time = da42Time;
	}
	public String getDa40Time() {
		return da40Time;
	}
	public void setDa40Time(String da40Time) {
		this.da40Time = da40Time;
	}
	public String getDa20Time() {
		return da20Time;
	}
	public void setDa20Time(String da20Time) {
		this.da20Time = da20Time;
	}
	public String getZcNumber() {
		return zcNumber;
	}
	public void setZcNumber(String zcNumber) {
		this.zcNumber = zcNumber;
	}
	public String getZcdfNumber() {
		return zcdfNumber;
	}
	public void setZcdfNumber(String zcdfNumber) {
		this.zcdfNumber = zcdfNumber;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	
	
}
