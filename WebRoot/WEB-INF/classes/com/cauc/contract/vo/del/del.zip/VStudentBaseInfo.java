package com.cauc.training.vo;

import java.util.Date;
import java.util.List;


public class VStudentBaseInfo implements java.io.Serializable {

	private static final long serialVersionUID = -7482629940830774879L;
	
	private String VId;//学员id
	private String VCode;
	private String VName;
	private String VGender;
	
	private String stuTypeName;
	private String companyName;
	private String stuStatusName;
	private String xjStatusName;
	private String formName;
	private String freeTypeName;
	private String bj; //班级
	private Date rxsj;  //入学时间,局方考试时间
	private String lxfs;//联系方式
	private String zzmm;//政治面貌
	private String whcd;//文化程度
	private String nation;//民族
	private String jg; //籍贯
	private String enLevel;//英语水平
	private String byyx;//毕业院校
	private String zy; //专业
	private String syd;//生源地
	private String jtzz;//家庭住址
	private String xlxz;//学历性质
	private String xxlx;//学习类型
	private String rxny;
	private String lxny;
	
	
	private String outlineid;//大纲id
	private String outlineName;//大纲名称
	private String dvid;//大纲分配表id
	
	private String VCardid;
	private String VClassNoid;
	private Date DBirthday;
	private String VSyd;
	private String createTime;
	private String userid;
	private Integer iday;
	
	private int avgScore;
	private int ltime;
	private int enScore;
	
	List<VStudentDistributionClass> stuClassList;
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVGender() {
		return VGender;
	}
	public void setVGender(String vGender) {
		VGender = vGender;
	}
	public String getStuTypeName() {
		return stuTypeName;
	}
	public void setStuTypeName(String stuTypeName) {
		this.stuTypeName = stuTypeName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStuStatusName() {
		return stuStatusName;
	}
	public void setStuStatusName(String stuStatusName) {
		this.stuStatusName = stuStatusName;
	}
	public String getXjStatusName() {
		return xjStatusName;
	}
	public void setXjStatusName(String xjStatusName) {
		this.xjStatusName = xjStatusName;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFreeTypeName() {
		return freeTypeName;
	}
	public void setFreeTypeName(String freeTypeName) {
		this.freeTypeName = freeTypeName;
	}
	public String getOutlineid() {
		return outlineid;
	}
	public void setOutlineid(String outlineid) {
		this.outlineid = outlineid;
	}
	public String getOutlineName() {
		return outlineName;
	}
	public void setOutlineName(String outlineName) {
		this.outlineName = outlineName;
	}
	public String getDvid() {
		return dvid;
	}
	public void setDvid(String dvid) {
		this.dvid = dvid;
	}
	public String getVCardid() {
		return VCardid;
	}
	public void setVCardid(String vCardid) {
		VCardid = vCardid;
	}
	public String getVClassNoid() {
		return VClassNoid;
	}
	public void setVClassNoid(String vClassNoid) {
		VClassNoid = vClassNoid;
	}
	public Date getDBirthday() {
		return DBirthday;
	}
	public void setDBirthday(Date dBirthday) {
		DBirthday = dBirthday;
	}
	public String getVSyd() {
		return VSyd;
	}
	public void setVSyd(String vSyd) {
		VSyd = vSyd;
	}

	public String getBj() {
		return bj;
	}
	public void setBj(String bj) {
		this.bj = bj;
	}
	public Date getRxsj() {
		return rxsj;
	}
	public void setRxsj(Date rxsj) {
		this.rxsj = rxsj;
	}
	public String getLxfs() {
		return lxfs;
	}
	public void setLxfs(String lxfs) {
		this.lxfs = lxfs;
	}
	public String getZzmm() {
		return zzmm;
	}
	public void setZzmm(String zzmm) {
		this.zzmm = zzmm;
	}
	public String getWhcd() {
		return whcd;
	}
	public void setWhcd(String whcd) {
		this.whcd = whcd;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getJg() {
		return jg;
	}
	public void setJg(String jg) {
		this.jg = jg;
	}
	public String getEnLevel() {
		return enLevel;
	}
	public void setEnLevel(String enLevel) {
		this.enLevel = enLevel;
	}
	public String getByyx() {
		return byyx;
	}
	public void setByyx(String byyx) {
		this.byyx = byyx;
	}
	public String getZy() {
		return zy;
	}
	public void setZy(String zy) {
		this.zy = zy;
	}
	public String getSyd() {
		return syd;
	}
	public void setSyd(String syd) {
		this.syd = syd;
	}
	public String getJtzz() {
		return jtzz;
	}
	public void setJtzz(String jtzz) {
		this.jtzz = jtzz;
	}
	public String getXlxz() {
		return xlxz;
	}
	public void setXlxz(String xlxz) {
		this.xlxz = xlxz;
	}
	public String getXxlx() {
		return xxlx;
	}
	public void setXxlx(String xxlx) {
		this.xxlx = xxlx;
	}

	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public Integer getIday() {
		return iday;
	}
	public void setIday(Integer iday) {
		this.iday = iday;
	}
	public String getRxny() {
		return rxny;
	}
	public void setRxny(String rxny) {
		this.rxny = rxny;
	}
	public String getLxny() {
		return lxny;
	}
	public void setLxny(String lxny) {
		this.lxny = lxny;
	}
	public List<VStudentDistributionClass> getStuClassList() {
		return stuClassList;
	}
	public void setStuClassList(List<VStudentDistributionClass> stuClassList) {
		this.stuClassList = stuClassList;
	}
	public int getAvgScore() {
		return avgScore;
	}
	public void setAvgScore(int avgScore) {
		this.avgScore = avgScore;
	}
	public int getLtime() {
		return ltime;
	}
	public void setLtime(int ltime) {
		this.ltime = ltime;
	}
	public int getEnScore() {
		return enScore;
	}
	public void setEnScore(int enScore) {
		this.enScore = enScore;
	}




}
