package com.cauc.training.vo;


public class VStudentDistributionClass implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6715406309158233851L;
	
	private String VId;
	private String classid;
	private String className;
	private String DAssigntime;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDAssigntime() {
		return DAssigntime;
	}
	public void setDAssigntime(String dAssigntime) {
		DAssigntime = dAssigntime;
	}

	
}
