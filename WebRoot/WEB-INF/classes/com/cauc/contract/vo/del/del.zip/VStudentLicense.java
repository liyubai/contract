package com.cauc.training.vo;

import java.util.List;


public class VStudentLicense implements java.io.Serializable {


	private static final long serialVersionUID = -559549513205176450L;
	private String VId;
	private String TuserId;
	private String StudentId;
	private String VCode;
	private String VName;
	private String VCardid;
	private String VGender;
	private String year;
	private String DEffectdate;
	private String VIssuer;
	private String VCompany;
	private String DIssuetime;
	private String DUpdatedate;
	private String VZhizhaoxingzhi;
	private String VZhizhaodengji;
	private String VHangkongqileibie;
	private String VXuanzhuanjijibie;
	private String VFeijijibie;
	private String VHkqdj;
	private String VBeizhu;
	private String DLastchecktime;
	private String DChecktime;
	private String DExamtime;
	private String DNextchecktime;
	private String DCreatedate;
	private String YiBiaoLevel;
	private String ILevel;
	private String DResultdate;
	private String DIssueTime;
	private String DUsedTime;
	private String VDoctor;
	private int iday;
	private int used;//区分在用与历史
	private Integer IExam;
	private List<VOTTeaLicenseskilledcheck> checkList;
	public String getVId() {
		return VId;
	}
	public void setVId(String id) {
		VId = id;
	}
	public String getTuserId() {
		return TuserId;
	}
	public void setTuserId(String tuserId) {
		TuserId = tuserId;
	}
	public String getStudentId() {
		return StudentId;
	}
	public void setStudentId(String studentId) {
		StudentId = studentId;
	}

	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVCardid() {
		return VCardid;
	}
	public void setVCardid(String cardid) {
		VCardid = cardid;
	}
	public String getDEffectdate() {
		return DEffectdate;
	}
	public void setDEffectdate(String effectdate) {
		DEffectdate = effectdate;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String issuer) {
		VIssuer = issuer;
	}
	public String getVCompany() {
		return VCompany;
	}
	public void setVCompany(String company) {
		VCompany = company;
	}
	public String getDIssuetime() {
		return DIssuetime;
	}
	public void setDIssuetime(String issuetime) {
		DIssuetime = issuetime;
	}
	public String getDUpdatedate() {
		return DUpdatedate;
	}
	public void setDUpdatedate(String updatedate) {
		DUpdatedate = updatedate;
	}
	public String getVZhizhaoxingzhi() {
		return VZhizhaoxingzhi;
	}
	public void setVZhizhaoxingzhi(String zhizhaoxingzhi) {
		VZhizhaoxingzhi = zhizhaoxingzhi;
	}
	public String getVZhizhaodengji() {
		return VZhizhaodengji;
	}
	public void setVZhizhaodengji(String zhizhaodengji) {
		VZhizhaodengji = zhizhaodengji;
	}
	public String getVHangkongqileibie() {
		return VHangkongqileibie;
	}
	public void setVHangkongqileibie(String hangkongqileibie) {
		VHangkongqileibie = hangkongqileibie;
	}
	public String getVXuanzhuanjijibie() {
		return VXuanzhuanjijibie;
	}
	public void setVXuanzhuanjijibie(String xuanzhuanjijibie) {
		VXuanzhuanjijibie = xuanzhuanjijibie;
	}
	public String getVFeijijibie() {
		return VFeijijibie;
	}
	public void setVFeijijibie(String feijijibie) {
		VFeijijibie = feijijibie;
	}
	public String getVHkqdj() {
		return VHkqdj;
	}
	public void setVHkqdj(String hkqdj) {
		VHkqdj = hkqdj;
	}
	public String getVBeizhu() {
		return VBeizhu;
	}
	public void setVBeizhu(String beizhu) {
		VBeizhu = beizhu;
	}
	public String getDLastchecktime() {
		return DLastchecktime;
	}
	public void setDLastchecktime(String lastchecktime) {
		DLastchecktime = lastchecktime;
	}
	public String getDChecktime() {
		return DChecktime;
	}
	public void setDChecktime(String checktime) {
		DChecktime = checktime;
	}
	public String getDExamtime() {
		return DExamtime;
	}
	public void setDExamtime(String examtime) {
		DExamtime = examtime;
	}
	public String getDNextchecktime() {
		return DNextchecktime;
	}
	public void setDNextchecktime(String nextchecktime) {
		DNextchecktime = nextchecktime;
	}
	public String getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(String createdate) {
		DCreatedate = createdate;
	}
	public String getYiBiaoLevel() {
		return YiBiaoLevel;
	}
	public void setYiBiaoLevel(String yiBiaoLevel) {
		YiBiaoLevel = yiBiaoLevel;
	}
	public String getILevel() {
		return ILevel;
	}
	public void setILevel(String iLevel) {
		ILevel = iLevel;
	}
	public String getDResultdate() {
		return DResultdate;
	}
	public void setDResultdate(String dResultdate) {
		DResultdate = dResultdate;
	}
	public String getDIssueTime() {
		return DIssueTime;
	}
	public void setDIssueTime(String dIssueTime) {
		DIssueTime = dIssueTime;
	}
	public String getDUsedTime() {
		return DUsedTime;
	}
	public void setDUsedTime(String dUsedTime) {
		DUsedTime = dUsedTime;
	}
	public String getVDoctor() {
		return VDoctor;
	}
	public void setVDoctor(String vDoctor) {
		VDoctor = vDoctor;
	}
	public int getIday() {
		return iday;
	}
	public void setIday(int iday) {
		this.iday = iday;
	}
	public int getUsed() {
		return used;
	}
	public void setUsed(int used) {
		this.used = used;
	}
	public List<VOTTeaLicenseskilledcheck> getCheckList() {
		return checkList;
	}
	public void setCheckList(List<VOTTeaLicenseskilledcheck> checkList) {
		this.checkList = checkList;
	}
	public Integer getIExam() {
		return IExam;
	}
	public void setIExam(Integer iExam) {
		IExam = iExam;
	}
	public String getVGender() {
		return VGender;
	}
	public void setVGender(String vGender) {
		VGender = vGender;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
}
