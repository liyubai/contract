package com.cauc.training.vo;

import java.util.Date;

import com.cauc.training.pojos.TTeaLicense;
import com.cauc.training.pojos.TUser;
import com.cauc.training.pojos.TeacherLicenseupdate;

/**
 * TTeaLicenseskilledcheck entity. @author MyEclipse Persistence Tools
 */

public class VTTeaLicenseskilledcheck implements java.io.Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1300272925514472237L;
	private String VId;
	private TeacherLicenseupdate teacherLicenseupdate;//执照升级标识	
	private TTeaLicense TTeaLicense;//执照标识
	private TUser TUser;
	private Date DCheckdate;//检查日期
	private String VCheckcontent;//检查内容
	private String VCheckteacher;//检查教员
	private String VBz;//备注
	private Date DEffectdate;//有效期
	private String VFlyform;//航空器型别
	private String IChecktype;//检查类型
	private Date DCreatedate;

	// Constructors

	/** default constructor */
	public VTTeaLicenseskilledcheck() {
	}

	/** minimal constructor */
	public VTTeaLicenseskilledcheck(TUser TUser, Date DCreatedate) {
		this.TUser = TUser;
		this.DCreatedate = DCreatedate;
	}


	public String getVId() {
		return this.VId;
	}

	public void setVId(String VId) {
		this.VId = VId;
	}

	public TeacherLicenseupdate getTeacherLicenseupdate() {
		return this.teacherLicenseupdate;
	}

	public void setTeacherLicenseupdate(
			TeacherLicenseupdate teacherLicenseupdate) {
		this.teacherLicenseupdate = teacherLicenseupdate;
	}

	public TTeaLicense getTTeaLicense() {
		return this.TTeaLicense;
	}

	public void setTTeaLicense(TTeaLicense TTeaLicense) {
		this.TTeaLicense = TTeaLicense;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Date getDCheckdate() {
		return this.DCheckdate;
	}

	public void setDCheckdate(Date DCheckdate) {
		this.DCheckdate = DCheckdate;
	}

	public String getVCheckcontent() {
		return this.VCheckcontent;
	}

	public void setVCheckcontent(String VCheckcontent) {
		this.VCheckcontent = VCheckcontent;
	}

	public String getVCheckteacher() {
		return this.VCheckteacher;
	}

	public void setVCheckteacher(String VCheckteacher) {
		this.VCheckteacher = VCheckteacher;
	}

	public String getVBz() {
		return this.VBz;
	}

	public void setVBz(String VBz) {
		this.VBz = VBz;
	}

	public Date getDEffectdate() {
		return this.DEffectdate;
	}

	public void setDEffectdate(Date DEffectdate) {
		this.DEffectdate = DEffectdate;
	}

	public String getVFlyform() {
		return this.VFlyform;
	}

	public void setVFlyform(String VFlyform) {
		this.VFlyform = VFlyform;
	}

	public String getIChecktype() {
		return IChecktype;
	}

	public void setIChecktype(String iChecktype) {
		IChecktype = iChecktype;
	}

	public Date getDCreatedate() {
		return this.DCreatedate;
	}

	public void setDCreatedate(Date DCreatedate) {
		this.DCreatedate = DCreatedate;
	}

}