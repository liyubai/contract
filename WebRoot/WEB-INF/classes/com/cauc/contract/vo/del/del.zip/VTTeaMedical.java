package com.cauc.training.vo;

import java.util.Date;

public class VTTeaMedical implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1174592562253790657L;
	private String VId;
	private String TUser;
	private String teacherBaseInfo;
	private String ILevel;
	private String VNation;
	private String VLimit;
	private String DResultdate;
	private String VDoctor;
	private String VIssuer;
	private String DIssueTime;
	private String DUsedTime;
	private String VCompany;
	private Date DCreatedate;
	private String teacherCode;
	private String deptName;


	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getTUser() {
		return TUser;
	}
	public void setTUser(String tUser) {
		TUser = tUser;
	}
	public String getTeacherBaseInfo() {
		return teacherBaseInfo;
	}
	public void setTeacherBaseInfo(String teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}

	public String getVNation() {
		return VNation;
	}
	public void setVNation(String vNation) {
		VNation = vNation;
	}
	public String getVLimit() {
		return VLimit;
	}
	public void setVLimit(String vLimit) {
		VLimit = vLimit;
	}

	public String getVDoctor() {
		return VDoctor;
	}
	public void setVDoctor(String vDoctor) {
		VDoctor = vDoctor;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}

	public String getVCompany() {
		return VCompany;
	}
	public void setVCompany(String vCompany) {
		VCompany = vCompany;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getTeacherCode() {
		return teacherCode;
	}
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getILevel() {
		return ILevel;
	}
	public void setILevel(String iLevel) {
		ILevel = iLevel;
	}
	public String getDResultdate() {
		return DResultdate;
	}
	public void setDResultdate(String dResultdate) {
		DResultdate = dResultdate;
	}
	public String getDIssueTime() {
		return DIssueTime;
	}
	public void setDIssueTime(String dIssueTime) {
		DIssueTime = dIssueTime;
	}
	public String getDUsedTime() {
		return DUsedTime;
	}
	public void setDUsedTime(String dUsedTime) {
		DUsedTime = dUsedTime;
	}
	
}
