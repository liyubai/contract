package com.cauc.training.vo;

import java.util.Date;

public class VTTeaMedicalhistory implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7089408946136947521L;
	private String VId;
	private String TTeaMedical;
	private String TUser;
	private String teacherBaseInfo;
	private Integer ILevel;
	private String VNation;
	private String VLimit;
	private Date DResultdate;
	private String VDoctor;
	private String VIssuer;
	private Date DIssueTime;
	private Date DUsedTime;
	private String VCompany;
	private Date DCreatedate;
	private String teacherCode;
	private String deptName;
	public VTTeaMedicalhistory(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getTTeaMedical() {
		return TTeaMedical;
	}
	public void setTTeaMedical(String tTeaMedical) {
		TTeaMedical = tTeaMedical;
	}
	public String getTUser() {
		return TUser;
	}
	public void setTUser(String tUser) {
		TUser = tUser;
	}
	public String getTeacherBaseInfo() {
		return teacherBaseInfo;
	}
	public void setTeacherBaseInfo(String teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}
	public Integer getILevel() {
		return ILevel;
	}
	public void setILevel(Integer iLevel) {
		ILevel = iLevel;
	}
	public String getVNation() {
		return VNation;
	}
	public void setVNation(String vNation) {
		VNation = vNation;
	}
	public String getVLimit() {
		return VLimit;
	}
	public void setVLimit(String vLimit) {
		VLimit = vLimit;
	}
	public Date getDResultdate() {
		return DResultdate;
	}
	public void setDResultdate(Date dResultdate) {
		DResultdate = dResultdate;
	}
	public String getVDoctor() {
		return VDoctor;
	}
	public void setVDoctor(String vDoctor) {
		VDoctor = vDoctor;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}
	public Date getDIssueTime() {
		return DIssueTime;
	}
	public void setDIssueTime(Date dIssueTime) {
		DIssueTime = dIssueTime;
	}
	public Date getDUsedTime() {
		return DUsedTime;
	}
	public void setDUsedTime(Date dUsedTime) {
		DUsedTime = dUsedTime;
	}
	public String getVCompany() {
		return VCompany;
	}
	public void setVCompany(String vCompany) {
		VCompany = vCompany;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getTeacherCode() {
		return teacherCode;
	}
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}
