package com.cauc.training.vo;

import java.util.Date;
import java.util.List;

public class VTeacherBaseInfo implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8727887351796656126L;
	private String VId;//主键
	private String TDictionByVFlyform;//所飞机型
	private String TDictionByVGeneraltype;//地面教员类型
	private String TDictionByVFlytype;//飞行教员类型
	private String TDictionByVWhcd;//文化程度
	private String TDictionByVMz;//民族
	private String TUser;//创建人
	private String TOrg;//所属飞行大队
	private String TDictionByVTecdengji;//所聘技术等级
	private String VName;//教员名称
	private String VCode;//教员编号
	private Integer IExam;//是否为考试员
	private String VSafedengji;//安全等级
	private Date DRxrq;//入校日期
	private String vrxrq;
	private String VSfz;//身份证
	private String VXb;//性别
	private Date DCsrq;//出生日期
	private String vcsrq;
	private String VZzmm;//政治面貌
	private String VLxfs;//联系方式
	private String VJg;//籍贯
	private String VJtzz;//家庭住址
	private Date DCreatedate;//创建时间
	private String VByyx;//毕业院校
	private String VZw;//职位
	private String VYysp;//英语水平
	private Date DMhyytgsj;//民航英语通过时间
	private String vmhyytgsj;
	private Date DCjgzsj;//参加工作时间
	private String vcjgzsj;
	private String VSzdw;//所在单位
	private String VSzdwzw;//所在单位职务
	private String deptName;//所在大队名称
	private String baseName;//所在基地
	private String jdt;//用于显示进度条
	private String jdt1;//用于显示进度条
	private String jdt2;//用于显示进度条
	private Date tjfzrq;//体检发证日期
	private String vtjfzrq;
	private Date tjyxrq;//体检有效日期
	private String vtjyxrq;
	private Date dqsj;//当前时间
	private String ILevel;
	private String DResultdate;
	private String DIssueTime;
	private String DUsedTime;
	private String VDoctor;
	private String VIssuer;
	private int iday;
	private int used;//区分在用与历史
	private List<VOTTeaLicenseskilledcheck> checkList;
	
	public VTeacherBaseInfo(){}
	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getTDictionByVFlyform() {
		return TDictionByVFlyform;
	}
	public void setTDictionByVFlyform(String tDictionByVFlyform) {
		TDictionByVFlyform = tDictionByVFlyform;
	}
	public String getTDictionByVGeneraltype() {
		return TDictionByVGeneraltype;
	}
	public void setTDictionByVGeneraltype(String tDictionByVGeneraltype) {
		TDictionByVGeneraltype = tDictionByVGeneraltype;
	}
	public String getTDictionByVFlytype() {
		return TDictionByVFlytype;
	}
	public void setTDictionByVFlytype(String tDictionByVFlytype) {
		TDictionByVFlytype = tDictionByVFlytype;
	}
	public String getTDictionByVWhcd() {
		return TDictionByVWhcd;
	}
	public void setTDictionByVWhcd(String tDictionByVWhcd) {
		TDictionByVWhcd = tDictionByVWhcd;
	}
	public String getTDictionByVMz() {
		return TDictionByVMz;
	}
	public void setTDictionByVMz(String tDictionByVMz) {
		TDictionByVMz = tDictionByVMz;
	}
	public String getTUser() {
		return TUser;
	}
	public void setTUser(String tUser) {
		TUser = tUser;
	}
	public String getTOrg() {
		return TOrg;
	}
	public void setTOrg(String tOrg) {
		TOrg = tOrg;
	}
	public String getTDictionByVTecdengji() {
		return TDictionByVTecdengji;
	}
	public void setTDictionByVTecdengji(String tDictionByVTecdengji) {
		TDictionByVTecdengji = tDictionByVTecdengji;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public Integer getIExam() {
		return IExam;
	}
	public void setIExam(Integer iExam) {
		IExam = iExam;
	}
	public String getVSafedengji() {
		return VSafedengji;
	}
	public void setVSafedengji(String vSafedengji) {
		VSafedengji = vSafedengji;
	}
	public Date getDRxrq() {
		return DRxrq;
	}
	public void setDRxrq(Date dRxrq) {
		DRxrq = dRxrq;
	}
	public String getVSfz() {
		return VSfz;
	}
	public void setVSfz(String vSfz) {
		VSfz = vSfz;
	}
	public String getVXb() {
		return VXb;
	}
	public void setVXb(String vXb) {
		VXb = vXb;
	}
	public Date getDCsrq() {
		return DCsrq;
	}
	public void setDCsrq(Date dCsrq) {
		DCsrq = dCsrq;
	}
	public String getVZzmm() {
		return VZzmm;
	}
	public void setVZzmm(String vZzmm) {
		VZzmm = vZzmm;
	}
	public String getVLxfs() {
		return VLxfs;
	}
	public void setVLxfs(String vLxfs) {
		VLxfs = vLxfs;
	}
	public String getVJg() {
		return VJg;
	}
	public void setVJg(String vJg) {
		VJg = vJg;
	}
	public String getVJtzz() {
		return VJtzz;
	}
	public void setVJtzz(String vJtzz) {
		VJtzz = vJtzz;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getVByyx() {
		return VByyx;
	}
	public void setVByyx(String vByyx) {
		VByyx = vByyx;
	}
	public String getVZw() {
		return VZw;
	}
	public void setVZw(String vZw) {
		VZw = vZw;
	}
	public String getVYysp() {
		return VYysp;
	}
	public void setVYysp(String vYysp) {
		VYysp = vYysp;
	}
	public Date getDMhyytgsj() {
		return DMhyytgsj;
	}
	public void setDMhyytgsj(Date dMhyytgsj) {
		DMhyytgsj = dMhyytgsj;
	}
	public Date getDCjgzsj() {
		return DCjgzsj;
	}
	public void setDCjgzsj(Date dCjgzsj) {
		DCjgzsj = dCjgzsj;
	}
	public String getVSzdw() {
		return VSzdw;
	}
	public void setVSzdw(String vSzdw) {
		VSzdw = vSzdw;
	}
	public String getVSzdwzw() {
		return VSzdwzw;
	}
	public void setVSzdwzw(String vSzdwzw) {
		VSzdwzw = vSzdwzw;
	}
	public String getJdt() {
		return jdt;
	}
	public void setJdt(String jdt) {
		this.jdt = jdt;
	}
	public Date getTjfzrq() {
		return tjfzrq;
	}
	public void setTjfzrq(Date tjfzrq) {
		this.tjfzrq = tjfzrq;
	}
	public Date getTjyxrq() {
		return tjyxrq;
	}
	public void setTjyxrq(Date tjyxrq) {
		this.tjyxrq = tjyxrq;
	}
	public String getJdt1() {
		return jdt1;
	}
	public void setJdt1(String jdt1) {
		this.jdt1 = jdt1;
	}
	public String getJdt2() {
		return jdt2;
	}
	public void setJdt2(String jdt2) {
		this.jdt2 = jdt2;
	}
	public Date getDqsj() {
		return dqsj;
	}
	public void setDqsj(Date dqsj) {
		this.dqsj = dqsj;
	}

	public String getBaseName() {
		return baseName;
	}

	public void setBaseName(String baseName) {
		this.baseName = baseName;
	}

	public String getILevel() {
		return ILevel;
	}

	public void setILevel(String iLevel) {
		ILevel = iLevel;
	}

	public String getDResultdate() {
		return DResultdate;
	}

	public void setDResultdate(String dResultdate) {
		DResultdate = dResultdate;
	}

	public String getDIssueTime() {
		return DIssueTime;
	}

	public void setDIssueTime(String dIssueTime) {
		DIssueTime = dIssueTime;
	}

	public String getDUsedTime() {
		return DUsedTime;
	}

	public void setDUsedTime(String dUsedTime) {
		DUsedTime = dUsedTime;
	}

	public String getVDoctor() {
		return VDoctor;
	}

	public void setVDoctor(String vDoctor) {
		VDoctor = vDoctor;
	}

	public String getVIssuer() {
		return VIssuer;
	}

	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}

	public int getIday() {
		return iday;
	}

	public void setIday(int iday) {
		this.iday = iday;
	}

	public int getUsed() {
		return used;
	}

	public void setUsed(int used) {
		this.used = used;
	}

	public List<VOTTeaLicenseskilledcheck> getCheckList() {
		return checkList;
	}

	public void setCheckList(List<VOTTeaLicenseskilledcheck> checkList) {
		this.checkList = checkList;
	}

	public String getVrxrq() {
		return vrxrq;
	}

	public void setVrxrq(String vrxrq) {
		this.vrxrq = vrxrq;
	}

	public String getVcsrq() {
		return vcsrq;
	}

	public void setVcsrq(String vcsrq) {
		this.vcsrq = vcsrq;
	}

	public String getVmhyytgsj() {
		return vmhyytgsj;
	}

	public void setVmhyytgsj(String vmhyytgsj) {
		this.vmhyytgsj = vmhyytgsj;
	}

	public String getVcjgzsj() {
		return vcjgzsj;
	}

	public void setVcjgzsj(String vcjgzsj) {
		this.vcjgzsj = vcjgzsj;
	}

	public String getVtjfzrq() {
		return vtjfzrq;
	}

	public void setVtjfzrq(String vtjfzrq) {
		this.vtjfzrq = vtjfzrq;
	}

	public String getVtjyxrq() {
		return vtjyxrq;
	}

	public void setVtjyxrq(String vtjyxrq) {
		this.vtjyxrq = vtjyxrq;
	}


	
}
