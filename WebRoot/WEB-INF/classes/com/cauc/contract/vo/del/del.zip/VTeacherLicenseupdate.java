package com.cauc.training.vo;

import java.util.Date;

public class VTeacherLicenseupdate implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -215370832587348260L;
	private String VId;
	private String TTeaLicense;
	private String TUser;
	private String teacherBaseInfo;
	private String VCardid;
	private Date DEffectdate;
	private String VIssuer;
	private String VQfdw;
	private Date DQfsj;
	private Date DUpdatedate;
	private String VDengji;
	private String VJyzzlx;
	private String VZzlx;
	private String VXingzhi;
	private String VYbdj;
	private String VFjjbdj;
	private String VHkqlb;
	private Date DLastchecktime;
	private Date DChecktime;
	private Date DExamtime;
	private Date DNextchecktime;
	private Date DCreatedate;
	private String VHkqdj;
	private String VXyjdj;
	private String VYszzdj;
	private Integer IHgz;
	private Integer IJiankong;
	private String teacherCode;
	private String deptName;
	public VTeacherLicenseupdate(){}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getTTeaLicense() {
		return TTeaLicense;
	}
	public void setTTeaLicense(String tTeaLicense) {
		TTeaLicense = tTeaLicense;
	}
	public String getTUser() {
		return TUser;
	}
	public void setTUser(String tUser) {
		TUser = tUser;
	}
	public String getTeacherBaseInfo() {
		return teacherBaseInfo;
	}
	public void setTeacherBaseInfo(String teacherBaseInfo) {
		this.teacherBaseInfo = teacherBaseInfo;
	}
	public String getVCardid() {
		return VCardid;
	}
	public void setVCardid(String vCardid) {
		VCardid = vCardid;
	}
	public Date getDEffectdate() {
		return DEffectdate;
	}
	public void setDEffectdate(Date dEffectdate) {
		DEffectdate = dEffectdate;
	}
	public String getVIssuer() {
		return VIssuer;
	}
	public void setVIssuer(String vIssuer) {
		VIssuer = vIssuer;
	}
	public String getVQfdw() {
		return VQfdw;
	}
	public void setVQfdw(String vQfdw) {
		VQfdw = vQfdw;
	}
	public Date getDQfsj() {
		return DQfsj;
	}
	public void setDQfsj(Date dQfsj) {
		DQfsj = dQfsj;
	}
	public Date getDUpdatedate() {
		return DUpdatedate;
	}
	public void setDUpdatedate(Date dUpdatedate) {
		DUpdatedate = dUpdatedate;
	}
	public String getVDengji() {
		return VDengji;
	}
	public void setVDengji(String vDengji) {
		VDengji = vDengji;
	}
	public String getVJyzzlx() {
		return VJyzzlx;
	}
	public void setVJyzzlx(String vJyzzlx) {
		VJyzzlx = vJyzzlx;
	}
	public String getVZzlx() {
		return VZzlx;
	}
	public void setVZzlx(String vZzlx) {
		VZzlx = vZzlx;
	}
	public String getVXingzhi() {
		return VXingzhi;
	}
	public void setVXingzhi(String vXingzhi) {
		VXingzhi = vXingzhi;
	}
	public String getVYbdj() {
		return VYbdj;
	}
	public void setVYbdj(String vYbdj) {
		VYbdj = vYbdj;
	}
	public String getVFjjbdj() {
		return VFjjbdj;
	}
	public void setVFjjbdj(String vFjjbdj) {
		VFjjbdj = vFjjbdj;
	}
	public String getVHkqlb() {
		return VHkqlb;
	}
	public void setVHkqlb(String vHkqlb) {
		VHkqlb = vHkqlb;
	}
	public Date getDLastchecktime() {
		return DLastchecktime;
	}
	public void setDLastchecktime(Date dLastchecktime) {
		DLastchecktime = dLastchecktime;
	}
	public Date getDChecktime() {
		return DChecktime;
	}
	public void setDChecktime(Date dChecktime) {
		DChecktime = dChecktime;
	}
	public Date getDExamtime() {
		return DExamtime;
	}
	public void setDExamtime(Date dExamtime) {
		DExamtime = dExamtime;
	}
	public Date getDNextchecktime() {
		return DNextchecktime;
	}
	public void setDNextchecktime(Date dNextchecktime) {
		DNextchecktime = dNextchecktime;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getVHkqdj() {
		return VHkqdj;
	}
	public void setVHkqdj(String vHkqdj) {
		VHkqdj = vHkqdj;
	}
	public String getVXyjdj() {
		return VXyjdj;
	}
	public void setVXyjdj(String vXyjdj) {
		VXyjdj = vXyjdj;
	}
	public String getVYszzdj() {
		return VYszzdj;
	}
	public void setVYszzdj(String vYszzdj) {
		VYszzdj = vYszzdj;
	}
	public Integer getIHgz() {
		return IHgz;
	}
	public void setIHgz(Integer iHgz) {
		IHgz = iHgz;
	}
	public Integer getIJiankong() {
		return IJiankong;
	}
	public void setIJiankong(Integer iJiankong) {
		IJiankong = iJiankong;
	}
	public String getTeacherCode() {
		return teacherCode;
	}
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
}
