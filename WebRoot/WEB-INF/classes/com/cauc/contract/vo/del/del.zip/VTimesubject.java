package com.cauc.training.vo;

import java.util.Date;

public class VTimesubject implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7568969576353762357L;
	private String VId;
	private String VName;
	private String VGroup;
	private String VUnit;
	private String DTime;
	private double defaultTime;
	private double finishTime;
	private String viewFinishTime;
	private String viewTotalTime;
	
	public String getVUnit() {
		return VUnit;
	}
	public void setVUnit(String vUnit) {
		VUnit = vUnit;
	}
	private Date DCreatedate;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVGroup() {
		return VGroup;
	}
	public void setVGroup(String vGroup) {
		VGroup = vGroup;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getDTime() {
		return DTime;
	}
	public void setDTime(String dTime) {
		DTime = dTime;
	}
	public double getDefaultTime() {
		return defaultTime;
	}
	public void setDefaultTime(double defaultTime) {
		this.defaultTime = defaultTime;
	}
	public double getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(double finishTime) {
		this.finishTime = finishTime;
	}
	public String getViewFinishTime() {
		return viewFinishTime;
	}
	public void setViewFinishTime(String viewFinishTime) {
		this.viewFinishTime = viewFinishTime;
	}
	public String getViewTotalTime() {
		return viewTotalTime;
	}
	public void setViewTotalTime(String viewTotalTime) {
		this.viewTotalTime = viewTotalTime;
	}

	
}
