package com.cauc.training.vo;

public class VToDoing  implements java.io.Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 404518748842197237L;
	private String submitUserName;//提交人姓名
	private String submitUserId;//提交人id
	private String title;//标题
	private String submitTime;//提交时间
	private String infoId;//信息id
	private String type;//信息类型
	
	private String VJishu;
	private String VZongjie;
	private Integer IPass;
	private String VCheckcomment;
	private Integer IZpzb;
	private Integer IZpjs;
	private Integer IZp;
	
	public String getSubmitUserName() {
		return submitUserName;
	}
	public void setSubmitUserName(String submitUserName) {
		this.submitUserName = submitUserName;
	}
	public String getSubmitUserId() {
		return submitUserId;
	}
	public void setSubmitUserId(String submitUserId) {
		this.submitUserId = submitUserId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(String submitTime) {
		this.submitTime = submitTime;
	}
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getVJishu() {
		return VJishu;
	}
	public void setVJishu(String vJishu) {
		VJishu = vJishu;
	}
	public String getVZongjie() {
		return VZongjie;
	}
	public void setVZongjie(String vZongjie) {
		VZongjie = vZongjie;
	}
	public Integer getIPass() {
		return IPass;
	}
	public void setIPass(Integer iPass) {
		IPass = iPass;
	}
	public String getVCheckcomment() {
		return VCheckcomment;
	}
	public void setVCheckcomment(String vCheckcomment) {
		VCheckcomment = vCheckcomment;
	}
	public Integer getIZpzb() {
		return IZpzb;
	}
	public void setIZpzb(Integer iZpzb) {
		IZpzb = iZpzb;
	}
	public Integer getIZpjs() {
		return IZpjs;
	}
	public void setIZpjs(Integer iZpjs) {
		IZpjs = iZpjs;
	}
	public Integer getIZp() {
		return IZp;
	}
	public void setIZp(Integer iZp) {
		IZp = iZp;
	}
	
	
}
