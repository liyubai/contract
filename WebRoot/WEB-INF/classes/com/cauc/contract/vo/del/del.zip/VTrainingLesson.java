package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.Lessonchangedbaseflyline;
import com.cauc.training.pojos.TTrainingLesson;

public class VTrainingLesson implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3224021892410817636L;
	TTrainingLesson trainingLseeson;
	private String DFjsj;
	private String DXlqsj;
	private String DXlsj;
	private String DMnjsj;
	List<Lessonchangedbaseflyline> lessonchangedbaseflylineList;
	
	List<VTraininglessonSubjectRelation> relationzList;
	
	public TTrainingLesson getTrainingLseeson() {
		return trainingLseeson;
	}

	public void setTrainingLseeson(TTrainingLesson trainingLseeson) {
		this.trainingLseeson = trainingLseeson;
	}

	public List<Lessonchangedbaseflyline> getLessonchangedbaseflylineList() {
		return lessonchangedbaseflylineList;
	}

	public void setLessonchangedbaseflylineList(
			List<Lessonchangedbaseflyline> lessonchangedbaseflylineList) {
		this.lessonchangedbaseflylineList = lessonchangedbaseflylineList;
	}

	public List<VTraininglessonSubjectRelation> getRelationzList() {
		return relationzList;
	}

	public void setRelationzList(List<VTraininglessonSubjectRelation> relationzList) {
		this.relationzList = relationzList;
	}

	public String getDFjsj() {
		return DFjsj;
	}

	public void setDFjsj(String dFjsj) {
		DFjsj = dFjsj;
	}

	public String getDXlqsj() {
		return DXlqsj;
	}

	public void setDXlqsj(String dXlqsj) {
		DXlqsj = dXlqsj;
	}


	public String getDXlsj() {
		return DXlsj;
	}

	public void setDXlsj(String dXlsj) {
		DXlsj = dXlsj;
	}

	public String getDMnjsj() {
		return DMnjsj;
	}

	public void setDMnjsj(String dMnjsj) {
		DMnjsj = dMnjsj;
	}


	
}
