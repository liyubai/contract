package com.cauc.training.vo;

import java.util.List;


public class VTrainingLessonContent implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1436666082923845331L;
	private String VId;
	private String startName;
	private String endName;
	private Integer IOrder;
	private String VNo;
	private String VName;
	private String VVersion;
	private String IType;
	private String IPlaneproperty;
	private String ITrainType;
	private String IDaynightproperty;
	private String IFxxz;
	private String IKcxz;
	private String ITj;
	private double DFjsj;
	private double DXlqsj;
	private double DYbsj;
	private double DMnjsj;
	private String VTrainpurpose;
	private String VNeirong;
	private String VTiaojian;
	private String VShebei;
	private String VXiangmu;
	private String VTsyq;
	private String VBz;
	private boolean flag;
	private Integer IIsthree;
	private Integer IOneNum;
	private Integer ITotalNum;
	private List<VTimesubject> subList;
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getStartName() {
		return startName;
	}
	public void setStartName(String startName) {
		this.startName = startName;
	}
	public String getEndName() {
		return endName;
	}
	public void setEndName(String endName) {
		this.endName = endName;
	}
	public Integer getIOrder() {
		return IOrder;
	}
	public void setIOrder(Integer iOrder) {
		IOrder = iOrder;
	}
	public String getVNo() {
		return VNo;
	}
	public void setVNo(String vNo) {
		VNo = vNo;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVVersion() {
		return VVersion;
	}
	public void setVVersion(String vVersion) {
		VVersion = vVersion;
	}

	public String getIType() {
		return IType;
	}
	public void setIType(String iType) {
		IType = iType;
	}
	public String getIPlaneproperty() {
		return IPlaneproperty;
	}
	public void setIPlaneproperty(String iPlaneproperty) {
		IPlaneproperty = iPlaneproperty;
	}
	public String getITrainType() {
		return ITrainType;
	}
	public void setITrainType(String iTrainType) {
		ITrainType = iTrainType;
	}
	public String getIDaynightproperty() {
		return IDaynightproperty;
	}
	public void setIDaynightproperty(String iDaynightproperty) {
		IDaynightproperty = iDaynightproperty;
	}
	public String getIFxxz() {
		return IFxxz;
	}
	public void setIFxxz(String iFxxz) {
		IFxxz = iFxxz;
	}
	public String getIKcxz() {
		return IKcxz;
	}
	public void setIKcxz(String iKcxz) {
		IKcxz = iKcxz;
	}
	public String getITj() {
		return ITj;
	}
	public void setITj(String iTj) {
		ITj = iTj;
	}
	public double getDFjsj() {
		return DFjsj;
	}
	public void setDFjsj(double dFjsj) {
		DFjsj = dFjsj;
	}
	public double getDXlqsj() {
		return DXlqsj;
	}
	public void setDXlqsj(double dXlqsj) {
		DXlqsj = dXlqsj;
	}
	public double getDYbsj() {
		return DYbsj;
	}
	public void setDYbsj(double dYbsj) {
		DYbsj = dYbsj;
	}
	public String getVTrainpurpose() {
		return VTrainpurpose;
	}
	public void setVTrainpurpose(String vTrainpurpose) {
		VTrainpurpose = vTrainpurpose;
	}
	public String getVNeirong() {
		return VNeirong;
	}
	public void setVNeirong(String vNeirong) {
		VNeirong = vNeirong;
	}
	public String getVTiaojian() {
		return VTiaojian;
	}
	public void setVTiaojian(String vTiaojian) {
		VTiaojian = vTiaojian;
	}
	public String getVShebei() {
		return VShebei;
	}
	public void setVShebei(String vShebei) {
		VShebei = vShebei;
	}
	public String getVXiangmu() {
		return VXiangmu;
	}
	public void setVXiangmu(String vXiangmu) {
		VXiangmu = vXiangmu;
	}
	public String getVTsyq() {
		return VTsyq;
	}
	public void setVTsyq(String vTsyq) {
		VTsyq = vTsyq;
	}
	public String getVBz() {
		return VBz;
	}
	public void setVBz(String vBz) {
		VBz = vBz;
	}
	public double getDMnjsj() {
		return DMnjsj;
	}
	public void setDMnjsj(double dMnjsj) {
		DMnjsj = dMnjsj;
	}
	public Integer getIIsthree() {
		return IIsthree;
	}
	public void setIIsthree(Integer iIsthree) {
		IIsthree = iIsthree;
	}
	public Integer getIOneNum() {
		return IOneNum;
	}
	public void setIOneNum(Integer iOneNum) {
		IOneNum = iOneNum;
	}
	public Integer getITotalNum() {
		return ITotalNum;
	}
	public void setITotalNum(Integer iTotalNum) {
		ITotalNum = iTotalNum;
	}
	public List<VTimesubject> getSubList() {
		return subList;
	}
	public void setSubList(List<VTimesubject> subList) {
		this.subList = subList;
	}
	
	
}
