package com.cauc.training.vo;

import java.util.List;

public class VTrainingRecordCompletion  implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -137022130751952232L;
	private String VId;
	private String VCode;
	private String VName;
	private String stuid;
	private String outlineId;
	private String outlineName;
	private Integer isChild;
	private double finishTime;
	private double totalTime;
	private double monijiTime;
	private double trainingTime;
	
	private String viewFinishTime;
	private String viewTotalTime;
	private Integer hasFit;
	
	private List<VTimesubject> subList;
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getOutlineId() {
		return outlineId;
	}
	public void setOutlineId(String outlineId) {
		this.outlineId = outlineId;
	}
	public String getOutlineName() {
		return outlineName;
	}
	public void setOutlineName(String outlineName) {
		this.outlineName = outlineName;
	}
	public double getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(double finishTime) {
		this.finishTime = finishTime;
	}
	public double getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(double totalTime) {
		this.totalTime = totalTime;
	}
	public Integer getIsChild() {
		return isChild;
	}
	public void setIsChild(Integer isChild) {
		this.isChild = isChild;
	}
	public double getMonijiTime() {
		return monijiTime;
	}
	public void setMonijiTime(double monijiTime) {
		this.monijiTime = monijiTime;
	}
	public double getTrainingTime() {
		return trainingTime;
	}
	public void setTrainingTime(double trainingTime) {
		this.trainingTime = trainingTime;
	}
	public String getViewFinishTime() {
		return viewFinishTime;
	}
	public void setViewFinishTime(String viewFinishTime) {
		this.viewFinishTime = viewFinishTime;
	}
	public String getViewTotalTime() {
		return viewTotalTime;
	}
	public void setViewTotalTime(String viewTotalTime) {
		this.viewTotalTime = viewTotalTime;
	}
	public List<VTimesubject> getSubList() {
		return subList;
	}
	public void setSubList(List<VTimesubject> subList) {
		this.subList = subList;
	}
	public String getStuid() {
		return stuid;
	}
	public void setStuid(String stuid) {
		this.stuid = stuid;
	}
	public Integer getHasFit() {
		return hasFit;
	}
	public void setHasFit(Integer hasFit) {
		this.hasFit = hasFit;
	}
	
	
}
