package com.cauc.training.vo;

public class VTraininglessonSubjectRelation implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8536864336801475311L;
	private String subjectid;
	private String DTime;
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getDTime() {
		return DTime;
	}
	public void setDTime(String dTime) {
		DTime = dTime;
	}
	
	
}
