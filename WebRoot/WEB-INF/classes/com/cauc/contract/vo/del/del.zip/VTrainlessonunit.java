package com.cauc.training.vo;



public class VTrainlessonunit implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4023527069126660804L;
	private String VId;
	private String outlineid;
	private String VName;
	private String VNo;
	private String VLicenseform;
	private String VConditions;
	private String VPassstandard;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getOutlineid() {
		return outlineid;
	}
	public void setOutlineid(String outlineid) {
		this.outlineid = outlineid;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVNo() {
		return VNo;
	}
	public void setVNo(String vNo) {
		VNo = vNo;
	}
	public String getVLicenseform() {
		return VLicenseform;
	}
	public void setVLicenseform(String vLicenseform) {
		VLicenseform = vLicenseform;
	}
	public String getVConditions() {
		return VConditions;
	}
	public void setVConditions(String vConditions) {
		VConditions = vConditions;
	}
	public String getVPassstandard() {
		return VPassstandard;
	}
	public void setVPassstandard(String vPassstandard) {
		VPassstandard = vPassstandard;
	}

	
}
