package com.cauc.training.vo;

import java.util.Date;


public class VTrainsubject implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4938194733786645682L;
	private String VId;
	private String VName;
	private Integer ISort;
	private String typeid;
	private String typeName;
	private String VSubname;
	private double DScore;
	private double oldScore;
	private Date DCreatedate;
	private String pdate;
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public Integer getISort() {
		return ISort;
	}
	public void setISort(Integer iSort) {
		ISort = iSort;
	}
	public String getVSubname() {
		return VSubname;
	}
	public void setVSubname(String vSubname) {
		VSubname = vSubname;
	}
	public Date getDCreatedate() {
		return DCreatedate;
	}
	public void setDCreatedate(Date dCreatedate) {
		DCreatedate = dCreatedate;
	}
	public String getTypeid() {
		return typeid;
	}
	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public double getDScore() {
		return DScore;
	}
	public void setDScore(double dScore) {
		DScore = dScore;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public double getOldScore() {
		return oldScore;
	}
	public void setOldScore(double oldScore) {
		this.oldScore = oldScore;
	}
	
	
}
