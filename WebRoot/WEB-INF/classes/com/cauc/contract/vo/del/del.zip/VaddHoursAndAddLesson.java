package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.TTrainingLesson;


public class VaddHoursAndAddLesson implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -428026584180753595L;
	private String VId;
	private String VCode;
	private String VName;
	private String VGender;
	private String stuTypeName;
	private String companyName;
	private String xjStatusName;
	private String formName;
	private String freeTypeName;
	private Integer ITjexam;

	private String addHours;//加时
	private List<TTrainingLesson> addLessonList;//加课
	
	public String getVId() {
		return VId;
	}
	public void setVId(String vId) {
		VId = vId;
	}
	public String getVCode() {
		return VCode;
	}
	public void setVCode(String vCode) {
		VCode = vCode;
	}
	public String getVName() {
		return VName;
	}
	public void setVName(String vName) {
		VName = vName;
	}
	public String getVGender() {
		return VGender;
	}
	public void setVGender(String vGender) {
		VGender = vGender;
	}
	public String getStuTypeName() {
		return stuTypeName;
	}
	public void setStuTypeName(String stuTypeName) {
		this.stuTypeName = stuTypeName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getXjStatusName() {
		return xjStatusName;
	}
	public void setXjStatusName(String xjStatusName) {
		this.xjStatusName = xjStatusName;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFreeTypeName() {
		return freeTypeName;
	}
	public void setFreeTypeName(String freeTypeName) {
		this.freeTypeName = freeTypeName;
	}
	public String getAddHours() {
		return addHours;
	}
	public void setAddHours(String addHours) {
		this.addHours = addHours;
	}
	public List<TTrainingLesson> getAddLessonList() {
		return addLessonList;
	}
	public void setAddLessonList(List<TTrainingLesson> addLessonList) {
		this.addLessonList = addLessonList;
	}
	public Integer getITjexam() {
		return ITjexam;
	}
	public void setITjexam(Integer iTjexam) {
		ITjexam = iTjexam;
	}

	
}
