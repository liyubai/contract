package com.cauc.training.vo;

import java.util.List;

import com.cauc.training.pojos.Studentassignschool;
import com.cauc.training.pojos.TAbroadtrain;
import com.cauc.training.pojos.TForeignaviationschoolinterview;

public class Vforeignaviationschoolinterview implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6613085536592721142L;
	
	private String VId;//学员id
	private String VCode;
	private String VName;
	private String VGender;
	
	private List<Studentassignschool> schoolList;//航校表
	
	private List<TForeignaviationschoolinterview> viewList;//面试表
	
	private List<TAbroadtrain> trainingList;//训练表

	public String getVId() {
		return VId;
	}

	public void setVId(String vId) {
		VId = vId;
	}

	public String getVCode() {
		return VCode;
	}

	public void setVCode(String vCode) {
		VCode = vCode;
	}

	public String getVName() {
		return VName;
	}

	public void setVName(String vName) {
		VName = vName;
	}

	public String getVGender() {
		return VGender;
	}

	public void setVGender(String vGender) {
		VGender = vGender;
	}

	public List<Studentassignschool> getSchoolList() {
		return schoolList;
	}

	public void setSchoolList(List<Studentassignschool> schoolList) {
		this.schoolList = schoolList;
	}

	public List<TForeignaviationschoolinterview> getViewList() {
		return viewList;
	}

	public void setViewList(List<TForeignaviationschoolinterview> viewList) {
		this.viewList = viewList;
	}

	public List<TAbroadtrain> getTrainingList() {
		return trainingList;
	}

	public void setTrainingList(List<TAbroadtrain> trainingList) {
		this.trainingList = trainingList;
	}
	
	
	
	
}
